#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Legend Code 2  -  Code. Build. Create.
-------------------------------------
A fast, modern code editor for Python and C/C++ in ONE file.
No installs needed: just Python 3.8+ (Tk is included on Windows / macOS).
C/C++ needs a compiler (g++ / gcc / clang) on your PATH.

Built-in AI:  works out of the box with NO sign-up and NO key
  1. A local Ollama model if one is running on this PC (private, offline)
  2. Otherwise a free online model (your code is sent to that service)
  3. Optionally Claude, if you paste an API key in Settings

Run:   python legend_ide_v2.pyw
"""
import glob
import os
import re
import sys
import math
import base64
import struct
import zlib
import unicodedata
import json
import time
import bisect
import codecs
import queue
import shlex
import shutil
import hashlib
import keyword
import builtins
import tempfile
import threading
import importlib
import traceback
import subprocess
import webbrowser
import urllib.error
import urllib.request

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from tkinter import font as tkfont

APP = "Legend Code"
VERSION = "3.0"
APP_BUILD = 20                    # bump on every release; the app updates itself when GitHub has a higher build
UPDATE_BASE = "https://github.com/MATRIX5578/legend-code/releases/latest/download/"
HOME = os.path.expanduser("~")
SCRIPT_PATH = os.path.abspath(sys.executable if (getattr(sys, "frozen", False) or os.path.basename(sys.executable or "").lower().startswith("legend"))
                              else (globals().get("__file__") or sys.argv[0] or "legend_code.pyw"))
CONFIG_PATH = os.path.join(HOME, ".legend_ide.json")          # same settings file as v1
SESSION_PATH = os.path.join(HOME, ".legend_ide_session.json")  # unsaved-work safety copy
CRASH_LOG = os.path.join(HOME, ".legend_ide_crash.log")
TMP = os.path.join(tempfile.gettempdir(), "legend_ide")
IS_WIN = os.name == "nt"
IS_MAC = sys.platform == "darwin"
MAX_HL = 2_000_000        # never syntax-highlight more than this many characters at once
FULL_HL_LINES = 1500      # files up to this many lines are highlighted whole; bigger ones lazily (visible part)
TAB = "    "
RIGHT_CLICK = ("<Button-2>", "<Control-Button-1>") if IS_MAC else ("<Button-3>",)   # macOS: right button = Button-2
MIDDLE_CLICK = "<Button-3>" if IS_MAC else "<Button-2>"


def fs(n):
    """Font size helper: Tk on macOS draws point sizes noticeably smaller than on Windows."""
    return int(round(n * 1.3)) if IS_MAC else n


def K(s):
    """Show shortcut text the Mac way (⌘ ⇧ ⌥) on macOS; unchanged elsewhere."""
    if not IS_MAC or not s:
        return s
    return s.replace("Ctrl+Shift+", "⇧⌘").replace("Ctrl+", "⌘").replace("Shift+", "⇧").replace("Alt+", "⌥")


# ---- appearance variants (accent colours, colourful mode, glass, corner style) and language -----------------------
def make_theme(cfg):
    """The active theme = base theme + the user's accent / colourful / glass choices."""
    base = THEMES.get(cfg.get("theme"), THEMES["Legend Dark"])
    th = dict(base)
    acc = cfg.get("accent", "auto")
    if acc in ACCENTS or (isinstance(acc, str) and re.fullmatch(r"#[0-9a-fA-F]{6}", acc)):
        th["accent"] = ACCENTS.get(acc, acc)
        th["accent_fg"] = "#ffffff" if is_dark(th["accent"]) else "#14110a"
        th["sel"] = mix(base["sel"], th["accent"], .22)
    th["hues"] = HUES if cfg.get("colorful") else None
    th["glass"] = bool(cfg.get("glass"))
    th["glass"] = bool(cfg.get("glass")) and not cfg.get("lite")
    if th["glass"]:
        dark = th["dark"]
        tint = "#9db8ff" if dark else "#ffffff"
        for k in ("panel", "side", "act", "bar"):
            th[k] = mix(th[k], tint, .07 if dark else .45)
        th["pop"] = mix(th["pop"], tint, .08 if dark else .5)
        th["border"] = mix(th["border"], "#ffffff", .20 if dark else .55)
        th["hover"] = mix(th["hover"], "#ffffff", .05 if dark else .0)
    return th


def blend_theme(a, b, p):
    """Colour-by-colour mix of two themes (used for the smooth theme cross-fade)."""
    out = dict(b)
    for k, v in b.items():
        if isinstance(v, str) and v.startswith("#") and len(v) == 7 and isinstance(a.get(k), str) and a[k].startswith("#") and len(a[k]) == 7:
            out[k] = mix(a[k], v, p)
    return out


SHAPE = {"k": 1.0, "n": 2.0}


def set_shape(cfg):
    SHAPE["k"], SHAPE["n"] = SHAPES.get(cfg.get("shape"), SHAPES["soft"])


def R(r):
    """Corner radius scaled by the user's shape choice (sharp / soft / round)."""
    return max(0.0, r * SHAPE["k"])


_LANG = ["en"]
STR_AR = {}          # filled in below (Arabic interface strings)


def set_lang(cfg):
    _LANG[0] = cfg.get("ui_lang", "en")


def tr(text):
    """Translate a UI string (identity in English or when no translation exists)."""
    if _LANG[0] == "en" or not isinstance(text, str):
        return text
    return STR_AR.get(text, text)


def ease_out(p):
    return 1 - (1 - p) ** 3


def ease_in_out(p):
    return p * p * (3 - 2 * p)


def ease_in(p):
    return p * p * p


def ease_out_expo(p):
    return 1.0 if p >= 1 else 1 - 2 ** (-10 * p)


def ease_out_back(p, k=1.55):
    """Overshoots a little and settles: the 'spring' feel of the Expressive animation style."""
    p -= 1
    return 1 + (k + 1) * p ** 3 + k * p ** 2


def ease_out_quint(p):
    return 1 - (1 - p) ** 5


def spring(p):
    """Gentle overshoot that settles (the 'alive' feel of Apple's UI); exactly 1.0 at the end."""
    if p >= 1:
        return 1.0
    return 1 - math.exp(-7.5 * p) * math.cos(9.5 * p)


STR_AR.update({
    # --- top bar / menus
    "File": "ملف", "Edit": "تحرير", "View": "عرض", "Run": "تشغيل", "AI": "المساعد", "Help": "مساعدة",
    "Build": "بناء", "Stop": "إيقاف", "Ask AI": "المساعد", "Settings": "الإعدادات", "Home": "الرئيسية",
    "Search commands…        Ctrl+Shift+P": "ابحث في الأوامر…        Ctrl+Shift+P",
    "New file (Ctrl+N)": "ملف جديد (Ctrl+N)", "Open file (Ctrl+O)": "فتح ملف (Ctrl+O)", "Save (Ctrl+S)": "حفظ (Ctrl+S)",
    "Run (F5 or Ctrl+R)": "تشغيل (F5 أو Ctrl+R)", "Stop (Shift+F5 or Ctrl+.)": "إيقاف (Shift+F5 أو Ctrl+.)",
    "Build / check only (F7)": "بناء / فحص فقط (F7)", "Assistant (Ctrl+L)": "المساعد (Ctrl+L)", "Settings (Ctrl+,)": "الإعدادات (Ctrl+,)",
    "Explorer (Ctrl+Shift+E)": "المستكشف (Ctrl+Shift+E)", "Search (Ctrl+Shift+F)": "بحث (Ctrl+Shift+F)", "Run & Build": "تشغيل وبناء",
    "New Python File": "ملف بايثون جديد", "New C++ File": "ملف C++ جديد", "New C File": "ملف C جديد", "New from template…": "جديد من قالب…",
    "Open File…": "فتح ملف…", "Open Folder…": "فتح مجلد…", "Open Recent…": "المفتوحة مؤخرًا…", "Save": "حفظ", "Save As…": "حفظ باسم…",
    "Save All": "حفظ الكل", "Close Tab": "إغلاق التبويب", "Exit": "خروج", "Undo": "تراجع", "Redo": "إعادة", "Cut": "قص", "Copy": "نسخ",
    "Paste": "لصق", "Select All": "تحديد الكل", "Find…": "بحث…", "Replace…": "استبدال…", "Go to Line…": "الانتقال إلى سطر…",
    "Toggle Comment": "تعليق / إلغاء التعليق", "Duplicate Line": "تكرار السطر", "Format Document": "تنسيق المستند",
    "Toggle Sidebar": "إظهار / إخفاء الشريط الجانبي", "Toggle Bottom Panel": "إظهار / إخفاء اللوحة السفلية",
    "Toggle Assistant": "إظهار / إخفاء المساعد", "Full Screen": "ملء الشاشة", "Full screen - press F11 or Esc to leave": "ملء الشاشة - اضغط F11 أو Esc للخروج", "Start in full screen": "ابدأ بملء الشاشة", "Home Page": "الصفحة الرئيسية", "Explorer": "المستكشف",
    "Search in Files": "بحث في الملفات", "Theme…": "السمة…", "Word Wrap: On": "التفاف الأسطر: يعمل", "Word Wrap: Off": "التفاف الأسطر: متوقف",
    "Zoom In": "تكبير", "Zoom Out": "تصغير", "Reset Zoom": "إعادة الحجم", "Fold All": "طي الكل", "Unfold All": "فتح الكل",
    "Run without debugging": "تشغيل بدون تصحيح", "Build only": "بناء فقط", "Show Terminal": "إظهار الطرفية", "Show Problems": "إظهار المشاكل",
    "Compiler & Python settings…": "إعدادات المترجم وبايثون…", "Open Assistant": "فتح المساعد",
    "Ask AI to write code here…": "اطلب من المساعد كتابة كود هنا…", "Explain this code": "اشرح هذا الكود", "Fix errors": "أصلح الأخطاء",
    "Explain last error": "اشرح آخر خطأ", "Improve this code": "حسّن هذا الكود", "Refactor": "إعادة هيكلة", "Generate code…": "توليد كود…",
    "Add comments": "أضف تعليقات", "Write tests": "اكتب اختبارات", "Stop AI": "إيقاف المساعد", "AI settings…": "إعدادات المساعد…",
    "Keyboard Shortcuts": "اختصارات لوحة المفاتيح", "Command Palette": "قائمة الأوامر", "About Legend Code": "عن Legend Code",
    "Open crash log": "فتح سجل الأعطال", "Indent": "إزاحة", "Outdent": "إزاحة عكسية", "Fold / Unfold block": "طي / فتح الكتلة",
    "Ask AI about selection": "اسأل المساعد عن التحديد", "Ask AI about this file": "اسأل المساعد عن هذا الملف",
    "Fix with AI": "أصلح بالمساعد", "Improve with AI": "حسّن بالمساعد", "Ask AI to write here…": "اطلب من المساعد الكتابة هنا…",
    "Close": "إغلاق", "Close Others": "إغلاق الأخرى", "Close All": "إغلاق الكل", "Copy path": "نسخ المسار",
    "Reveal in file manager": "إظهار في مدير الملفات", "Open": "فتح", "No open files": "لا توجد ملفات مفتوحة",
    "Nothing opened yet": "لم يُفتح شيء بعد",
    # --- explorer / search / run sidebar
    "New File…": "ملف جديد…", "New Folder…": "مجلد جديد…", "Rename…": "إعادة تسمية…", "Rename": "إعادة تسمية", "Delete": "حذف",
    "Refresh": "تحديث", "New file": "ملف جديد", "New folder": "مجلد جديد", "Open folder": "فتح مجلد", "Explorer refreshed": "تم تحديث المستكشف",
    "No folder open": "لا يوجد مجلد مفتوح", "Open Folder": "فتح مجلد", "Open File": "فتح ملف",
    "Open a folder to browse and\nmanage its files here.": "افتح مجلدًا لتتصفح ملفاته\nوتديرها من هنا.",
    "Search": "بحث", "Type to search the open folder and open files.": "اكتب للبحث في المجلد المفتوح والملفات المفتوحة.",
    "Run current file": "تشغيل الملف الحالي", "Program arguments": "معاملات البرنامج", "Save the file before running": "احفظ الملف قبل التشغيل",
    "Clear the terminal on each run": "امسح الطرفية عند كل تشغيل", "Compiler settings": "إعدادات المترجم",
    "Tip: errors in the Terminal and Problems list are clickable and jump to the exact line.\nStep-by-step debugging isn't built in yet.":
        "نصيحة: الأخطاء في الطرفية وقائمة المشاكل قابلة للنقر وتنقلك إلى السطر المحدد.\nالتنفيذ خطوة بخطوة غير متوفر بعد.",
    # --- bottom panel / status
    "Terminal": "الطرفية", "Output": "المخرجات", "Problems": "المشاكل", "Debug Console": "وحدة التصحيح", "No problems found": "لا توجد مشاكل",
    "  input ›": "  إدخال ›", "Send": "إرسال", "Close input (Ctrl+D)": "إغلاق الإدخال (Ctrl+D)", "Ready": "جاهز",
    "Press F5 to run": "اضغط F5 للتشغيل", "Running…": "يعمل…", "Building…": "جاري البناء…", "Build OK": "تم البناء",
    "Build failed": "فشل البناء", "Stopped": "متوقف", "Finished": "انتهى", "Language mode": "لغة الملف",
    "Compilers found on this PC": "المترجمات الموجودة على هذا الجهاز", "Indentation": "المسافات البادئة", "AI provider": "مزوّد المساعد",
    "✔ No syntax errors": "✔ لا أخطاء في الصياغة", "Hide panel (Ctrl+J)": "إخفاء اللوحة (Ctrl+J)", "Clear": "مسح",
    "Build successful": "تم البناء بنجاح", "Build failed - click an error to jump to it": "فشل البناء - اضغط على خطأ للانتقال إليه",
    "Open a file first": "افتح ملفًا أولًا", "Open the file with the error first": "افتح الملف الذي فيه الخطأ أولًا",
    "That folder no longer exists": "هذا المجلد لم يعد موجودًا", "Input closed (EOF sent)": "تم إغلاق الإدخال",
    "Started in safe mode: the last start did not finish. Your files are untouched.": "بدأ البرنامج في الوضع الآمن: المرة السابقة لم تكتمل. ملفاتك سليمة.",
    "Shortcuts with a custom icon are for Windows.": "الاختصارات ذات الأيقونة المخصصة خاصة بويندوز.",
    "Add the Legend Code icon to your Desktop?": "هل تريد إضافة أيقونة Legend Code إلى سطح المكتب؟", "Add": "إضافة",
    "Shortcut created on your Desktop": "تم إنشاء الاختصار على سطح المكتب", "Could not create the shortcut": "تعذّر إنشاء الاختصار",
    "Theme": "السمة", "Restart": "إعادة التشغيل", "Restart to apply the language": "أعد التشغيل لتطبيق اللغة", "Panels reset": "تمت إعادة ضبط اللوحات",
    "Recovered %d unsaved file(s)": "تمت استعادة %d ملف(ات) غير محفوظة", "No unsaved work to recover": "لا يوجد عمل غير محفوظ لاستعادته",
    "No crash log - everything has been running smoothly.": "لا يوجد سجل أعطال - كل شيء يعمل بسلاسة.",
    # --- assistant
    "Assistant": "المساعد", "Explain": "اشرح", "Fix": "أصلح", "Improve": "حسّن", "Generate": "ولّد", "Comment": "علّق", "Tests": "اختبارات",
    "Error help": "مساعدة الخطأ", "Current file": "الملف الحالي", "Terminal output": "مخرجات الطرفية", "You": "أنت",
    "Set up local AI": "إعداد المساعد المحلي", "Got it": "حسنًا", "Close (Esc)": "إغلاق (Esc)", "Hide (Ctrl+L)": "إخفاء (Ctrl+L)",
    "Clear chat": "مسح المحادثة", "thinking…": "يفكر…", "Describe the code to generate…": "صف الكود المطلوب توليده…",
    "Hi! I'm your coding assistant.\n\nAsk me anything, or press a button above. Select some code first to work on just that part.\n\n"
    "No account, no key, no cost. When something fails, press Error help - it works even offline.":
        "أهلًا! أنا مساعدك في البرمجة.\n\nاسألني أي شيء أو اضغط أحد الأزرار بالأعلى. حدّد جزءًا من الكود أولًا لأعمل عليه وحده.\n\n"
        "بدون حساب ولا مفتاح ولا تكلفة. وعند حدوث خطأ اضغط «مساعدة الخطأ» - تعمل حتى بدون إنترنت.",
    "Ask the assistant…   Enter = send · Shift+Enter = new line": "اسأل المساعد…   Enter = إرسال · Shift+Enter = سطر جديد",
    "The assistant is built in and free - no account needed. It uses a free online model, so your code is sent to that service. "
    "For fully private, offline use, set up a local model.":
        "المساعد مدمج ومجاني - بدون حساب. يستخدم نموذجًا مجانيًا عبر الإنترنت، لذلك يُرسل الكود إلى تلك الخدمة. للخصوصية الكاملة وللعمل بدون إنترنت أعدّ نموذجًا محليًا.",
    "Explain the last error": "اشرح آخر خطأ", "Quick diagnosis (works offline)": "تشخيص سريع (يعمل بدون إنترنت)",
    "I could not recognise this error offline. Press Fix and I will ask the online assistant.":
        "لم أتعرف على هذا الخطأ بدون إنترنت. اضغط «أصلح» وسأسأل المساعد عبر الإنترنت.",
    "Meanwhile, from the error text (offline)": "في الأثناء، من نص الخطأ (بدون إنترنت)",
    "Nothing to explain yet - run your program first": "لا شيء لشرحه بعد - شغّل برنامجك أولًا",
    "Insert at cursor": "أدرج عند المؤشر", "Ask the assistant": "اسأل المساعد",
    "Built-in assistant · no account needed        Ctrl+Shift+P  commands        F5  run        Ctrl+L  assistant":
        "مساعد مدمج · بدون حساب        Ctrl+Shift+P  الأوامر        F5  تشغيل        Ctrl+L  المساعد",
    # --- home page
    "New Python File ": "ملف بايثون جديد", "Start a C++ program": "ابدأ برنامج C++", "Recent projects": "المشاريع الأخيرة",
    "Recent files": "الملفات الأخيرة", "Folders you open will appear here.": "المجلدات التي تفتحها ستظهر هنا.",
    "Files you open will appear here.": "الملفات التي تفتحها ستظهر هنا.", "Code. Build. Create.": "اكتب. ابنِ. أبدع.",
    # --- palette
    "No matching commands": "لا توجد أوامر مطابقة", "↑ ↓ to choose · Enter to run · Esc to close": "↑ ↓ للاختيار · Enter للتنفيذ · Esc للإغلاق",
    "Toggle Terminal / Bottom Panel": "إظهار / إخفاء الطرفية", "Toggle AI": "إظهار / إخفاء المساعد", "Show Explorer": "إظهار المستكشف",
    "Show Output": "إظهار المخرجات", "Show Debug Console": "إظهار وحدة التصحيح", "Change Theme": "تغيير السمة", "Find": "بحث",
    "Replace": "استبدال", "Go to Line": "الانتقال إلى سطر", "Toggle Word Wrap": "تبديل التفاف الأسطر", "AI Settings": "إعدادات المساعد",
    "AI: Explain Code": "المساعد: اشرح الكود", "AI: Fix Errors": "المساعد: أصلح الأخطاء", "AI: Improve Code": "المساعد: حسّن الكود",
    "AI: Refactor": "المساعد: إعادة هيكلة", "AI: Generate Code": "المساعد: ولّد كودًا", "AI: Add Comments": "المساعد: أضف تعليقات",
    "AI: Write Tests": "المساعد: اكتب اختبارات", "AI: Ask Inline at Cursor": "المساعد: اكتب عند المؤشر",
    # --- settings
    "General": "عام", "Appearance": "المظهر", "Editor": "المحرر", "Python": "بايثون", "C/C++": "C/C++", "Advanced": "متقدم",
    "Reset settings": "إعادة ضبط الإعدادات", "Changes are saved automatically.": "التغييرات تُحفظ تلقائيًا.",
    "Language, start-up and saving.": "اللغة والبدء والحفظ.", "Colours, shapes, glass and motion.": "الألوان والأشكال والزجاج والحركة.",
    "How the code editor behaves.": "طريقة عمل محرر الكود.", "The interpreter and how programs are run.": "المفسّر وطريقة تشغيل البرامج.",
    "Compilers and build flags.": "المترجمات وخيارات البناء.",
    "The assistant works out of the box: no account, no key, no cost. Everything here is optional.":
        "المساعد يعمل مباشرة: بدون حساب ولا مفتاح ولا تكلفة. كل ما هنا اختياري.",
    "Performance, safety and diagnostics.": "الأداء والأمان والتشخيص.",
    "Language": "اللغة", "Interface language": "لغة الواجهة", "The interface changes after a restart.": "تتغير الواجهة بعد إعادة التشغيل.",
    "Start": "البدء", "When Legend starts": "عند تشغيل البرنامج", "Reopen my last files": "أعد فتح ملفاتي الأخيرة",
    "Show the Home page": "اعرض الصفحة الرئيسية", "Start with a new file": "ابدأ بملف جديد", "Short welcome message": "رسالة ترحيب قصيرة",
    "One quiet line when the app opens. Never blocks or slows the start.": "سطر هادئ عند فتح البرنامج. لا يعطّل البدء ولا يبطّئه.",
    "Saving": "الحفظ", "Autosave": "حفظ تلقائي", "Saves files that already have a name.": "يحفظ الملفات التي لها اسم.",
    "Autosave every": "احفظ كل", "15 seconds": "15 ثانية", "30 seconds": "30 ثانية", "1 minute": "دقيقة", "2 minutes": "دقيقتان",
    "Confirm before closing": "تأكيد قبل الإغلاق",
    "Always ask before Legend Code quits. (Unsaved changes are always asked about.)": "اسأل دائمًا قبل إغلاق Legend Code. (التغييرات غير المحفوظة يُسأل عنها دائمًا.)",
    "Windows": "ويندوز", "Desktop icon": "أيقونة سطح المكتب", "Create shortcut": "إنشاء اختصار",
    "Adds a Legend Code shortcut that shows the logo (Windows shows Python's icon for .pyw files).":
        "يضيف اختصار Legend Code يعرض الشعار (ويندوز يعرض أيقونة بايثون لملفات .pyw).",
    "Look": "المظهر", "Theme ": "السمة", "Colours cross-fade smoothly.": "الألوان تتبدّل بنعومة.", "Accent colour": "لون التمييز",
    "Colour of highlights, buttons and selections.": "لون العناصر المميّزة والأزرار والتحديد.", "Colourful interface": "واجهة ملوّنة",
    "Gives each part its own colour: sidebar icons, menus and the home cards.": "يمنح كل جزء لونه: أيقونات الشريط والقوائم وبطاقات الرئيسية.",
    "Shapes": "الأشكال", "The corner style of buttons, cards and menus.": "شكل زوايا الأزرار والبطاقات والقوائم.",
    "Sharp": "حادة", "Soft": "ناعمة", "Round": "مستديرة", "Glass": "زجاج", "Glass style": "طابع زجاجي",
    "Lighter, cooler surfaces with soft glowing edges, plus a see-through window.": "أسطح أفتح وأبرد بحواف متوهجة ناعمة، مع نافذة شفافة قليلًا.",
    "Window transparency": "شفافية النافذة", "Used together with Glass style.": "تُستخدم مع الطابع الزجاجي.",
    "None (100%)": "بدون (100%)", "Slight (95%)": "خفيفة (95%)", "Medium (90%)": "متوسطة (90%)", "Strong (85%)": "قوية (85%)",
    "Very strong (80%)": "قوية جدًا (80%)", "Motion": "الحركة", "Smooth animations": "حركة سلسة", "Gentle fades, glides and springs.": "تلاشٍ وانزلاق ونوابض ناعمة.",
    "Animation style": "نمط الحركة", "Smooth (richer)": "سلس (أغنى)", "Subtle (shorter)": "هادئ (أقصر)", "Editor text": "نص المحرر",
    "Editor font": "خط المحرر", "Monospaced fonts found on this PC.": "الخطوط أحادية المسافة الموجودة على هذا الجهاز.", "Font size": "حجم الخط",
    "Typing": "الكتابة", "Tab size": "حجم Tab", "2 spaces": "مسافتان", "4 spaces": "4 مسافات", "8 spaces": "8 مسافات", "Autocomplete": "إكمال تلقائي",
    "Suggest variables, functions and keywords as you type (Ctrl+Space any time).": "يقترح المتغيرات والدوال والكلمات أثناء الكتابة (Ctrl+Space في أي وقت).",
    "Display": "العرض", "Word wrap": "التفاف الأسطر", "Line numbers": "أرقام الأسطر", "Highlight current line": "تمييز السطر الحالي",
    "Bracket matching": "مطابقة الأقواس", "Highlights the partner of the bracket next to the cursor.": "يميّز القوس المقابل للقوس بجانب المؤشر.",
    "Interpreter": "المفسّر", "Python executable": "ملف بايثون التنفيذي", "Leave empty to auto-detect.": "اتركه فارغًا للكشف التلقائي.",
    "Running": "التشغيل", "Passed to your program (same box as the Run sidebar).": "تُمرَّر إلى برنامجك (نفس خانة شريط التشغيل).",
    "Compiler": "المترجم", "C++ compiler (g++)": "مترجم C++ ‏(g++)", "Leave empty to auto-detect (also finds MinGW on Windows).": "اتركه فارغًا للكشف التلقائي (يجد MinGW أيضًا).",
    "Flags": "الخيارات", "C++ flags": "خيارات C++", "C flags": "خيارات C", "Example: -std=c++17 -O2 -Wall": "مثال: -std=c++17 -O2 -Wall",
    "Example: -std=c17 -O2 -Wall": "مثال: -std=c17 -O2 -Wall", "Unbuffered output": "مخرجات فورية", "Makes prompts appear immediately in the terminal.": "تجعل الرسائل تظهر فورًا في الطرفية.",
    "Provider": "المزوّد", "Auto (recommended)": "تلقائي (موصى به)", "Free online - no account": "مجاني عبر الإنترنت - بدون حساب",
    "Local model - Ollama": "نموذج محلي - Ollama", "Claude - needs an API key": "Claude - يحتاج مفتاح API",
    "Auto uses a local model when one is running, otherwise the free online model.": "التلقائي يستخدم نموذجًا محليًا إن وُجد، وإلا النموذج المجاني عبر الإنترنت.",
    "Reply language": "لغة الردود", "Arabic": "العربية", "English": "English", "Same as my question": "مثل لغة سؤالي",
    "Check that it works": "تأكد أنه يعمل", "Test the assistant": "اختبر المساعد", "Local AI - private, offline, free": "ذكاء محلي - خاص وبدون إنترنت ومجاني",
    "Runs on your own PC with Ollama. Your code never leaves your computer, and there are no limits.": "يعمل على جهازك عبر Ollama. كودك لا يغادر جهازك وبدون حدود.",
    "Ollama status": "حالة Ollama", "Set up": "الإعداد", "1. Get Ollama": "1. نزّل Ollama", "Check again": "تحقق مجددًا",
    "Download progress": "تقدم التحميل", "Ollama address": "عنوان Ollama", "Ollama model": "نموذج Ollama", "Use the name from 'ollama list'.": "استخدم الاسم الظاهر في 'ollama list'.",
    "Free online model": "النموذج المجاني عبر الإنترنت", "Service address": "عنوان الخدمة", "Empty = built-in default.": "فارغ = الافتراضي المدمج.", "Model name": "اسم النموذج",
    "Claude (optional)": "Claude (اختياري)", "API key": "مفتاح API", "Claude model": "نموذج Claude", "Checking…": "جاري الفحص…",
    "Performance": "الأداء", "Lite mode": "الوضع الخفيف", "Turns off animations and glass: the lightest and fastest feel.": "يوقف الحركة والزجاج: أخف وأسرع إحساس.",
    "Safety": "الأمان", "Unsaved work": "عمل غير محفوظ", "If Legend ever closes unexpectedly, your unsaved text is kept safely.": "إذا أُغلق البرنامج فجأة فنصوصك غير المحفوظة محفوظة بأمان.",
    "Recover unsaved work": "استعادة العمل غير المحفوظ", "Panels": "اللوحات", "Brings the side panels back to their normal size.": "يعيد اللوحات الجانبية لحجمها الطبيعي.",
    "Reset layout": "إعادة ضبط التخطيط", "Crash log": "سجل الأعطال", "Where errors are written (send it if something breaks).": "المكان الذي تُكتب فيه الأخطاء (أرسله إذا تعطل شيء).",
    "Information": "معلومات", "Browse…": "استعراض…", "Cancel": "إلغاء", "Create": "إنشاء",
})


# ---- Arabic / right-to-left text: Tk 8.6 draws text strictly left-to-right, so Arabic comes out reversed and unjoined.
# ---- These helpers join the letters (shaping) and put the line in visual order (bidi) before it is drawn.
_NEED_BIDI = [True]                                   # True = handle right-to-left lines specially
_SHAPE_RTL = [sys.platform.startswith("linux")]        # True = Tk cannot shape Arabic here (X11), do it ourselves
RLE, PDF = "\u202b", "\u202c"
_AR = {}


def _arabic_tables():
    if _AR:
        return _AR
    forms, lig = {}, {}
    for cp in range(0xFE70, 0xFF00):
        d = unicodedata.decomposition(chr(cp))
        if not d.startswith("<"):
            continue
        tag, _, rest = d.partition(" ")
        tag = tag.strip("<>")
        base = [int(x, 16) for x in rest.split()]
        if tag not in ("isolated", "initial", "medial", "final"):
            continue
        if len(base) == 1:
            forms.setdefault(base[0], {})[tag] = chr(cp)
        elif len(base) == 2 and base[0] == 0x644:
            lig.setdefault(base[1], {})[tag] = chr(cp)
    _AR["forms"], _AR["lig"] = forms, lig
    return _AR


def _has_rtl(s):
    for ch in s:
        o = ord(ch)
        if 0x0590 <= o <= 0x08FF or 0xFB50 <= o <= 0xFDFF or 0xFE70 <= o <= 0xFEFF:
            return True
    return False


def _joining(ch):
    """'D' joins both sides, 'R' joins the previous letter only, 'T' is a mark (ignored), 'N' joins nothing."""
    o = ord(ch)
    if unicodedata.category(ch) == "Mn":
        return "T"
    if o == 0x0640:
        return "D"
    f = _arabic_tables()["forms"].get(o)
    if not f:
        return "N"
    return "D" if "initial" in f else "R"


def shape_arabic(s):
    """Replace Arabic letters by their joined (initial / medial / final / isolated) presentation forms."""
    t = _arabic_tables()
    forms, lig = t["forms"], t["lig"]
    chars = list(s)
    n = len(chars)
    types = [_joining(c) for c in chars]

    def prev_t(i):
        j = i - 1
        while j >= 0 and types[j] == "T":
            j -= 1
        return types[j] if j >= 0 else "N"

    def next_i(i):
        j = i + 1
        while j < n and types[j] == "T":
            j += 1
        return j

    out, i = [], 0
    while i < n:
        c, o = chars[i], ord(chars[i])
        if types[i] in ("D", "R") and o in forms:
            cp = prev_t(i) == "D"
            j = next_i(i)
            if o == 0x644 and j < n and ord(chars[j]) in lig:
                out.append(lig[ord(chars[j])].get("final" if cp else "isolated", c))
                i = j + 1
                continue
            cn = types[i] == "D" and j < n and types[j] in ("D", "R")
            form = "medial" if (cp and cn) else "final" if cp else "initial" if cn else "isolated"
            out.append(forms[o].get(form) or forms[o].get("isolated") or c)
        else:
            out.append(c)
        i += 1
    return "".join(out)


_MIRROR = {"(": ")", ")": "(", "[": "]", "]": "[", "{": "}", "}": "{", "<": ">", ">": "<", "«": "»", "»": "«"}


def _bidi_line(s):
    """Logical order -> visual order for one line, right-to-left paragraph (a compact version of Unicode UAX #9)."""
    n = len(s)
    cls, last_strong = [], None
    for ch in s:
        b = unicodedata.bidirectional(ch)
        if b in ("L", "R", "AL"):
            last_strong = b
        if b == "EN" and last_strong == "AL":
            b = "AN"
        cls.append(b)
    for i, b in enumerate(cls):                       # numbers: 1,000  3.5  -5  50%
        if b in ("CS", "ES") and 0 < i < n - 1 and cls[i - 1] in ("EN", "AN") and cls[i + 1] == cls[i - 1]:
            cls[i] = cls[i - 1]
        elif b == "ET" and ((i > 0 and cls[i - 1] == "EN") or (i < n - 1 and cls[i + 1] == "EN")):
            cls[i] = "EN"
    kind = []
    for b in cls:
        kind.append("R" if b in ("R", "AL") else "L" if b == "L" else "D" if b in ("EN", "AN") else None)
    lv = [0] * n
    i = 0
    while i < n:
        if kind[i] is None:
            j = i
            while j < n and kind[j] is None:
                j += 1
            a = kind[i - 1] if i > 0 else "R"
            b = kind[j] if j < n else "R"
            a, b = ("R" if a == "D" else a), ("R" if b == "D" else b)
            d = a if a == b else "R"
            for k in range(i, j):
                lv[k] = 1 if d == "R" else 2
            i = j
        else:
            lv[i] = 1 if kind[i] == "R" else 2
            i += 1
    idx, cur = list(range(n)), lv[:]
    for L in range(max(cur) if cur else 0, 0, -1):
        i = 0
        while i < n:
            if cur[i] >= L:
                j = i
                while j < n and cur[j] >= L:
                    j += 1
                idx[i:j] = idx[i:j][::-1]
                cur[i:j] = cur[i:j][::-1]
                i = j
            else:
                i += 1
    return "".join((_MIRROR.get(s[k], s[k]) if lv[k] % 2 == 1 else s[k]) for k in idx)


def visual(s):
    """Text ready to draw: right-to-left lines get the right reading order (no-op for English)."""
    if not _NEED_BIDI[0] or not isinstance(s, str) or not _has_rtl(s):
        return s
    if not _SHAPE_RTL[0]:
        # Windows / macOS shape and reorder Arabic themselves; they only need to know the line reads right-to-left,
        # otherwise a line that mixes Arabic with English or code comes out scrambled.
        return "\n".join((RLE + line + PDF) if (_has_rtl(line) and not line.startswith(RLE)) else line for line in s.split("\n"))
    if any(0xFE70 <= ord(c) <= 0xFEFF for c in s) and not any(0x0621 <= ord(c) <= 0x064A for c in s):
        return s                                     # already converted
    return "\n".join(_bidi_line(shape_arabic(line)) if _has_rtl(line) else line for line in s.split("\n"))


def wrap_logical(text, font, max_px):
    """Greedy word wrap on LOGICAL text (wrap first, reorder each line after)."""
    lines, cur = [], ""
    for w in text.split(" "):
        trial = (cur + " " + w) if cur else w
        if cur and font.measure(shape_arabic(trial) if _SHAPE_RTL[0] else trial) > max_px:
            lines.append(cur)
            cur = w
        else:
            cur = trial
    lines.append(cur)
    return lines


# ---- anti-aliased rounded shapes -----------------------------------------------------------------------------
# Tk's own polygons are not anti-aliased (jagged corners). We build small PNG corners with real alpha and place them on a
# canvas; the straight parts are plain rectangles. Results are cached, so a repaint costs almost nothing.
SHAPES = {"sharp": (0.15, 2.0), "soft": (1.0, 2.0), "round": (1.8, 2.0), "squircle": (1.5, 4.6), "pill": (99.0, 2.0)}
_AA = {}


def _png(w, h, rows):
    raw = b"".join(b"\x00" + r for r in rows)

    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, 1)) + chunk(b"IEND", b""))


def _photo(w, h, rows):
    return tk.PhotoImage(data=base64.b64encode(_png(w, h, rows)))


def _corners(r, fill, line, lw, n):
    key = ("c", r, fill, line, lw, n)
    hit = _AA.get(key)
    if hit is not None:
        return hit
    if len(_AA) > 600:
        _AA.clear()
    fr = _rgb(fill)
    lr = _rgb(line) if line else fr
    tl = []
    for py in range(r):
        row = bytearray()
        for px in range(r):
            dx, dy = r - (px + .5), r - (py + .5)
            d = (dx ** n + dy ** n) ** (1.0 / n)
            a_out = min(1.0, max(0.0, r - d + .5))
            if a_out <= 0:
                row += b"\x00\x00\x00\x00"
                continue
            a_in = min(1.0, max(0.0, r - lw - d + .5)) if line else a_out
            t = a_in / a_out
            row += bytes((int(fr[0] * t + lr[0] * (1 - t) + .5), int(fr[1] * t + lr[1] * (1 - t) + .5),
                          int(fr[2] * t + lr[2] * (1 - t) + .5), int(a_out * 255 + .5)))
        tl.append(bytes(row))

    def mirror(rows):
        return [b"".join(row[i:i + 4] for i in range(len(row) - 4, -1, -4)) for row in rows]
    sets = (tl, mirror(tl), tl[::-1], mirror(tl[::-1]))            # tl, tr, bl, br
    imgs = tuple(_photo(r, r, rows) for rows in sets)
    _AA[key] = imgs
    return imgs


def aa_round_rect(c, x1, y1, x2, y2, r, fill, line=None, lw=1, n=None, grad=None, rim=None, tag=None):
    """Anti-aliased rounded rectangle. grad=(top, bottom) fill colours; rim=(top, bottom) edge colours (glass look)."""
    x1, y1, x2, y2 = int(round(x1)), int(round(y1)), int(round(x2)), int(round(y2))
    w, h = x2 - x1, y2 - y1
    if w < 2 or h < 2:
        return
    r = int(min(r, w // 2, h // 2))
    n = n if n is not None else SHAPE["n"]
    tags = (tag,) if tag else ()
    top_c, bot_c = grad if grad else (fill, fill)
    rim_t, rim_b = rim if rim else (line, line)
    if not hasattr(c, "_imgs"):
        c._imgs = []
    if r < 2:
        c.create_rectangle(x1, y1, x2, y2, fill=top_c, outline=rim_t or "", tags=tags)
        return
    tl, tr_, _, _ = _corners(r, top_c, rim_t, lw, n)
    _, _, bl, br = _corners(r, bot_c, rim_b, lw, n)
    c._imgs.extend((tl, tr_, bl, br))
    c.create_image(x1, y1, image=tl, anchor="nw", tags=tags)
    c.create_image(x2 - r, y1, image=tr_, anchor="nw", tags=tags)
    c.create_image(x1, y2 - r, image=bl, anchor="nw", tags=tags)
    c.create_image(x2 - r, y2 - r, image=br, anchor="nw", tags=tags)
    bands = max(1, min(14, h // 4)) if grad else 1

    def paint(ya, yb, col):
        for lo, hi, xa, xb in ((ya, min(yb, y1 + r), x1 + r, x2 - r), (max(ya, y1 + r), min(yb, y2 - r), x1, x2),
                               (max(ya, y2 - r), yb, x1 + r, x2 - r)):
            if hi > lo and xb > xa:
                c.create_rectangle(xa, lo, xb, hi, fill=col, outline="", tags=tags)
    for k in range(bands):
        ya, yb = y1 + h * k // bands, y1 + h * (k + 1) // bands
        paint(ya, yb, mix(top_c, bot_c, (k + .5) / bands) if grad else fill)
    if line or rim:
        c.create_rectangle(x1 + r, y1, x2 - r, y1 + lw, fill=rim_t or line, outline="", tags=tags)
        c.create_rectangle(x1 + r, y2 - lw, x2 - r, y2, fill=rim_b or line, outline="", tags=tags)
        mid = mix(rim_t or line, rim_b or line, .5)
        c.create_rectangle(x1, y1 + r, x1 + lw, y2 - r, fill=mid, outline="", tags=tags)
        c.create_rectangle(x2 - lw, y1 + r, x2, y2 - r, fill=mid, outline="", tags=tags)


def aa_circle(c, cx, cy, r, fill, line=None, lw=1, tag=None):
    """Anti-aliased filled circle (optional ring)."""
    d = int(2 * r) + 2
    key = ("o", d, fill, line, lw)
    img = _AA.get(key)
    if img is None:
        if len(_AA) > 600:
            _AA.clear()
        fr = _rgb(fill)
        lr = _rgb(line) if line else fr
        rr, mid, rows = r, d / 2.0, []
        for py in range(d):
            row = bytearray()
            for px in range(d):
                dist = math.hypot(px + .5 - mid, py + .5 - mid)
                a_out = min(1.0, max(0.0, rr - dist + .5))
                if a_out <= 0:
                    row += b"\x00\x00\x00\x00"
                    continue
                a_in = min(1.0, max(0.0, rr - lw - dist + .5)) if line else a_out
                t = a_in / a_out
                row += bytes((int(fr[0] * t + lr[0] * (1 - t) + .5), int(fr[1] * t + lr[1] * (1 - t) + .5),
                              int(fr[2] * t + lr[2] * (1 - t) + .5), int(a_out * 255 + .5)))
            rows.append(bytes(row))
        img = _photo(d, d, rows)
        _AA[key] = img
    if not hasattr(c, "_imgs"):
        c._imgs = []
    c._imgs.append(img)
    c.create_image(int(round(cx - d / 2.0)), int(round(cy - d / 2.0)), image=img, anchor="nw", tags=(tag,) if tag else ())


def glass_colors(th, base, strength=1.0):
    """(gradient, rim) pair that makes a surface look like lit glass: bright top, soft bottom, lit edge."""
    dark = th["dark"]
    top = mix(base, "#ffffff", (.16 if dark else .55) * strength)
    bot = mix(base, "#000000" if dark else th["accent"], (.10 if dark else .07) * strength)
    return (top, bot), (mix(th["border"], "#ffffff", .55 if dark else .9), mix(th["border"], "#000000" if dark else th["accent"], .25))


STR_AR.update({
    "Remember my work when I close": "تذكّر عملي عند الإغلاق",
    "Open tabs, unsaved text, cursor positions and the chat come back next time, without asking to save.": "تعود التبويبات والنص غير المحفوظ ومواضع المؤشر والمحادثة في المرة القادمة دون سؤال عن الحفظ.",
    "New files are": "الملفات الجديدة تكون", "Show the activity bar": "إظهار شريط الأنشطة", "The icon column on the far left.": "عمود الأيقونات في أقصى اليسار.",
    "Show the status bar": "إظهار شريط الحالة", "Full screen": "ملء الشاشة", "Press F11 any time (Esc leaves it).": "اضغط F11 في أي وقت (Esc للخروج).",
    "Toggle full screen": "تبديل ملء الشاشة", "Layout": "التخطيط", "Smooth scrolling": "تمرير سلس", "Eased mouse-wheel scrolling.": "تمرير عجلة الفأرة بنعومة.",
    "Scroll speed": "سرعة التمرير", "Slow (2 lines)": "بطيء (سطران)", "Normal (3 lines)": "عادي (3 أسطر)", "Fast (5 lines)": "سريع (5 أسطر)",
    "Very fast (8 lines)": "سريع جدًا (8 أسطر)", "Auto-close brackets and quotes": "إغلاق الأقواس والاقتباس تلقائيًا",
    "Typing ( [ { or a quote adds the closing one.": "كتابة ( [ { أو علامة اقتباس تضيف المقابل لها.", "Cursor": "المؤشر", "Line": "خط",
    "Thick line": "خط سميك", "Block": "كتلة", "Blinking cursor": "مؤشر وامض", "Line spacing": "تباعد الأسطر", "Tight": "ضيق", "Normal": "عادي",
    "Relaxed": "مريح", "Airy": "واسع", "Saving files": "حفظ الملفات", "Remove trailing spaces when saving": "حذف المسافات الزائدة عند الحفظ",
    "End files with a new line": "إنهاء الملفات بسطر جديد", "Squircle": "منحنية", "Pill": "كبسولة", "Theme": "السمة",
    "Continued where you left off (unsaved changes included)": "أكملنا من حيث توقفت (مع التغييرات غير المحفوظة)",
    "Start in full screen": "ابدأ بملء الشاشة", "Recent": "الأخيرة",
})


STR_AR.update({"Python is needed to run Python files. Install it from python.org, then press Run again.":
               "تحتاج بايثون لتشغيل ملفات بايثون. ثبّته من python.org ثم اضغط تشغيل مجددًا.", "Python is not installed": "بايثون غير مثبت",
               "Download": "تحميل"})


STR_AR.update({"Type a command…": "اكتب أمرًا…"})
STR_AR.update({"Legend Code was updated. Restart it to use the new version.": "تم تحديث Legend Code. أعد فتحه عشان تشتغل النسخة الجديدة.",
               "Automatic updates": "التحديث التلقائي", "Downloads new versions quietly; they apply the next time you open the app.": "ينزّل النسخ الجديدة بهدوء، وتشتغل في المرة الجاية اللي تفتح فيها البرنامج."})
STR_AR.update({"Review AI changes": "راجع تعديلات المساعد", "Apply": "طبّق", "Cancel": "إلغاء", "No changes: the code is already the same": "ما فيه تغيير: الكود نفسه"})
STR_AR.update({"Tools": "أدوات", "Sort lines": "ترتيب الأسطر", "Remove duplicate lines": "حذف الأسطر المكررة", "Trim trailing spaces": "حذف المسافات الزائدة",
               "Tabs to spaces": "تحويل Tab إلى مسافات", "UPPER CASE": "أحرف كبيرة", "lower case": "أحرف صغيرة", "Format JSON": "تنسيق JSON",
               "Insert date and time": "إدراج التاريخ والوقت", "File statistics": "إحصائيات الملف", "Open file location": "فتح مكان الملف",
               "Could not do that": "ما قدرت أسويها", "Nothing to change": "ما فيه شي يتغير", "Lines": "الأسطر", "Words": "الكلمات", "Characters": "الحروف",
               "Save the file first": "احفظ الملف أول", "Expressive (strongest)": "قوية (الأقوى)"})
STR_AR.update({"Custom colour…": "لون مخصص…", "Custom colour": "لون مخصص"})
STR_AR.update({"Welcome to Legend Code": "أهلًا بك في Legend Code", "What's your name?": "وش اسمك؟", "Please type your name": "اكتب اسمك لو سمحت",
               "Continue": "متابعة", "Later": "لاحقًا", "Your name": "اسمك", "Used in the welcome message and by the assistant.": "يظهر في رسالة الترحيب ويعرفه المساعد."})


STR_AR.update({"Downloading the free local assistant…": "جاري تنزيل المساعد المحلي المجاني…", "Installing…": "جاري التثبيت…",
    "Downloading the model (one time)…": "جاري تنزيل النموذج (مرة واحدة)…", "Setting up the assistant": "إعداد المساعد",
    "The assistant is ready - free, private, works offline": "المساعد جاهز - مجاني وخاص ويعمل بدون إنترنت", "Setup failed: ": "فشل الإعداد: ",
    "The free online service is not answering. Press 'Set up local AI' above: it installs a free assistant on this PC (no account) in one step.":
    "الخدمة المجانية عبر الإنترنت لا ترد. اضغط «إعداد المساعد المحلي» بالأعلى: يثبّت مساعدًا مجانيًا على جهازك (بدون حساب) بخطوة واحدة.",
    "Set up the free local assistant?": "تبي تعدّ المساعد المحلي المجاني؟", "Set up": "إعداد"})


class TLabel(tk.Label):
    """tk.Label that translates its text when the interface language is not English."""

    def __init__(self, master=None, **kw):
        if isinstance(kw.get("text"), str):
            kw["text"] = visual(tr(kw["text"]))
        super().__init__(master, **kw)

    def configure(self, cnf=None, **kw):
        if isinstance(kw.get("text"), str):
            kw["text"] = visual(tr(kw["text"]))
        return super().configure(cnf, **kw)
    config = configure



# ----------------------------------------------------------------------------
#  Colour helpers + themes
# ----------------------------------------------------------------------------
def _rgb(c):
    c = c.lstrip("#")
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))


def mix(a, b, t):
    """Blend colour a towards colour b by t (0..1)."""
    ra, rb = _rgb(a), _rgb(b)
    return "#%02x%02x%02x" % tuple(max(0, min(255, round(x + (y - x) * t))) for x, y in zip(ra, rb))


def is_dark(c):
    r, g, b = _rgb(c)
    return (r * 299 + g * 587 + b * 114) / 1000 < 140


def finish_theme(th):
    """Fill the UI-chrome colours a theme did not set explicitly."""
    dark = is_dark(th["bg"])
    th.setdefault("act", mix(th["bg"], "#000000", .45 if dark else .07))
    th.setdefault("bar", th["act"])
    th.setdefault("side", th["panel"])
    th.setdefault("hover", mix(th["panel2"], th["fg"], .06))
    th.setdefault("accent_fg", "#ffffff" if is_dark(th["accent"]) else "#14110a")
    th.setdefault("dim", mix(th["bg"], th["fg"], .30))
    th.setdefault("pop", mix(th["panel"], th["fg"], .04) if dark else "#ffffff")
    th["dark"] = dark
    return th


THEMES = {
    "Legend Dark": finish_theme(dict(
        bg="#161a22", fg="#d7dce6", panel="#12151c", panel2="#1e232e", border="#262d3a",
        sel="#2d3b5c", cur="#1b212c", ln_fg="#454e60", ln_cur="#aab3c5", accent="#f2b84b",
        green="#52d49a", red="#ff6b7f", yellow="#ffd27a", cyan="#62d2ea", muted="#7d8799",
        kw="#b99cf7", bi="#7fb2ff", st="#a3d38b", cm="#576377", nu="#ff9f7a", fn="#7fb2ff",
        dc="#f2b84b", ty="#58d6c4", pp="#78cfff", sf="#ff8196", err="#3b202a", match="#4a3f1f",
        bracket="#34476f", side="#12151c", act="#0d1016", bar="#0d1016")),
    "Midnight": finish_theme(dict(
        bg="#14161f", fg="#d6dae8", panel="#1b1e2b", panel2="#242839", border="#2c3047",
        sel="#34407f", cur="#1b1f2e", ln_fg="#4f5575", ln_cur="#b3b9da", accent="#7c6cff",
        green="#3ddc97", red="#ff5c7a", yellow="#ffcc66", cyan="#5ad1e6", muted="#8087a8",
        kw="#c792ea", bi="#82aaff", st="#c3e88d", cm="#5c6482", nu="#f78c6c", fn="#82aaff",
        dc="#ffcb6b", ty="#ffcb6b", pp="#89ddff", sf="#f07178", err="#43202c", match="#4b4220",
        bracket="#3b4a7a", act="#0e1018", bar="#0e1018")),
    "Light": finish_theme(dict(
        bg="#fbfbfe", fg="#2b2f3a", panel="#f0f1f8", panel2="#e6e8f3", border="#d8dbea",
        sel="#cfd6ff", cur="#f1f3fb", ln_fg="#a3a8c0", ln_cur="#4a4f6a", accent="#5b4bff",
        green="#0f9d63", red="#d6304f", yellow="#b87400", cyan="#0a7e96", muted="#6a6f8f",
        kw="#8b3fd1", bi="#1c64d6", st="#2f8a2f", cm="#8e94ad", nu="#d2561f", fn="#1c64d6",
        dc="#a9740a", ty="#a9740a", pp="#0a7e96", sf="#c93b44", err="#fde1e7", match="#fff0b3",
        bracket="#d4dbff", act="#e4e6f2", bar="#eceef7", hover="#dfe2f2")),
    "Matrix": finish_theme(dict(
        bg="#050805", fg="#b6f5b6", panel="#0a110a", panel2="#101c10", border="#1a2e1a",
        sel="#17421f", cur="#0a140a", ln_fg="#2b5a2b", ln_cur="#7dff7d", accent="#25d366",
        green="#3dff7a", red="#ff5370", yellow="#e5ff6a", cyan="#4dffe0", muted="#4f8f4f",
        kw="#25d366", bi="#4dffe0", st="#e5ff6a", cm="#3a6f3a", nu="#ffb86c", fn="#4dffe0",
        dc="#e5ff6a", ty="#9cff9c", pp="#4dffe0", sf="#ff79c6", err="#3a1219", match="#36421a",
        bracket="#1d5a2a", act="#020402", bar="#020402", accent_fg="#03140a")),
}


def _mk_theme(bg, fg, accent, kw, bi, st, cm, nu, fn, ty):
    """A full theme from a 10-colour palette (the other colours are derived)."""
    dark = is_dark(bg)
    red, green, yellow, cyan = ("#ff6b7f", "#4fd69c", "#ffd27a", "#62d2ea") if dark else ("#d6304f", "#15803d", "#b87400", "#0a7e96")
    t = dict(bg=bg, fg=fg, accent=accent, kw=kw, bi=bi, st=st, cm=cm, nu=nu, fn=fn, ty=ty, dc=ty, pp=bi,
             sf="#ff8196" if dark else "#c93b44", red=red, green=green, yellow=yellow, cyan=cyan)
    if dark:
        t.update(panel=mix(bg, "#000000", .22), panel2=mix(bg, fg, .08), border=mix(bg, fg, .14), sel=mix(bg, accent, .32),
                 cur=mix(bg, fg, .045), ln_fg=mix(bg, fg, .32), ln_cur=mix(bg, fg, .72), muted=mix(bg, fg, .56))
    else:
        t.update(panel=mix(bg, "#000000", .035), panel2=mix(bg, "#000000", .07), border=mix(bg, "#000000", .13), sel=mix(bg, accent, .25),
                 cur=mix(bg, "#000000", .035), ln_fg=mix(bg, fg, .40), ln_cur=mix(bg, fg, .85), muted=mix(bg, fg, .62))
    t.update(err=mix(bg, red, .18 if dark else .14), match=mix(bg, yellow, .28), bracket=mix(bg, accent, .30))
    return finish_theme(t)


for _n, _p in (
        ("Graphite", ("#1c1c1e", "#e5e5ea", "#0a84ff", "#bf5af2", "#64d2ff", "#30d158", "#6e6e73", "#ff9f0a", "#64d2ff", "#ffd60a")),
        ("Apple Dark", ("#1f1f24", "#dfdfe0", "#0a84ff", "#fc5fa3", "#5dd8ff", "#fc6a5d", "#6c7986", "#d0bf69", "#67b7a4", "#5dd8ff")),
        ("Apple Light", ("#ffffff", "#1d1d1f", "#0071e3", "#ad3da4", "#0f68a0", "#d12f1b", "#707f8c", "#272ad8", "#4b21b0", "#3e8087")),
        ("Aurora", ("#0f1b1e", "#d6ebe8", "#38e0b4", "#7ee0ff", "#5fd0c2", "#b8e986", "#4f6b6e", "#ffb86b", "#5ee6c5", "#ffd36e")),
        ("Ocean", ("#0c1824", "#d4e4f2", "#4aa8ff", "#79b8ff", "#56d4dd", "#9ee493", "#4d6680", "#ffab70", "#82cfff", "#f9c97c")),
        ("Sunset", ("#1d1520", "#f1e0e0", "#ff7a59", "#ff9ecb", "#ffb86b", "#ffd37a", "#7a5f73", "#ff7a59", "#7fd1ff", "#c4a1ff")),
        ("Forest", ("#121c14", "#d8e6d2", "#7bd45a", "#c5e478", "#6fd3b0", "#e6c86e", "#5a7258", "#f0a05a", "#7fd1f0", "#e6c86e")),
        ("Dracula", ("#282a36", "#f8f8f2", "#bd93f9", "#ff79c6", "#8be9fd", "#f1fa8c", "#6272a4", "#bd93f9", "#50fa7b", "#8be9fd")),
        ("Nord", ("#2e3440", "#d8dee9", "#88c0d0", "#81a1c1", "#8fbcbb", "#a3be8c", "#616e88", "#b48ead", "#88c0d0", "#ebcb8b")),
        ("Monokai", ("#272822", "#f8f8f2", "#a6e22e", "#f92672", "#66d9ef", "#e6db74", "#75715e", "#ae81ff", "#a6e22e", "#66d9ef")),
        ("Solarized Dark", ("#002b36", "#93a1a1", "#b58900", "#859900", "#268bd2", "#2aa198", "#586e75", "#d33682", "#268bd2", "#b58900")),
        ("Amoled", ("#000000", "#e6e6e6", "#00e5a0", "#c792ea", "#82aaff", "#c3e88d", "#555b66", "#f78c6c", "#82aaff", "#ffcb6b")),
        ("Solarized Light", ("#fdf6e3", "#586e75", "#268bd2", "#859900", "#268bd2", "#2aa198", "#93a1a1", "#d33682", "#268bd2", "#b58900")),
        ("GitHub Light", ("#ffffff", "#24292f", "#0969da", "#cf222e", "#0550ae", "#0a3069", "#6e7781", "#0550ae", "#8250df", "#953800")),
        ("Paper", ("#f7f1e5", "#3b3226", "#c4572a", "#9c3d54", "#2f6f8f", "#4d7a3a", "#a39a86", "#b5651d", "#2f6f8f", "#8a6d1f")),
        ("Sakura", ("#fff5f7", "#4a3340", "#e5517f", "#b83280", "#3182ce", "#2f855a", "#b08a9b", "#dd6b20", "#6b46c1", "#b7791f")),
        ("Lavender", ("#f6f3ff", "#2d2745", "#7c5cff", "#a23be0", "#2563eb", "#15803d", "#9a94b5", "#c2410c", "#2563eb", "#a16207"))):
    THEMES[_n] = _mk_theme(*_p)
THEME_ORDER = ["Legend Dark", "Midnight", "Light", "Matrix", "Graphite", "Apple Dark", "Apple Light", "Aurora", "Ocean", "Sunset", "Forest",
               "Dracula", "Nord", "Monokai", "Solarized Dark", "Amoled", "Solarized Light", "GitHub Light", "Paper", "Sakura", "Lavender"]
THEME_ALIAS = {"Daylight": "Light"}
TAGS = ("kw", "bi", "st", "cm", "nu", "fn", "dc", "ty", "pp", "sf")

# ----------------------------------------------------------------------------
#  Settings (same file as v1; new keys are simply added)
# ----------------------------------------------------------------------------
DEFAULTS = dict(
    # general
    theme="Legend Dark", animations=True, lite=False, fullscreen_start=False, hot_exit=True, new_lang="python", smooth_scroll=True, scroll_lines=3, cursor_style="line", cursor_blink=True,
    line_spacing=1, auto_pair=True, trim_ws=False, final_newline=False, show_status=True, show_activity=True, anim_level="expressive", accent="auto", colorful=False, shape="soft", glass=False, opacity=100,
    ui_lang="en", greeting=True, tips=True, shortcut_offered=False, font_size=14 if IS_MAC else 13, font_family="", autosave=True, autosave_secs=15, confirm_exit=False, user_name="", cfg_v=18,
    startup="restore", geometry="1360x840", maximized=False,
    # layout memory
    sidebar_open=True, sidebar_view="explorer", sidebar_w=260, panel_open=False, panel_h=220, panel_tab="Terminal",
    ai_open=False, ai_w=410, folder="", files=[], active=0, recent_files=[], recent_folders=[],
    # editor
    tab_size=4, word_wrap=False, line_numbers=True, highlight_line=True, autocomplete=True, bracket_match=True,
    # python / c++ / run
    python="", cxx="", cxxflags="-std=c++17 -O2 -Wall", cflags="-std=c17 -O2 -Wall", unbuffered=True,
    autosave_on_run=True, clear_on_run=True, run_args="",
    # ai  (provider: auto | free | ollama | anthropic)
    ai_provider="auto", ai_key="", ai_model="claude-sonnet-5-5", ollama_url="http://localhost:11434",
    ollama_model="qwen2.5-coder:7b", free_url="", free_model="", ai_reply="Arabic", ai_notice_seen=False,
)


ACCENTS = {"amber": "#F2B84B", "orange": "#FF8A3D", "rose": "#FF6B8B", "violet": "#9B8CFF", "blue": "#4DA3FF",
           "cyan": "#38C8E0", "green": "#43D18B", "lime": "#A6D94A"}
HUES = dict(files="#F2B84B", search="#5AB0FF", run="#43D18B", ai="#B497FF", gear="#FF7B95", home="#38C8E0")   # 'colorful' mode
BOOT_PATH = os.path.join(HOME, ".legend_code_boot")


def _clamp(v, lo, hi, d):
    try:
        v = int(v)
    except Exception:
        return d
    return max(lo, min(hi, v))


def sanitize_config(cfg):
    """Settings from an old or damaged file must never be able to stop the app from opening."""
    for k, lo, hi in (("scroll_lines", 1, 12), ("line_spacing", 0, 8), ("font_size", 8, 40), ("sidebar_w", 180, 700), ("ai_w", 300, 800), ("panel_h", 90, 700),
                      ("autosave_secs", 5, 3600), ("opacity", 60, 100), ("active", 0, 9999)):
        cfg[k] = _clamp(cfg.get(k), lo, hi, DEFAULTS[k])
    if cfg.get("tab_size") not in (2, 4, 8):
        cfg["tab_size"] = 4
    for k in ("files", "recent_files", "recent_folders"):
        v = cfg.get(k)
        cfg[k] = [p for p in v if isinstance(p, str)][:40] if isinstance(v, list) else []
    if _clamp(cfg.get("cfg_v"), 0, 999, 0) < 18:               # v18: the new Expressive motion is the default
        if cfg.get("anim_level") in (None, "smooth"):
            cfg["anim_level"] = "expressive"
    if _clamp(cfg.get("cfg_v"), 0, 999, 0) < 13:          # v13: autosave on by default, forget the dead free model
        cfg["autosave"], cfg["autosave_secs"] = True, 15
        cfg["free_ok_url"] = cfg["free_ok_model"] = None
        if cfg.get("free_model") in ("qwen-coder",):
            cfg["free_model"] = ""
    cfg["cfg_v"] = 18
    for k in ("folder", "geometry", "python", "cxx", "cxxflags", "cflags", "run_args", "font_family", "user_name"):
        if not isinstance(cfg.get(k), str):
            cfg[k] = DEFAULTS.get(k, "")
    for k, v in DEFAULTS.items():
        if isinstance(v, bool):
            cfg[k] = bool(cfg.get(k, v))
    for k, opts in (("ui_lang", ("en", "ar")), ("new_lang", ("python", "cpp", "c")), ("cursor_style", ("line", "thick", "block")), ("shape", ("sharp", "soft", "round", "squircle", "pill")), ("anim_level", ("subtle", "smooth", "expressive")),
                    ("startup", ("restore", "welcome", "new")), ("sidebar_view", ("explorer", "search", "run")),
                    ("panel_tab", ("Terminal", "Output", "Problems", "Debug Console"))):
        if cfg.get(k) not in opts:
            cfg[k] = DEFAULTS[k]
    if cfg.get("accent") != "auto" and cfg.get("accent") not in ACCENTS and not re.fullmatch(r"#[0-9a-fA-F]{6}", str(cfg.get("accent"))):
        cfg["accent"] = "auto"
    return cfg


def sane_geometry(geo, sw, sh):
    """A window saved off-screen (closed while minimised = -32000,-32000, or on a monitor that is gone) would look like
    'the app does not start'. Always bring it back on screen."""
    m = re.match(r"^\s*(\d+)x(\d+)(?:\+(-?\d+)\+(-?\d+))?", geo or "")
    w, h = (int(m.group(1)), int(m.group(2))) if m else (1360, 840)
    w, h = max(980, min(w, sw - 20)), max(560, min(h, sh - 80))
    x = y = None
    if m and m.group(3) is not None:
        x, y = int(m.group(3)), int(m.group(4))
    if x is None or x < -10 or y < -10 or x > sw - 160 or y > sh - 120:
        x, y = max(0, (sw - w) // 2), max(10, (sh - h) // 3)
    return "%dx%d+%d+%d" % (w, h, x, y)


CHAT_PATH = os.path.join(HOME, ".legend_code_chat.json")


def load_chat():
    try:
        with open(CHAT_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        return [dict(role=m["role"], content=m["content"]) for m in data if isinstance(m, dict) and m.get("role") in ("user", "assistant")
                and isinstance(m.get("content"), str)][-40:]
    except Exception:
        return []


def save_chat(msgs):
    try:
        with open(CHAT_PATH + ".tmp", "w", encoding="utf-8") as f:
            json.dump([dict(role=m["role"], content=m["content"]) for m in msgs if m.get("content")][-40:], f, ensure_ascii=False)
        os.replace(CHAT_PATH + ".tmp", CHAT_PATH)
    except Exception:
        pass


def boot_begin():
    """True if the previous start never finished (hang / crash / killed) -> this start runs in safe mode."""
    bad = os.path.exists(BOOT_PATH)
    try:
        with open(BOOT_PATH, "w") as f:
            f.write(str(time.time()))
    except Exception:
        pass
    return bad


def boot_end():
    try:
        os.remove(BOOT_PATH)
    except OSError:
        pass


def start_watchdog(seconds=12):
    """If the UI thread has not finished starting after `seconds`, write where it is stuck to the crash log."""
    done = threading.Event()

    def run():
        if done.wait(seconds):
            return
        try:
            fr = sys._current_frames().get(threading.main_thread().ident)
            with open(CRASH_LOG, "a", encoding="utf-8") as f:
                f.write("\n--- startup is taking too long (%s) ---\n%s" % (time.ctime(), "".join(traceback.format_stack(fr)) if fr else "?"))
        except Exception:
            pass
    threading.Thread(target=run, daemon=True).start()
    return done


def load_config():
    cfg = json.loads(json.dumps(DEFAULTS))
    saved = {}
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            loaded = json.load(f)
        if isinstance(loaded, dict):
            saved = loaded
            cfg.update(saved)
    except Exception:
        pass
    cfg["theme"] = THEME_ALIAS.get(cfg.get("theme"), cfg.get("theme"))
    if cfg["theme"] not in THEMES:
        cfg["theme"] = "Legend Dark"
    # v1 defaulted to "anthropic" even without a key -> make it work out of the box now
    if cfg.get("ai_provider") == "anthropic" and not (cfg.get("ai_key") or "").strip():
        cfg["ai_provider"] = "auto"
    if cfg.get("ai_provider") not in ("auto", "free", "ollama", "anthropic"):
        cfg["ai_provider"] = "auto"
    if "explorer" in saved and "sidebar_open" not in saved:
        cfg["sidebar_open"] = bool(saved.get("explorer"))
    return sanitize_config(cfg)


def save_config(cfg):
    try:
        tmp = CONFIG_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=1)
        os.replace(tmp, CONFIG_PATH)
    except Exception:
        pass


def push_recent(cfg, key, path, limit=8):
    lst = [p for p in cfg.get(key, []) if p != path]
    lst.insert(0, path)
    cfg[key] = lst[:limit]


# ----------------------------------------------------------------------------
#  Language knowledge (snippets, templates, keywords)
# ----------------------------------------------------------------------------

# Legend Code window / taskbar icon (PNG, 32 / 64 / 128 px) - embedded so the app stays a single file
LOGO_ICON_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAECUlEQVR4nO2Xz4+TRRjHP8/MtN3+gO4PQZASAn+A/gfGePDAwR/x4kkvhnjAE54IetIrJyGS6MmDMSZAiNFEBUXJxptkD2JWEsOyxcBSurvtltK+8zwe2i5laXfZlqPfZN6kfeed72eeeeaZjPCoPBB7P4rFA5O2IzrGkNScrawsVId5yMYXMzP7nzNv74rIK4IcNLOwod92ZAgqyKKaXXKqn9+9W/67H6I3sAfi9HTpDTxnnPO7Wq0WSRJHt96gTDqNiDRM47Fq5dZnPU/h4cxfw3MeIElie++zM35nsSAWFWR0CjMjeG/lf+9ord4IIaRINB5dXlo8BXgBZPfug7sTa18DmfRe9F511X/x6Qneeft16tUVvPfjmLNSW+PFw0co31rSdDplZiaWyPPV6s0/HWCJtt8T56bAEpDR3AZI1UjvyPH9j7PMX19gYiLjzMzEOYfXDwBzAIYdxsyAsTJ+o0RAW22+OX+REAJgAN7UTJCXS6VS1k0dOlQU5IAZ8jQBVI1sLsvc3DxXfr9KIZ8lRu2+NUFsz/37/oBLms0w2NiGNrOtW4wRl0nx9bmfWK2tEcJjKyuq6oM4ZwOnIAFcutse/TiIITL4MwAzyGTS1CorXPjuV3K5/tn3WYhYGDyEQGsZGmWsUcP6doGIUWunaUU/dHfGqOR3Frjw7S9c/2eR4s78QACAxwFMwU+g5R9g7g9iLQHXcYpqFAue42du8+WlZaYKnqhDAuiEer1BPjcx1HwwwBYSEeprDSqVZbQVhgIAeO9wIgzvMQJAZ2BPSAVSqYDbBACzTc1HBtiY8ePoqRae/wFG0Ug5IHTqfK89iYalykgAUY0kMdqJbboN180B76RXTsYDMIN81jNTDEwVNq8D6+YiNB5Emi17LGLbAvBOWLsfOf7WXo69uWfL8HfModk2Xv1onht3WmRS8shyjByBHbmt+0Y1CoXA2csV5hebTA6I2Mg5EJ+g/kQ1Ylv56ud7Q/t0j+MnyKQ+yfpjuNQgP+H5a6HJ5bkahezgg8utLCwsg93qnhnj1dV+ADXSGeHslXtUVhNSoZ9YMFgSWbvpuqYXERFg+Lm5TaWCUKtHzs1WyWYEfTj7KE4Mk9lKpVJzAMH506b6gE5gx4aIauQmPJeurnLtRpNs2vUWufs0welJuoYeiFPP7DvivD+DqSXR4p7plC/mQz/5tuSdcLvaplpPCE6wzlVMnHM+avy4ulT+kO7FhB7E9K7SUeCkcy7VaitJVMa5FqaCI/jOhMUJmKGmn1SXyifou5qtQwNxcte+FwT3vhN7CdjX/X/bEjo1wzAFuQ0yq8bp5bs3f6NzCGqvX7/Wb62lUinbbOp+DSHQGgWhCyKiUC9XKpXaRg+A/wCB9gwxHhKXbQAAAABJRU5ErkJggg==",
    "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAJD0lEQVR4nO2be4xcVR3Hv79zz7137p3Zmel2y0MarFtMKhVKXFRK09wGqBiLEqPTiGmTkhhQkIc0Mcof4sYY/EPFpGh4yB+ISN0trW6ssdDQTloppW6BhW5fulihJdvHPud97zk//5jZdlt3tzM7s4+J/STnj3mck3O+53d/53fPOT+gfAiJhOF5ngQgKqg3XRA8TyYSCQMAlV+pHBIJA+3tavRXTz/9D7Oj47nIYGWdrDkxAM3NizJPPvlwnpnP/VDsswbA49UFLi6AKDXAzCyu++zK5dn00Bf9fG6p0sHVrFUcTGWrPSUQmEgMCUMetyx7nxtq2PaZO9fueL717lzxD48JoFWPX31cEgbQrkgIfOq65etSqf6HC/nsEhX4UEqBedw2ZwQigjAkpCFh2s6RcDj21MoVid9s2PBQfmQsY9Yb60vP82QymQxu8r58Te+J489mM0MrCoUcWGsNIk1EVKo7s7N/jhErZTALEAnLCiHkRN6Jz7v8nnfeeOXNkTFdWPF/B+B5EslksLjl1hVDfb0vZ9KDjUqpQAghMDud31ho1lqTEDLkRvPR2Lx1h7qSG8cS4XwBSs7u0zfc5vX3H/9rJj3oAhQQkZzW7tcOpbU2XLcB0Tnz7jrUtXvjhQ59lACPCaCVP7c8seDEB91vpVP9MSKhABgz0PFaorXWCIdjmHvl/Ju79r66d7QI55k0M6P3o6MvZDNDMSIKUP+DBwAhhOBsdkgMnOr9w8qV68Nob2eUJr8ogOdJoFVfu2TFmnw2tUwpFQB1a/ZjYTBzkMummo8df/0RABqeZwBFAQjJpGprYyM13PeDQiHHQojZ4t1rBpEQvp/nTHrwwdsS98RQdIYkkEgIAPyTn916s1/IXcusGRWaPhHBMMS0F1FZDCYA1r6fbzpx8OAdAOB5niFbenpEJ6Ay6aE7lAoYII0KljsiQj5fQL7goxgeTBh51ggCM8OUEo5j47wQeKJaRKyUz+nc8FcAvJhMArKzs1MBBN8vLNU6oFKQU26D8P0AC5vnY8HHr4LyA0xHYMwMGKZEb+9pdB96H6YpyxSBhNaagqDQ0tbGxurVFEgAescOLdesW3x1qZGyh2AYAmf60vjm12/H9x+9H2pwAIac+oVDKwURjeKB+36Mffu70TgnBqXGjHQvhJgZrNQVv3jqriYAvRIAfvj4t6KsdYyZUYkFAEUrKBR86EIGqXQGcooFYAYsy8TxA0ewqeM1NERcaF3W4EdagGYOB9m+ORgRQJpWVQ8uEUEIcbZMJUGgYEVcbOp4Db0n+zCvKY4gqESAIkTEQP3E9mcxpYHM4DDat2yHE7KhdXVvpXUlgFIaoYiL5O796DrwT7huCFpXt+rUlQAAA0R4adM2KK1Robsak7oRQGtGyAmh5+gxvLJjLyLhSp3f2NSRABrSCeGPW7bj5Ol+WJZEmfHPhNTohYcvKOOjFIPBFW0lMQNCEIb7BtG2ZTvcUKhq5zdCbQQgCQi7VCaOAyIREzCosohZKcCJYuvmv+DAoR7EYw3lBj4XpToBmEGGDT69DzjwK6iBPMiYeG5/tCWNE30KlgSYy7MDzRqmbWPvm12wLbNmsw9UbQEMkATnTgH974IHFfgiArS9/B4Ov5+BGRKoZAVjzXDdEGzbKvvlpxxq8AgwQCYgXUAGRfOegHg8imijCceuTABC0RHqGg4eqKUTZF0qEwuglEKgFJTiigSYKupmGZwqLgkw0x2YaS4JMNMdmGkuCTDTHZhpLgkw0x2Yaab9/E8IwBAEQxCoykiQufpoctoFSGU1htMB/KCyd4HzITAYpkFwbFHVxsi0C7BscQTzmyzYJk2648yAlITePh/d/8nClJNva9oF+PV3F0CU9kMmu6UZaIYdkbj/5z3YdySNxgYJNUkFpl2ATL66zQxmhmUKHO3JYPPf+9HgiKq2xqffCVa5kx1owHUENu/ux8n+AE0xiUBNXoC6WwZNgzCcUti0qw8hi/6/DkaUZriOgWTXMN59Pwu3wm21sagrAQCACNi48wyUZlAN7mnWjQCaAcc2cPSDHLa/NYRIlc5vhPoRQDNsm9C+qw+nBgJYUtTkMo4EgMAvVHXvVzMQKC6a5RRckWEGBBEGhgJs2tUHx67e+XHpUEICwO1Lv5d69vCeYSKKocIYhRlwLAEZk2hkQFxkW3xSndUMikh0bD+NA8eyiIcl1KQFIBBR1g43DhU/AUREPP8Ti/dkUoM3MXPZ12MFAbkC44aFLpZc46JQqM2R9YUwMyxL4I3uFA5/mKsmjNYAhONGj6169HeffObeG33Z0tIiOzs7fSmtfUIYn1fK53INQDNgW4T9/0rj9e7UlN4QYwbckKjqHQKAJiFImuY7z9x7ow/AkJ3NzRqdnXAj0a3Z9NADQVAQlcwiM+BaApFQVR27KERFR1jNo8+sIQ2bHKdhKwB4nkeilFdDtyz76k5phf5duiVWUcA+2glOVQmqP0liAIaU1vCcKxb8CQCSyaQq5gR5nrFhw0P5cDj+hGmGiLmGx6+zBGZWUtrkhKPP7Xn19yeLaTTgYhyQTCoA4vqvPfiUHQofIBISQG0O4GcHGmDDDrmn5l/W/FMAAmjXwLlAiIEEtbeuLsQv/9hax23wtdYVPwqzFNZaaceNUnzuvLuTyZdOI5E4e6l5VCTYrpBIGF17/vZWNNa01nUbREmEerYErbXSIadBRiKNj7zXuXPrBCkzJUpJU4uu974xNND7QjY7LMEcEImKMjJnGC7FM9JxI4hE564/8t7rvxwZ2+g/Tpg2t6Rl5bL+gZO/zWWGF/l+DgBUKWNuNqXMjVBKndMMhpSmDdsJn2hobLrvYOfOPwOeBMpJmztLMdlwzZr14Tff3rM+kx78tp/PXRkoH1opTE9eQCUQhDBgSAnTsvtdN/5801ULHy96fBgY51G+yCyey7hcteo7c3o+fHdVLpv5kl/I36hVcKVmHZkNhiCIMmQYvaa037ZD7rbLrlrQsWvbix8Vfx0/axQor/cEJMToRtqYjSe+sHZukD0TBwAuOstpp+ALtm0boXB4+Jab7jzT2rq6cO7XhFFa6mpmqlRKnZ/NqXQVp/f/F/P2VfIgzgibAAAAAElFTkSuQmCC",
    "iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAQlElEQVR4nO2deWwc133Hv++9OffgTUpKbBdI0SBRJNuIzdhu7G6rRJZay4CBYFIgSA//kRR14/5TJGiKOgyB/tEWLdo0SNEzCNq6cjRuXSmWLCk+tI5iSaZsy5YrX6p80ZYoiVwee8689379Y3d5yNTBY5dD7nyAJbTL0cxwft/3O9777QwQ09KwFjtu1KGVPoFGwABPZDIZA54nAPCVPqEIw+vXyqteq4YPlEYdgHmexwHA93116S8HiPjxHQ+0540iKRm2tDcQhklKJtiGhFP2/b8pfXSLAZ7JHOLZbFahAR5iuS8+8zyPzzb6jh1fT5ydOL9JBaU7wiC4WZO+QYXheq3VBhDFwYAAMAYGNmVY9mlGmBCm/YJhWUfttPvS0YP+WH1Tz/OE7/sEQC/X4Zfr8s8x/PbtD9ojuTPbgrB0nwyDLwTl4g1ShpBhBUpJaK2glARjDGs07C0IIoBzDiFMMM5hWjYMw4JpOaOW5Rw2LGe3k2zfd+zpR0aAaSFoLMPFW7IAaiejAOC22+5dV9bB71cqhd+slIufKhfzCIISlJIEgmKMAaz6s2b9mBmIiAggEBGBwLkQ3LRsOE4KtpMccZzkTywr9b3jRx57FZh77RfLkoyQyWSMbDYrN3qeZb4z+a1KufhgsTjZV8jnoMJQgzHNOecAqyV+8Wi/dhiqmtCatAYXQriJdrip9sB1Ug9z03ro5aN7PwAGODBIWOTFXawAWO2lb7xj2zZZKv91fmr8M4WpMUgZSsEFB+M8NvhyURWD1koxxo1Esh2pdOf5hJv+s5eG9n8fAOB5AovwBosRAEctCbmpf9t3C4XxgYnceQSVkhRCCICz2PCNoiYEJRUXhtHRtR7JVPsuh+OBoaGnRhcTEhZUkw8MDHAAevOd93RuuuUL+yfGzw9cHHlfy7CihWEaAIuN31AIABgXpgEQjV4YlmOjZ79cCNSRm2/d3u/7vspkMsZC9njNHmBgYIAPDg7qzXd+pVMVPjwwMTbSn5/KhUIY5kL/jJjlgkGpUFp2wujqWZ9zU13bThx5fKiem13bHq6N2sivGj938Wx/sTARCmGa8YhfaRi0lsowLNHdd33OTXVsO3Hk8aFrDQfXEgIYAOrvv697lvFlbPyoQODcEFKGevT8+52l/PiBm26/+3O+76tayL4iV92gNqVLRTXxyMTYSH3kG7HxowSBc8GlDNXYheHOSqn0k9u23LtucHCQcBUbX/GXmUzG8H1fbe7f+t3i1PgXqzE/HvnRpDpzFAYVOZm70Jcfz/979XPvimH+sgLwPE9ks1l58+33fLFcmPxObmxEVRO+2PjRhcCFYRTy47I4Nb71xlvv/g7gq9rK4rxcTh0MGGAbvVMGvXnu5MXzw5+UYUUzxuOl3NUBERH19F2v2jv6Nh9/bs8b9Sru0g3nNWg17g9q8U7um8X8xCeDSkkyJmLjrx4YEdHU5KhZLE3+HQAMDl5mw8t9dktmR3d+LPfGxZH3OonoctvGRJZqedjTd71IdvZsefm5fc/MVxp+ZFRnMhkBgMJC8Afl4lSXlKGqzvDFrC4IAEN+KoewVHwIAHx/40cSuEsFwLLZrLrd89xKJf/bhfw4CWHEizqrFM6FKJfyVC7l7+r/tXs/AwzqS+cG5ryp1/zhcGFLUCl/QoYhzSzlxqw+CABUUC4axcni/QBw6NChywugTrlc8srFPIExHY/+1Q3ngpdLeYSV4o7t2x+0a72FM7+f9W/m+766cetXk2FY3hoEZcY5v2z9GLNaYFzKkJQMf2lk8t3NAGh2GJheOhwYGGCDg4NkFyY/PRVU1ikVEudGU5d3DSFaqtZQSqNWYTWQWhiolA0dFO8EcLwWBjQwSwD1Dyth6ZelDAQACdCC1paXdJpEuDg2Xrsga71ZlIGI0JZOwjSNhouAMcbCoIxAhncB+NtsNjt9wGkD1z+UYdgvg6BpPZuMMSilkXBtfONrHlzXgdbL1vUcSYgIlmXiYX8/zrz9AWzbaqgIGONMygAyDDbd7nnuUd8vozbKZo9wAgCt1ceVkmhm7a+1huPY+JM/uh9OdwcQhmu3+NAasGxceOd9fP8fd8EwmpJmMa0VSKt1KcACUEIt2NYFwADQ7Z7njr02vE5rVf+sadRDQDcRwlCu2a5xKRXaezrx9//6Xxj+YAR9fV2Qckmd3ddEtb9YWaMjhY8BmKjnfHM9wARcpeT1WodgjDfdAoYQMAwBIlqzAjBNgcLEJHbvyyKZdJsU7hgjTVpr7XJF1wF47dSpUwy4ZB7AME1iYGFLpeJNRCoNJ51C9vCLePW1M0gkXGjd7GSXh3PezbNFbP0GIRigwhD/8m+7axnWClQ6RHPsu0YzreihtYaddHHylTeR/fmLSCUTUGrlq51YAE1Ca4KwLex67ElMTuablf1flVgATYCIYFsmxs5dxGN7s0hGZPQDsQCaglIaViqBA08dxekz78Nx7CZMAV8bsQCagOAMKpTY+ehB8IjdEyEWQIOZSf7ewM+OvIRUKjruH4gF0HCimvzViQXQQKKc/NWJBdBAlNKw0slIJn91YgE0EMEZZKWC/3z0QOSSvzqxABqEUhpOKomh50/i6exxpNOpyLl/IBZAwyAicNPAzv/+KSqVAEJEc4klFkADICI4joVz753F3gOHkUy6kRz9wKyWsEhAeua1TIuSmqo3YmwarNr04bal8PjBvXjnvbPo6e5oStPHYoiQABhgJgEzBUAuW0da0kLVz9V7TRtNXW2cYeejB2GZZuQy/9lEQwCMARRCDx+AziegpVpyRxARYHDC0EgHxkoWDNYcI2hNsF0bb7zxNl448TqSiei6fyASAqgNTR1UBTApoCUt2QFoDbgux7f/9DSeGppEMmlANbP7hgEJ1wFFsPSbTQQEUKceAgyALcNdxDUAkyORSMJJSaSaLQBgVbS3R0gAmJUELoOhanfP1VrPekV7NK4EcRnY4sQCaHFiAbQ4sQBanFgALU4sgBYnFkCLEwugxYkF0OLEAmhxYgG0OLEAWpxYAC1OLIAWJxZAixMLoMWJBdDixAJocWIBtDixAFqcWAAtTiyAFicWQIsTC6DFiQXQ4kTrm0ENQHAGQ1RfUbsDvdLU3K+uz8OaFgBjwHhBojgRIpCAitB39YiAtoSAabAVFcGaFQBjQCAJ99/di1/ZlIZjcUTlq4GkCZbJsfOZUZw5V4FtrpwI1rYAQsLvbu0BDFb7wmkEYgARYHGc/bCMH+wZgbHCWdiaFQAwEwJWOs7ORipCd7uJf9h7AcMXA/R1mJBq5U5wTQsAqCaBUcIUHBN5iT1Hckg6HCudlsRlYBNRmpBKcDx7cgr/+24JCZtDr7B7igXQRBgYQkn44YGLtWxk5b1TLIAmoTUh4XC8cqaIZ09OIuWKpt+yZj5iATQJTYBpcfg/G8NkQcGIyJ1DYwE0ASLANjkujAXY/dw4kk40Rj8QC6ApKE1IuAIHXpjE6Q/LcGwemdI0FkAT4IwhDDV+nB0Fj9hd42MBNJjZyd/hV/ORSf7qxAJoMLOTv4mCjEzyVycWQAO5NPlLRSj5qxMLoIFEOfmrEwuggXDOUAk0HjkUveSvTiyABqE0IeUKPP96Hs+cmEQ6ET33D8wvgOid5SqECBAC+HF2DJVQR2dVks19cMIcAcgwZARa80vEjYYIcCyO4fMB9j0frZk/xea2AMx+w7hTCTkX44zxNqLmt9AoTdOvqDVwLgSpCOmkiX3PT+Dd8wF62owVbfoAAFZ9BEtoajEOABs3biRgRgAEgD+3Z8/Up26864wQ5g1hWKGlPrZlYSdYbZJMJY1leWLIilGzM2PAI9lRWKLJD62aFyLGGTMMs5jo7TwNAIODg3MEANRHO2fjjDc3N2QMCCXhmZen0J4QkGr1CkATwbUFXn+vhBffKiAZkZk/xjgY41MhiTmPL5sWQCaTYdlsFqZhDVmWfV+lXCDGGv+ka6Jq21a+rPHVP/+/NZWBJiJS9xORNk1bcMM69dyeH06hmvtpYJYA+vr6qi7BNI4JwyQQeNUpNOcvYACSDo9Ck8yysdL9fnWINBmmBcs0jwJAJpPh2Wx2rgB839cAYKfTL5kTuXEuRGeze6l17Tk/McsJAwjcshMwLSsLzAx2YG4ZSAD40YN+zjSdI6ZpExFFRMMxi4eIC8EN0zzLkqkXgJnBDlwyD5DJZDgAMi3Hd9wUo6j4sJhFo7VWtpOEaTpPvvCkP+F5nsAsPztHANlsVgEAs9v2Wo57kQvBETvlVQwDiLjjJslx3R/Nt8Wl9R55nidOHPYv2HZydyLZxrRW0XzqccxVIdLatB1mO4nX09bnngXAfN+fY8+PFPy1GSJm2+5fJZJtFVadFIi9wKqDQWtF6XQXcxKpv8hmB6XneR+x97wZvud5wvd9temWLT/KjZ77ncJUTnIu4jWCVQQRacMwWc+6G94MNyRuOr1/f4jp56nOMO+Un+/7BIC5KeePk8n2HOdG7AVWFQykNbV19DLLTvzh6f37K57nzTupc7k5X+15Hh/K7jvnJtse6ujq40pJtaZmadYsDEqFMtXWKRLJtP/y8/sP1j36/FtfgUwmY2SzWbnps1seHR8796WpyTEphGnEziC6EGltmDbr6bv+beY6/aeOHhzHPK6/zhVXfWplIWMJ92vpjt63bTthaB17gqhSW8JHZ9d6mE7qK6eOHhwDBoArjNirLfvRwMAAO3l4b84xE1/u7FmfMwxLaK10LIJoQVV0d+913E6kf++VY/uOVSd9Bq84m3dNVqzHkJvv2NFfyo8fGD3/fqeUoeJciDgcrDx14/f0XSeSbd1ff/nYE/9cD99X+7/XPIzrO5wWwYXhzjCoSCGMOCdYMRhIKwUG3t17HVuo8at7WADTIrh1e38lLO6eyJ3fUMiPSyEMsdB9xSwdraQ0bdfo7Fov7UT6gZNDBxdkfGCBbeHZbFZ6nidOHN8/lGjrvqWr9+MHOrs3GESaaa3j5LAZMAYirZWSOtnWbfT23fCWm+741cUYH1isxTxPoFZXbu7f+t1yMf/tqYmLVrmU1wyMGBccoFgNywljIK211oosyxFtHb1IJNsfCXnqG68P/c/olWr9K+52CadUnx2kW++4Z1OpUv7LSmnq1/NTOZRLeQCQnHMOcB7nCIuFoVrZawXSwrRdlkp3wU2kX7Vs91snjj3xBDCTpC/2CEti9sFv+fy9W8ul4jdLxYktQbkoSsU8lAoJBMU4Y9XW5Hq752pt+2wUVP9BRJqIiEDgXAhuO0k4bgqOm3rFsd3vVX4h/R+nfD8ABjgwuKQ+quUywrQ3AIDb7vzSjcXS5G8FleJvSBlsrFRKCIMyVBhAaQWAQFrHcwnTULVxn3HGOYdhmDBMB7btwjDtYdN2f+q4iZ2f+Jjz9PRInxWGl8LyWqB6Uho1IXjeLvH28M7PhmHh86EM7lIy+LRSar1Sso1Ii2Y2nUYfBsMwc4yxvGHZr3FhHLGtxLNOb+9QrZMXwLTHnb7GSz9qQxjgmcwhfmlGumvXLvGDh3+ensy9u8GUer2SsgXuVXoVJADDACOdT/b94ltpVQoef/yfirM3qbVxYTkN3ywYPE9kMhkD8Br/JYM1Q/Wa1Qzf0DjZ7CBcO94A87xTzAfgNfkEokb9Gvg+AEx3666qUR6zivl/QebvKAyQTSoAAAAASUVORK5CYII=",
)
# ----------------------------------------------------------------------------
#  Language knowledge
# ----------------------------------------------------------------------------
PY_BI = {n for n in dir(builtins) if not n.startswith("_") and not n[0].isupper() and n not in keyword.kwlist}
PY_EXC = {n for n in dir(builtins) if n[0].isupper() and n not in ("True", "False", "None")}
PY_WORDS = sorted(set(keyword.kwlist) | PY_BI | PY_EXC | {"self", "cls", "__init__", "__name__", "__main__"})

CPP_KW = set("""alignas alignof and and_eq asm break case catch class compl concept const consteval constexpr
constinit const_cast continue co_await co_return co_yield decltype default delete do dynamic_cast else enum
explicit export extern false final for friend goto if inline mutable namespace new noexcept not not_eq nullptr
operator or or_eq override private protected public register reinterpret_cast requires return sizeof static
static_assert static_cast struct switch template this thread_local throw true try typedef typeid typename union
using virtual volatile while xor xor_eq NULL""".split())
CPP_TY = set("""bool char char8_t char16_t char32_t double float int long short signed unsigned void auto wchar_t
size_t ssize_t int8_t int16_t int32_t int64_t uint8_t uint16_t uint32_t uint64_t string vector map set unordered_map
unordered_set multiset multimap pair queue stack deque priority_queue array bitset list tuple optional variant
string_view std istream ostream ifstream ofstream stringstream istringstream ostringstream mt19937 function
shared_ptr unique_ptr""".split())
STD_NAMES = sorted("""cout cin cerr endl getline string vector map set unordered_map unordered_set pair make_pair
queue stack deque priority_queue array bitset list tuple make_tuple sort reverse min max swap abs sqrt pow floor
ceil accumulate iota fill lower_bound upper_bound binary_search unique next_permutation prev_permutation
to_string stoi stoll stod move forward ios_base ifstream ofstream stringstream sort_heap make_heap count find
max_element min_element for_each transform copy remove erase mt19937 random_device uniform_int_distribution
chrono unique_ptr shared_ptr make_unique make_shared optional string_view function cbegin cend begin end
numeric_limits gcd lcm""".split())
CPP_MEMBERS = sorted("""push_back pop_back emplace_back emplace push pop top front back size empty clear begin end
rbegin rend insert erase find count at resize reserve capacity substr length append c_str first second
lower_bound upper_bound swap assign data sort""".split())
CPP_WORDS = sorted(CPP_KW | CPP_TY | set(STD_NAMES) | {"include", "define", "main", "return", "iostream",
                                                        "bits/stdc++.h", "ios_base"})

PY_SNIPS = {
    "main": 'def main():\n    $0\n\n\nif __name__ == "__main__":\n    main()',
    "for": "for i in range($0):\n    ",
    "def": "def $0():\n    ",
    "cls": "class $0:\n    def __init__(self):\n        ",
    "try": "try:\n    $0\nexcept Exception as e:\n    print(e)",
    "ifm": 'if __name__ == "__main__":\n    $0',
    "inp": "n = int(input())$0",
    "arr": "arr = list(map(int, input().split()))$0",
}
CPP_SNIPS = {
    "main": "#include <iostream>\nusing namespace std;\n\nint main() {\n    $0\n    return 0;\n}",
    "cp": ("#include <bits/stdc++.h>\nusing namespace std;\n\nint main() {\n    ios_base::sync_with_stdio(false);\n"
           "    cin.tie(nullptr);\n    $0\n    return 0;\n}"),
    "for": "for (int i = 0; i < $0; i++) {\n    \n}",
    "fori": "for (int i = 0; i < $0; i++) {\n    \n}",
    "vec": "vector<int> $0;",
    "inc": "#include <$0>",
}

TEMPLATES = {
    "Python — Hello": ("python", '# Python — press F5 to run\nname = input("Your name? ")\nprint(f"Hello, {name}! 👋")\n'),
    "Python — Class demo": ("python", (
        "class Student:\n    def __init__(self, name, grade):\n        self.name = name\n        self.grade = grade\n\n"
        "    def __str__(self):\n        return f\"{self.name}: {self.grade}\"\n\n\n"
        "students = [Student(\"Ali\", 95), Student(\"Sara\", 88)]\n"
        "for s in sorted(students, key=lambda s: -s.grade):\n    print(s)\n")),
    "C++ — Hello": ("cpp", '#include <iostream>\nusing namespace std;\n\nint main() {\n    string name;\n'
                            '    cout << "Your name? ";\n    cin >> name;\n    cout << "Hello, " << name << "!" << endl;\n'
                            '    return 0;\n}\n'),
    "C++ — Competitive template": ("cpp", (
        "#include <bits/stdc++.h>\nusing namespace std;\n\nusing ll = long long;\n\n"
        "void solve() {\n    int n;\n    cin >> n;\n    vector<int> a(n);\n    for (auto &x : a) cin >> x;\n"
        "    sort(a.begin(), a.end());\n    for (int x : a) cout << x << ' ';\n    cout << '\\n';\n}\n\n"
        "int main() {\n    ios_base::sync_with_stdio(false);\n    cin.tie(nullptr);\n    int t = 1;\n"
        "    // cin >> t;\n    while (t--) solve();\n    return 0;\n}\n")),
    "C — Hello": ("c", '#include <stdio.h>\n\nint main(void) {\n    char name[64];\n    printf("Your name? ");\n'
                       '    scanf("%63s", name);\n    printf("Hello, %s!\\n", name);\n    return 0;\n}\n'),
}



LANG_LABEL = {"python": "Python", "cpp": "C++", "c": "C", "text": "Text"}
LANG_EXT = {"python": ".py", "cpp": ".cpp", "c": ".c", "text": ".txt"}


def detect_lang(path):
    if not path:
        return "python"
    e = os.path.splitext(path)[1].lower()
    if e in (".py", ".pyw"):
        return "python"
    if e in (".cpp", ".cc", ".cxx", ".c++", ".hpp", ".hh", ".hxx", ".h"):
        return "cpp"
    if e == ".c":
        return "c"
    return "text"


# ----------------------------------------------------------------------------
#  Pure logic (kept separate so it is easy to test)
# ----------------------------------------------------------------------------
PY_RE = re.compile(
    r'(?P<comment>\#[^\n]*)'
    r'|(?P<string>(?:[rRbBuUfF]{1,2})?(?:"""[\s\S]*?(?:"""|\Z)|' + "'''" + r'[\s\S]*?(?:' + "'''" + r'|\Z)'
    r'|"(?:\\.|[^"\\\n])*"?|\'(?:\\.|[^\'\\\n])*\'?))'
    r'|(?P<decor>^[ \t]*@[\w.]+)'
    r'|(?P<defn>\b(?:def|class)\b[ \t]+)(?P<fname>[A-Za-z_]\w*)'
    r'|(?P<number>\b0[xX][0-9a-fA-F_]+\b|\b0[bB][01_]+\b|\b0[oO][0-7_]+\b'
    r'|(?:\b\d[\d_]*\.?[\d_]*|\.\d[\d_]*)(?:[eE][+-]?\d+)?[jJ]?\b)'
    r'|(?P<word>[A-Za-z_]\w*)', re.M)

CPP_RE = re.compile(
    r'(?P<comment>//[^\n]*|/\*[\s\S]*?(?:\*/|\Z))'
    r'|(?P<string>(?:u8|[uUL])?"(?:\\.|[^"\\\n])*"?|\'(?:\\.|[^\'\\\n])*\'?)'
    r'|(?P<inc>^[ \t]*\#[ \t]*include[ \t]*)(?P<hdr><[^>\n]*>)'
    r'|(?P<pp>^[ \t]*\#[ \t]*\w+)'
    r'|(?P<defn>\b(?:class|struct|enum|union|namespace)\b[ \t]+)(?P<fname>[A-Za-z_]\w*)'
    r'|(?P<number>\b(?:0[xX][0-9a-fA-F\']+|0[bB][01\']+|\d[\d\']*\.?[\d\']*(?:[eE][+-]?\d+)?)[uUlLfF]*\b)'
    r'|(?P<word>[A-Za-z_]\w*)', re.M)


def compute_ranges(s, lang):
    """Return {tag: [(start, end), ...]} character ranges for syntax colouring."""
    out = {k: [] for k in TAGS}
    if lang == "python":
        for m in PY_RE.finditer(s):
            g = m.lastgroup
            if g == "comment":
                out["cm"].append((m.start(), m.end()))
            elif g == "string":
                out["st"].append((m.start(), m.end()))
            elif g == "decor":
                out["dc"].append((m.start(), m.end()))
            elif g == "fname":
                d = m.group("defn")
                out["kw"].append((m.start("defn"), m.start("defn") + len(d.rstrip())))
                out["fn" if d.startswith("def") else "ty"].append((m.start("fname"), m.end("fname")))
            elif g == "number":
                out["nu"].append((m.start(), m.end()))
            elif g == "word":
                w = m.group()
                nxt = s[m.end():m.end() + 1]
                if w in keyword.kwlist:
                    out["kw"].append((m.start(), m.end()))
                elif w in ("self", "cls"):
                    out["sf"].append((m.start(), m.end()))
                elif w in PY_BI:
                    out["bi"].append((m.start(), m.end()))
                elif w in PY_EXC or (nxt == "(" and w[0].isupper()):
                    out["ty"].append((m.start(), m.end()))
                elif nxt == "(":
                    out["fn"].append((m.start(), m.end()))
    elif lang in ("cpp", "c"):
        for m in CPP_RE.finditer(s):
            g = m.lastgroup
            if g == "comment":
                out["cm"].append((m.start(), m.end()))
            elif g == "string":
                out["st"].append((m.start(), m.end()))
            elif g == "hdr":
                out["pp"].append((m.start("inc"), m.start("inc") + len(m.group("inc").rstrip())))
                out["st"].append((m.start("hdr"), m.end("hdr")))
            elif g == "pp":
                out["pp"].append((m.start(), m.end()))
            elif g == "fname":
                d = m.group("defn")
                out["kw"].append((m.start("defn"), m.start("defn") + len(d.rstrip())))
                out["ty"].append((m.start("fname"), m.end("fname")))
            elif g == "number":
                out["nu"].append((m.start(), m.end()))
            elif g == "word":
                w = m.group()
                if w in CPP_KW:
                    out["kw"].append((m.start(), m.end()))
                elif w in CPP_TY:
                    out["ty"].append((m.start(), m.end()))
                elif s[m.end():m.end() + 1] == "(":
                    out["fn"].append((m.start(), m.end()))
    return out


def line_starts(s):
    starts = [0]
    for m in re.finditer("\n", s):
        starts.append(m.end())
    return starts


def off2idx(starts, off):
    ln = bisect.bisect_right(starts, off) - 1
    return "%d.%d" % (ln + 1, off - starts[ln])


def strip_py_comment(code):
    q = None
    i = 0
    while i < len(code):
        c = code[i]
        if q:
            if c == "\\":
                i += 1
            elif c == q:
                q = None
        elif c in "\"'":
            q = c
        elif c == "#":
            return code[:i].rstrip()
        i += 1
    return code.rstrip()


def newline_indent(before, after, lang, tab=TAB):
    """Text to insert when Enter is pressed, and how many chars to move the cursor back."""
    base = re.match(r"[ \t]*", before).group()
    code = before.rstrip()
    extra = ""
    last = ""
    if lang == "python":
        code = strip_py_comment(code)
        last = code[-1:]
        if last == ":" or (last and last in "([{"):
            extra = tab
        elif re.match(r"\s*(return|break|continue|pass|raise)\b", code) and base.endswith(tab):
            base = base[:-len(tab)]
    elif lang in ("cpp", "c"):
        last = code[-1:]
        if last and last in "{([":
            extra = tab
    closer = after.lstrip()[:1]
    if extra and last and closer and {"(": ")", "[": "]", "{": "}"}.get(last) == closer:
        return "\n" + base + extra + "\n" + base, len("\n" + base)
    return "\n" + base + extra, 0


def toggle_comment(lines, token):
    tok = token.rstrip()
    nonempty = [l for l in lines if l.strip()]
    if not nonempty:
        return list(lines)
    if all(l.lstrip().startswith(tok) for l in nonempty):
        out = []
        for l in lines:
            if l.strip():
                i = len(l) - len(l.lstrip())
                rest = l[i + len(tok):]
                if rest.startswith(" "):
                    rest = rest[1:]
                out.append(l[:i] + rest)
            else:
                out.append(l)
        return out
    ind = min(len(l) - len(l.lstrip()) for l in nonempty)
    return [(l[:ind] + token + l[ind:]) if l.strip() else l for l in lines]


def indent_lines(lines, tab=TAB):
    return [(tab + l) if l.strip() else l for l in lines]


def dedent_lines(lines, tab=TAB):
    out = []
    for l in lines:
        if l.startswith("\t"):
            out.append(l[1:])
        else:
            n = len(l) - len(l.lstrip(" "))
            out.append(l[min(n, len(tab)):])
    return out


PAIRS = {"(": ")", "[": "]", "{": "}"}
REV = {v: k for k, v in PAIRS.items()}


def match_bracket(s, i):
    """Return (a, b) offsets of a bracket pair touching position i, or None."""
    for pos in (i, i - 1):
        if 0 <= pos < len(s):
            c = s[pos]
            if c in PAIRS:
                depth = 0
                for j in range(pos, len(s)):
                    if s[j] == c:
                        depth += 1
                    elif s[j] == PAIRS[c]:
                        depth -= 1
                        if depth == 0:
                            return pos, j
                return None
            if c in REV:
                depth = 0
                for j in range(pos, -1, -1):
                    if s[j] == c:
                        depth += 1
                    elif s[j] == REV[c]:
                        depth -= 1
                        if depth == 0:
                            return j, pos
                return None
    return None


def can_pair_quote(before, after, ch):
    if after[:1].isalnum() or after[:1] == "_":
        return False
    if before[-1:] == ch:
        return False
    if before[-1:].isalnum() or before[-1:] == "_":
        return bool(re.search(r"(?<![A-Za-z0-9_])[rRbBuUfF]{1,2}$", before)) and ch in "\"'"
    return True


SAFE_BLOCK = {"antigravity", "this", "idlelib", "turtledemo", "tkinter", "lib2to3", "__main__", "__phello__"}
FALLBACK_STD = {"os", "sys", "math", "random", "re", "json", "time", "datetime", "collections", "itertools",
                "functools", "string", "heapq", "bisect", "statistics", "pathlib", "subprocess", "threading",
                "typing", "decimal", "fractions", "copy", "operator", "csv", "io", "textwrap", "shutil"}
_resolve_cache = {}


def _is_std(root):
    if root in SAFE_BLOCK:
        return False
    std = getattr(sys, "stdlib_module_names", None)
    return (root in std) if std is not None else (root in FALLBACK_STD)


def resolve_dotted(path):
    """Resolve 'os.path' / 'collections.deque' safely (stdlib only)."""
    if path in _resolve_cache:
        return _resolve_cache[path]
    parts = path.split(".")
    obj = None
    if _is_std(parts[0]):
        try:
            obj = importlib.import_module(parts[0])
            for i, p in enumerate(parts[1:], 1):
                nxt = getattr(obj, p, None)
                if nxt is None:
                    nxt = importlib.import_module(".".join(parts[:i + 1]))
                obj = nxt
        except Exception:
            obj = None
    _resolve_cache[path] = obj
    return obj


def py_imports(doc):
    mp = {}
    for m in re.finditer(r"^[ \t]*import[ \t]+(.+)$", doc, re.M):
        for part in m.group(1).split(","):
            part = part.split("#")[0].strip()
            if not part:
                continue
            if " as " in part:
                mod, al = [x.strip() for x in part.split(" as ", 1)]
                mp[al] = mod
            else:
                mp[part.split(".")[0]] = part.split(".")[0]
    for m in re.finditer(r"^[ \t]*from[ \t]+([\w.]+)[ \t]+import[ \t]+(.+)$", doc, re.M):
        for part in m.group(2).replace("(", "").replace(")", "").split(","):
            part = part.split("#")[0].strip()
            if not part or part == "*":
                continue
            name, al = (part.split(" as ", 1) + [None])[:2] if " as " in part else (part, None)
            mp[(al or name).strip()] = m.group(1) + "." + name.strip()
    return mp


def infer_type(name, doc):
    last = None
    for m in re.finditer(r"^[ \t]*%s[ \t]*=[ \t]*(.*)$" % re.escape(name), doc, re.M):
        last = m.group(1).strip()
    if last is None:
        return None
    if last.startswith(("'", '"', "f'", 'f"', "str(", "input(")):
        return str
    if last.startswith(("[", "list(", "sorted(")):
        return list
    if last.startswith(("{",)) and ":" in last:
        return dict
    if last.startswith(("{", "set(")):
        return set
    if last.startswith("dict("):
        return dict
    if last.startswith("int("):
        return int
    if last.startswith("float("):
        return float
    return None


def py_members(chain, doc):
    root = chain.split(".")[0]
    if chain == "self":
        names = set(re.findall(r"self\.(\w+)", doc)) | set(re.findall(r"^[ \t]+def[ \t]+(\w+)", doc, re.M))
        return sorted(n for n in names if not n.startswith("__"))
    obj = None
    imps = py_imports(doc)
    if root in imps:
        full = imps[root] + chain[len(root):]
        obj = resolve_dotted(full)
    elif root in ("str", "list", "dict", "set", "tuple", "int", "float"):
        obj = getattr(builtins, root)
    else:
        t = infer_type(root, doc)
        if t is not None and "." not in chain:
            obj = t
    if obj is None:
        return []
    try:
        return sorted(n for n in dir(obj) if not n.startswith("_"))
    except Exception:
        return []


KIND_LABEL = {"v": "variable", "f": "function", "c": "class", "m": "module", "s": "snippet", "k": "keyword",
              "b": "builtin", "t": "type", "p": "member", "w": "word"}
KIND_RANK = {"v": 1, "f": 1, "c": 1, "m": 1, "p": 1, "s": 2, "k": 3, "t": 3, "b": 4, "w": 6}
PY_NOT_NAMES = set(keyword.kwlist) | {"self", "cls"}
CPP_CTRL = {"return", "else", "delete", "new", "throw", "case", "goto", "using", "typedef", "namespace", "if",
            "while", "for", "switch", "sizeof", "do", "co_return", "co_await", "co_yield"}
_ID = r"[A-Za-z_]\w*"


def _indent(line):
    return len(line) - len(line.lstrip())


def py_symbols(doc, cur_line):
    """Names defined in a Python file: {name: (kind, line, is_local)}."""
    syms = {}
    lines = doc.split("\n")

    # which functions enclose the cursor?
    enclosing = []
    if 1 <= cur_line <= len(lines):
        cur = lines[cur_line - 1]
        ind = _indent(cur) if cur.strip() else 10 ** 6
        for j in range(cur_line - 2, -1, -1):
            ln = lines[j]
            if not ln.strip():
                continue
            if _indent(ln) < ind:
                if re.match(r"\s*(?:async\s+)?def\s+" + _ID, ln):
                    enclosing.append(j + 1)
                ind = _indent(ln)
                if ind == 0:
                    break
    inner = enclosing[0] if enclosing else None

    def add(name, kind, ln, local=False):
        if not name or name in PY_NOT_NAMES or (name.startswith("__") and name.endswith("__")):
            return
        old = syms.get(name)
        if old is None or (local and not old[2]) or (old[0] == "v" and kind in "fcm" and not old[2]):
            syms[name] = (kind, ln, local)

    assign = re.compile(r"\s*((?:\*?" + _ID + r"\s*,\s*)*\*?" + _ID + r")\s*(?::[^=]+)?"
                        r"(?:=|[-+*/%&|^@]=|//=|\*\*=|>>=|<<=)(?!=)")
    for i, raw in enumerate(lines, 1):
        code = strip_py_comment(raw)
        if not code.strip():
            continue
        loc = inner is not None and inner <= i <= cur_line
        m = re.match(r"\s*(?:async\s+)?def\s+(" + _ID + r")\s*\((.*)", code)
        if m:
            add(m.group(1), "f", i)
            if i in enclosing:
                params = m.group(2)
                if ")" in params:
                    params = params[:params.rfind(")")]
                for p in params.split(","):
                    pm = re.match(r"\s*\*{0,2}(" + _ID + ")", p)
                    if pm:
                        add(pm.group(1), "v", i, True)
            continue
        m = re.match(r"\s*class\s+(" + _ID + ")", code)
        if m:
            add(m.group(1), "c", i)
            continue
        m = re.match(r"\s*import\s+(.+)", code)
        if m:
            for part in m.group(1).split(","):
                part = part.strip()
                name = part.split(" as ")[-1].strip() if " as " in part else part.split(".")[0]
                add(name, "m", i)
            continue
        m = re.match(r"\s*from\s+[\w.]+\s+import\s+(.+)", code)
        if m:
            for part in m.group(1).replace("(", "").replace(")", "").split(","):
                part = part.strip()
                if part and part != "*":
                    add(part.split(" as ")[-1].strip(), "m", i)
            continue
        m = assign.match(code)
        if m:
            for n in re.findall(_ID, m.group(1)):
                add(n, "v", i, loc)
        for fm in re.finditer(r"\bfor\s+(.+?)\s+in\b", code):
            for n in re.findall(_ID, fm.group(1)):
                add(n, "v", i, loc)
        for am in re.finditer(r"\bas\s+(" + _ID + ")", code):
            add(am.group(1), "v", i, loc)
        for wm in re.finditer(r"\b(" + _ID + r")\s*:=", code):
            add(wm.group(1), "v", i, loc)
    return syms


def cpp_symbols(doc, cur_line):
    """Names defined in a C/C++ file: {name: (kind, line, is_local)}."""
    syms = {}
    types = set(CPP_TY)
    starts = line_starts(doc)
    lineno = lambda off: bisect.bisect_right(starts, off)

    def add(name, kind, ln, local=False):
        if not name or name in CPP_KW or name in CPP_TY:
            return
        old = syms.get(name)
        if old is not None and old[0] in "fc" and kind == "v":
            return
        if old is None or (local and not old[2]):
            syms[name] = (kind, ln, local)

    for m in re.finditer(r"\b(?:class|struct|union|enum(?:\s+class|\s+struct)?)\s+(" + _ID + ")", doc):
        add(m.group(1), "c", lineno(m.start()))
        types.add(m.group(1))
    for m in re.finditer(r"\busing\s+(" + _ID + r")\s*=", doc):
        add(m.group(1), "c", lineno(m.start()))
        types.add(m.group(1))
    for m in re.finditer(r"\btypedef\b[^;]*?\b(" + _ID + r")\s*;", doc):
        add(m.group(1), "c", lineno(m.start()))
        types.add(m.group(1))
    for m in re.finditer(r"^[ \t]*#[ \t]*define[ \t]+(" + _ID + ")", doc, re.M):
        add(m.group(1), "v", lineno(m.start()))

    fn_re = re.compile(r"^[ \t]*(?:template\s*<[^>]*>\s*)?((?:[A-Za-z_][\w:]*(?:<[^;(){}]*?>)?[\s\*&]+)+)(" + _ID +
                       r")\s*\(([^()]*)\)\s*(?:const\s*)?(?:noexcept\s*)?(?:override\s*)?(?:\{|$)", re.M)
    fns = []
    for m in fn_re.finditer(doc):
        first = re.match(_ID, m.group(1)).group()
        if first in CPP_CTRL:
            continue
        fns.append((lineno(m.start()), m.group(2), m.group(3)))
    enclosing = None
    for ln, name, params in fns:
        add(name, "f", ln)
        if ln <= cur_line:
            enclosing = (ln, params)
    inner_line = enclosing[0] if enclosing else None
    if enclosing:
        for p in enclosing[1].split(","):
            pm = re.search(r"(" + _ID + r")\s*(?:\[[^\]]*\])?\s*(?:=.*)?$", p.strip())
            if pm:
                add(pm.group(1), "v", enclosing[0], True)

    tyalt = r"(?:(?:const|static|constexpr|unsigned|signed|register|volatile|extern|inline|mutable)\s+)*"
    var_re = re.compile(r"(?:^|[;{(])\s*" + tyalt + r"((?:" + _ID + r"::)*(" + _ID + r")(?:\s*<[^;{}]*?>)?"
                        r"(?:\s+(?:long|int|double|char|short))*)(?:\s+[\*&]*\s*|\s*[\*&]+\s*)(" + _ID + r")"
                        r"\s*(?=[=;,\[{:)]|$)")
    for i, raw in enumerate(doc.split("\n"), 1):
        code = re.sub(r"//.*$", "", raw)
        if not code.strip():
            continue
        loc = inner_line is not None and inner_line <= i <= cur_line
        for m in var_re.finditer(code):
            base = m.group(2)
            if not (base in types or base.endswith("_t") or "<" in m.group(1)):
                continue
            add(m.group(3), "v", i, loc)
            rest = code[m.end():]
            if "(" not in rest:
                for rm in re.finditer(r",\s*[\*&]*(" + _ID + r")\s*(?=[=;,\[])", rest):
                    add(rm.group(1), "v", i, loc)
    return syms


def _fuzzy(prefix, name):
    """Subsequence match anchored on the first letter (gn -> get_name)."""
    if not prefix or prefix[0].lower() != name[:1].lower():
        return False
    it = iter(name.lower())
    return all(c in it for c in prefix.lower())


def completions(lang, line_before, doc, force=False, cur_line=1):
    """Return ([(name, kind), ...], prefix) ranked like an IDE: locals first, then project symbols."""
    m = re.search(r"([A-Za-z_]\w*)$", line_before)
    prefix = m.group(1) if m else ""
    head = line_before[:len(line_before) - len(prefix)]
    if lang not in ("python", "cpp", "c"):
        return [], prefix
    py = lang == "python"
    member = False
    pool = {}      # (name, kind) -> (dist, local)
    names = set()
    names_ns = set()

    def put(name, kind, dist=0, local=False):
        if name == prefix or (kind != "s" and name in names_ns):
            return
        pool[(name, kind)] = (dist, local)
        names.add(name)
        if kind != "s":
            names_ns.add(name)

    if py:
        mm = re.search(r"([A-Za-z_][\w.]*)\.$", head)
        if mm:
            member = True
            for n in py_members(mm.group(1), doc):
                put(n, "p")
    else:
        if head.endswith("std::"):
            member = True
            for n in STD_NAMES:
                put(n, "f")
        elif head.endswith(".") or head.endswith("->"):
            member = True
            for n in CPP_MEMBERS:
                put(n, "p")
    if not member:
        if not prefix and not force:
            return [], prefix
        syms = (py_symbols if py else cpp_symbols)(doc, cur_line)
        for n, (k, ln, loc) in syms.items():
            put(n, k, abs(cur_line - ln) if ln <= cur_line else 5000 + ln, loc)
        if py:
            for n in keyword.kwlist:
                put(n, "k")
            for n in PY_BI:
                put(n, "b")
            for n in PY_EXC:
                put(n, "t")
            snips = PY_SNIPS
        else:
            for n in CPP_KW:
                put(n, "k")
            for n in CPP_TY:
                put(n, "t")
            for n in STD_NAMES:
                put(n, "b")
            snips = CPP_SNIPS
        for n in snips:
            put(n, "s")
    elif not py or True:
        pass
    for w in set(re.findall(r"[A-Za-z_]\w{2,}", doc)):
        if w not in names and w != prefix and (not member or not py):
            put(w, "w")
    pl = prefix.lower()

    def key(item):
        (name, kind), (dist, local) = item
        rank = 0 if (local and kind == "v") else KIND_RANK[kind]
        return (rank, dist, name.lower())

    exact = sorted((i for i in pool.items() if i[0][0].startswith(prefix)), key=key)
    loose = sorted((i for i in pool.items() if not i[0][0].startswith(prefix) and i[0][0].lower().startswith(pl)), key=key)
    fuzzy = []
    if len(prefix) >= 2 and not member:
        fuzzy = sorted((i for i in pool.items() if not i[0][0].lower().startswith(pl) and i[0][1] in "vfcm"
                        and _fuzzy(prefix, i[0][0])), key=key)[:12]
    out = [i[0] for i in exact + loose + fuzzy]
    return out[:80], prefix


GCC_RE = re.compile(r"^(.+?):(\d+):(?:(\d+):)?\s*(fatal error|error|warning|note)", re.I)
PYTB_RE = re.compile(r'^\s*File "(.+?)", line (\d+)')


def parse_error_line(line):
    """Return (path, line, col, kind) for compiler / traceback lines, or None."""
    m = PYTB_RE.match(line)
    if m:
        return m.group(1), int(m.group(2)), 1, "error"
    m = GCC_RE.match(line)
    if m:
        return m.group(1), int(m.group(2)), int(m.group(3) or 1), m.group(4).lower()
    return None


# ----------------------------------------------------------------------------
#  Tool discovery
# ----------------------------------------------------------------------------
FROZEN = bool(getattr(sys, "frozen", False)) or os.path.basename(sys.executable or "").lower().startswith("legend")
# ^ True inside the packaged app: "Legend Code.exe" hosts Python itself, so sys.executable is the app, not python.exe


def bundled_python():
    """runtime/python.exe shipped next to Legend Code.exe (used when this PC has no Python of its own)."""
    p = os.path.join(os.path.dirname(os.path.abspath(sys.executable or "")), "runtime", "python.exe")
    return p if os.path.exists(p) else None
_TOOLS = {}


def find_python(cfg):
    """The Python that runs the USER's programs. Inside the packaged .exe, sys.executable is Legend Code itself,
    so a real Python must be found on this PC."""
    if cfg.get("python"):
        return cfg["python"]
    if not FROZEN:
        exe = sys.executable or "python"
        if os.path.basename(exe).lower() == "pythonw.exe":
            cand = os.path.join(os.path.dirname(exe), "python.exe")
            if os.path.exists(cand):
                return cand
        return exe
    c = _TOOLS.get("py")
    if c:
        return c
    found = None
    for name in ("python", "python3", "py"):
        p = shutil.which(name)
        if p and "WindowsApps" not in p:                  # the Microsoft Store stub only opens the Store
            found = p
            break
    if not found and IS_WIN:
        base = os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Python")
        try:
            vers = sorted((d for d in os.listdir(base) if d.lower().startswith("python3")), reverse=True)
        except OSError:
            vers = []
        for d in vers:
            cand = os.path.join(base, d, "python.exe")
            if os.path.exists(cand):
                found = cand
                break
    found = found or bundled_python() or "python"
    _TOOLS["py"] = found
    return found


_CLT = {}


def ico_bytes():
    """A Windows .ico built from the embedded PNG icons (PNG-compressed entries are supported since Windows Vista)."""
    imgs = []
    for b in LOGO_ICON_B64:
        d = base64.b64decode(b)
        imgs.append((struct.unpack(">I", d[16:20])[0], struct.unpack(">I", d[20:24])[0], d))
    head = struct.pack("<HHH", 0, 1, len(imgs))
    off = 6 + 16 * len(imgs)
    ent, blob = b"", b""
    for w, h, d in imgs:
        ent += struct.pack("<BBBBHHII", w % 256, h % 256, 0, 0, 1, 32, len(d), off + len(blob))
        blob += d
    return head + ent + blob


def app_data_dir():
    return os.path.join(os.environ.get("LOCALAPPDATA") or HOME, "LegendCode")


def gui_python():
    """pythonw.exe (no black console window) next to the interpreter that runs the IDE (or the .exe itself when packaged)."""
    if getattr(sys, "frozen", False):
        return sys.executable
    exe = sys.executable
    if IS_WIN and os.path.basename(exe).lower() == "python.exe":
        w = os.path.join(os.path.dirname(exe), "pythonw.exe")
        if os.path.exists(w):
            return w
    return exe


def mac_dev_tools_ok():
    """Without Xcode's command line tools /usr/bin/g++ is only a stub that pops up an installer - don't trust it."""
    if "ok" not in _CLT:
        try:
            _CLT["ok"] = subprocess.run(["xcode-select", "-p"], capture_output=True, timeout=5).returncode == 0
        except Exception:
            _CLT["ok"] = False
    return _CLT["ok"]


MAC_BIN_DIRS = ["/opt/homebrew/bin", "/usr/local/bin"]      # Finder-launched apps don't inherit the shell PATH


def find_tool(names, extra=()):
    for n in names:
        p = shutil.which(n)
        if p and IS_MAC and p.startswith("/usr/bin/") and not mac_dev_tools_ok():
            p = None
        if p:
            return p
    if IS_MAC:
        for d in MAC_BIN_DIRS:
            for n in names:
                if os.path.exists(os.path.join(d, n)):
                    return os.path.join(d, n)
    for p in extra:
        if os.path.exists(p):
            return p
    return None


WIN_GXX = [r"C:\msys64\ucrt64\bin\g++.exe", r"C:\msys64\mingw64\bin\g++.exe", r"C:\mingw64\bin\g++.exe",
           r"C:\MinGW\bin\g++.exe", r"C:\ProgramData\mingw64\mingw64\bin\g++.exe",
           r"C:\Program Files\mingw64\bin\g++.exe"]


def find_cxx(cfg):
    if cfg.get("cxx"):
        return cfg["cxx"]
    return find_tool(["g++", "clang++", "c++"], WIN_GXX if IS_WIN else ())


def find_cc(cfg):
    if cfg.get("cxx"):
        guess = re.sub(r"(g|clang)\+\+", lambda m: "gcc" if m.group(1) == "g" else "clang", cfg["cxx"])
        if os.path.exists(guess) or shutil.which(guess):
            return guess
    gx = find_cxx(cfg)
    if gx:
        guess = re.sub(r"g\+\+", "gcc", gx)
        if guess != gx and (os.path.exists(guess) or shutil.which(guess)):
            return guess
    return find_tool(["gcc", "clang", "cc"])




# ----------------------------------------------------------------------------
#  Process runner (compile + run, streaming output, live stdin)
# ----------------------------------------------------------------------------
class Runner:
    """Runs build / run steps on a worker thread; everything the UI needs arrives through self.q."""

    def __init__(self):
        self.q = queue.Queue()
        self.proc = None
        self.gen = 0
        self.running = False

    def _flags(self):
        return subprocess.CREATE_NO_WINDOW if IS_WIN else 0

    @staticmethod
    def kill_tree(p):
        """Kill a process and its children (a program that started helpers must not be left running)."""
        if p is None or p.poll() is not None:
            return
        if IS_WIN:
            try:
                subprocess.run(["taskkill", "/F", "/T", "/PID", str(p.pid)], capture_output=True, timeout=4,
                               creationflags=subprocess.CREATE_NO_WINDOW)
            except Exception:
                pass
        try:
            p.kill()
        except Exception:
            pass

    def start(self, steps):
        """steps: list of (kind, argv, cwd) where kind is 'compile' or 'run'."""
        self.stop()
        self.gen += 1
        self.running = True
        threading.Thread(target=self._work, args=(self.gen, steps), daemon=True).start()

    def stop(self, wait=False):
        p = self.proc
        if self.running:
            self.gen += 1
        self.running = False
        if p is not None and p.poll() is None:
            if wait:
                self.kill_tree(p)
            else:
                threading.Thread(target=self.kill_tree, args=(p,), daemon=True).start()

    def send(self, text):
        p = self.proc
        if not (p and p.poll() is None and p.stdin):
            return False
        try:
            p.stdin.write(text.encode("utf-8"))
            p.stdin.flush()
            return True
        except Exception:
            return False

    def close_stdin(self):
        p = self.proc
        if p and p.stdin:
            try:
                p.stdin.close()
            except Exception:
                pass

    def _put(self, gen, *item):
        self.q.put((gen,) + item)

    def _work(self, gen, steps):
        t0 = time.time()
        rc = 0
        try:
            for kind, cmd, cwd in steps:
                if gen != self.gen:
                    return
                env = dict(os.environ)
                if kind == "compile":
                    env["LC_ALL"] = "C"
                    self._put(gen, "info", "$ " + " ".join(shlex.quote(c) if not IS_WIN else ('"%s"' % c if " " in c else c) for c in cmd) + "\n")
                    t1 = time.time()
                    p = subprocess.Popen(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                         stdin=subprocess.DEVNULL, env=env, creationflags=self._flags())
                    self.proc = p
                    data = p.stdout.read()
                    rc = p.wait()
                    text = data.decode("utf-8", "replace")
                    if text.strip():
                        self._put(gen, "out", text if text.endswith("\n") else text + "\n", "err" if rc else "warn")
                    if rc != 0:
                        self._put(gen, "info", "\n✖ Build failed (exit code %d)\n" % rc)
                        break
                    self._put(gen, "info", "✔ Build OK in %.2fs\n\n" % (time.time() - t1))
                else:
                    for k in ("PYTHONHOME", "PYTHONPATH", "PYTHONSTARTUP", "PYTHONNOUSERSITE"):
                        env.pop(k, None)
                    env["PYTHONUNBUFFERED"] = "1"
                    env["PYTHONIOENCODING"] = "utf-8"
                    env["PYTHONUTF8"] = "1"
                    p = subprocess.Popen(cmd, cwd=cwd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                         stderr=subprocess.PIPE, env=env, creationflags=self._flags())
                    self.proc = p
                    self._put(gen, "started")
                    ths = []
                    for stream, tag in ((p.stdout, "out"), (p.stderr, "err")):
                        th = threading.Thread(target=self._reader, args=(gen, stream, tag), daemon=True)
                        th.start()
                        ths.append(th)
                    rc = p.wait()
                    for th in ths:
                        th.join(timeout=2)
        except FileNotFoundError as e:
            self._put(gen, "missing", str(e))
            rc = -1
        except Exception as e:  # pragma: no cover
            self._put(gen, "out", "Runner error: %s\n" % e, "err")
            rc = -1
        finally:
            self._put(gen, "done", rc, time.time() - t0)       # first the event ...
            if gen == self.gen:
                self.running = False                           # ... then the flag, so the UI never misses the event

    def _reader(self, gen, stream, tag):
        dec = codecs.getincrementaldecoder("utf-8")("replace")
        try:
            while True:
                b = stream.read1(65536) if hasattr(stream, "read1") else stream.read(1)
                if not b:
                    break
                s = dec.decode(b)
                if s:
                    self._put(gen, "out", s, tag)
        except Exception:
            pass


# ----------------------------------------------------------------------------
#  AI assistant (Claude API or local Ollama) - pure helpers + streaming client
# ----------------------------------------------------------------------------
AI_SYSTEM = """You are the Assistant, an expert pair-programmer built into Legend Code (Python and C/C++).
Answer fast: be brief and to the point, practical and correct. Never invent APIs or libraries.
When you change or write code, return the COMPLETE updated code in ONE fenced code block that has a language tag, so the user can apply it with one click. Put short explanations outside the block.
Prefer clean, readable, beginner-friendly code with helpful comments.
{lang_rule}"""
AI_INLINE_SYSTEM = """You are a precise {lang} code generator inside an IDE.
Output ONLY the code to insert (or the full replacement for the selected code): no explanations, no markdown fences.
Match the surrounding style and indentation. Do not repeat code that already exists around the cursor."""
AI_LANG_RULE = {
    "Arabic": "Reply in simple, friendly Arabic, but keep all code, identifiers and technical terms in English.",
    "English": "Reply in English.",
    "Same as me": "Reply in the same language the user writes in.",
}
AI_PROMPTS = {
    "explain": "Explain this code clearly and simply, step by step. Mention anything risky or confusing.",
    "fix": ("Find the bugs and errors in this code (use the program output if it is provided) and fix them. "
            "Briefly explain what was wrong, then give the full corrected code."),
    "improve": ("Improve this code: readability, naming, performance and best practices, without changing its behavior. "
                "Give the full improved code and briefly list what you changed."),
    "comment": "Add clear, helpful comments (and docstrings where suitable). Return the full commented code.",
    "tests": "Write useful test cases for this code: give sample inputs with the expected outputs, including edge cases.",
    "refactor": ("Refactor this code for clarity and maintainability: split long functions, remove duplication, use clear names. "
                 "Keep the behavior identical. Return the full refactored code and briefly list the changes."),
}


def extract_code(text):
    """First fenced code block of a reply (or the text itself if it has no fences)."""
    m = re.search(r"```[^\n]*\n(.*?)(?:```|\Z)", text, re.S)
    return (m.group(1) if m else text).strip("\n")


def split_blocks(text):
    """Split a markdown reply into ('text', s) and ('code', lang, code, closed) parts."""
    out, pos = [], 0
    for m in re.finditer(r"```([\w+#.-]*)[ \t]*\n(.*?)(```|\Z)", text, re.S):
        if m.start() > pos:
            out.append(("text", text[pos:m.start()]))
        out.append(("code", m.group(1), m.group(2).rstrip("\n"), m.group(3) == "```"))
        pos = m.end()
    if pos < len(text):
        out.append(("text", text[pos:]))
    return out




# ----------------------------------------------------------------------------
#  Completion popup
# ----------------------------------------------------------------------------
def in_string(before):
    """True if the end of `before` sits inside an unterminated string literal."""
    q = None
    i = 0
    while i < len(before):
        c = before[i]
        if q:
            if c == "\\":
                i += 1
            elif c == q:
                q = None
        elif c in "\"'":
            q = c
        i += 1
    return q is not None





# ----------------------------------------------------------------------------
#  Offline error helper: explains the most common Python / C / C++ errors with no internet, no account, no AI model
# ----------------------------------------------------------------------------
# (regex, English title, English explanation, Arabic title, Arabic explanation)   <1> <2> <3> = regex groups
ERROR_RULES = [
    (r"SyntaxError: '([(\[{])' was never closed",
     "A bracket was never closed", "You opened '<1>' but never closed it. Look at the reported line and the line just above it, then add the matching closing bracket.",
     "قوس لم يُغلق", "فتحت القوس '<1>' ولم تُغلقه. افحص السطر المذكور والسطر الذي فوقه ثم أضف القوس المقابل."),
    (r"SyntaxError: expected ':'",
     "A ':' is missing", "Lines that start with if / elif / else / for / while / def / class / try / except must end with a colon ':'.",
     "نقص النقطتان ':'", "الأسطر التي تبدأ بـ if أو elif أو else أو for أو while أو def أو class أو try أو except يجب أن تنتهي بنقطتين ':'."),
    (r"SyntaxError: (?:unterminated string literal|unterminated triple-quoted|EOL while scanning)",
     "A quote is missing", "A text value starts with a quote but never ends. Add the closing quote (the same kind) at the end of the text.",
     "علامة اقتباس ناقصة", "بدأ النص بعلامة اقتباس ولم يُغلق. أضف علامة الاقتباس الختامية (من نفس النوع) في نهاية النص."),
    (r"IndentationError: (?:unexpected indent|expected an indented block|unindent does not match)",
     "Indentation problem", "Python groups code by the spaces at the start of each line. Every line in the same block needs the same number of spaces (4 is standard), and tabs must not be mixed with spaces.",
     "مشكلة في المسافات البادئة", "بايثون يجمّع الكود حسب المسافات في بداية السطر. كل سطر في نفس الكتلة يحتاج نفس عدد المسافات (4 هو المعتاد)، ولا تخلط بين Tab والمسافات."),
    (r"SyntaxError: invalid syntax",
     "Python can't understand this line", "Check the reported line and the one before it: a missing operator, comma or bracket, or a misspelled keyword is the usual cause.",
     "بايثون لا يفهم هذا السطر", "افحص السطر المذكور والسطر الذي قبله: السبب المعتاد هو نقص رمز أو فاصلة أو قوس أو كلمة محجوزة مكتوبة بشكل خاطئ."),
    (r"NameError: name '(\w+)' is not defined",
     "'<1>' is not defined", "You used '<1>' before creating it, or it is spelled differently (Python is case-sensitive). Create it first, fix the spelling, or import it.",
     "'<1>' غير معرّف", "استخدمت '<1>' قبل إنشائه أو كتبته بشكل مختلف (بايثون يفرّق بين الحروف الكبيرة والصغيرة). عرّفه أولًا أو صحّح الاسم أو استورده."),
    (r"TypeError: can only concatenate str",
     "Mixing text and numbers", "You joined a text with a number. Convert the number first: str(number) to join text, or int(text) to calculate.",
     "خلط بين نص ورقم", "جمعت نصًا مع رقم. حوّل الرقم أولًا: str(الرقم) للدمج مع النص، أو int(النص) للحساب."),
    (r"TypeError: unsupported operand type\(s\) for ([^:]+): '(\w+)' and '(\w+)'",
     "Can't use '<1>' between <2> and <3>", "These two values have types that don't work together. Convert one of them with int(...), float(...) or str(...). Note: input() always returns text.",
     "لا يمكن استخدام '<1>' بين <2> و <3>", "نوعا القيمتين لا يعملان معًا. حوّل إحداهما بـ int(...) أو float(...) أو str(...). تذكّر أن input() يُرجع نصًا دائمًا."),
    (r"TypeError: '(\w+)' object is not callable",
     "'<1>' is not a function", "You put () after something that isn't a function. Often a variable has the same name as a function (like sum or list), or an operator is missing before a bracket.",
     "'<1>' ليست دالة", "وضعت () بعد شيء ليس دالة. غالبًا يوجد متغير بنفس اسم دالة (مثل sum أو list)، أو ينقص رمز قبل القوس."),
    (r"TypeError: (\w+)\(\) missing (\d+) required positional argument",
     "<1>() needs more values", "The function needs <2> more value(s) than you gave. Add the missing argument(s) when you call it.",
     "الدالة <1>() تحتاج قيمًا أكثر", "الدالة تحتاج <2> قيمة (قيم) إضافية. أضف القيم الناقصة عند استدعائها."),
    (r"TypeError: (\w+)\(\) takes (\d+) positional arguments? but (\d+) (?:was|were) given",
     "Too many values for <1>()", "<1> accepts <2> value(s) but you passed <3>. Inside a class the first parameter must be self.",
     "قيم زائدة للدالة <1>()", "الدالة <1> تقبل <2> قيمة (قيم) لكنك مررت <3>. داخل الكلاس يجب أن يكون أول معامل self."),
    (r"TypeError: '(\w+)' object is not subscriptable",
     "Can't use [ ] on <1>", "You used [ ] on a value that isn't a list, string or dictionary (it may be None, a number or a function). Print the value to see what it really is.",
     "لا يمكن استخدام [ ] مع <1>", "استخدمت [ ] على قيمة ليست قائمة أو نصًا أو قاموسًا (ربما None أو رقم أو دالة). اطبع القيمة لترى ما هي فعلًا."),
    (r"ValueError: invalid literal for int\(\) with base 10: (.*)",
     "Can't turn <1> into a whole number", "int() only accepts text made of digits. Remove spaces and letters, or handle bad input with try / except ValueError.",
     "لا يمكن تحويل <1> إلى رقم صحيح", "الدالة int() تقبل نصًا من أرقام فقط. احذف المسافات والحروف، أو تعامل مع الإدخال الخاطئ بـ try / except ValueError."),
    (r"ValueError: could not convert string to float: (.*)",
     "Can't turn <1> into a number", "float() needs text like 3.14. Check the input for letters, commas or spaces.",
     "لا يمكن تحويل <1> إلى رقم", "الدالة float() تحتاج نصًا مثل 3.14. افحص الإدخال: قد يحتوي حروفًا أو فواصل أو مسافات."),
    (r"ValueError: (?:not enough|too many) values to unpack",
     "Wrong number of values to unpack", "You tried to split a list/tuple into a different number of variables than it holds. Make the counts equal.",
     "عدد القيم لا يطابق المتغيرات", "حاولت توزيع قائمة على عدد متغيرات مختلف عن عدد عناصرها. اجعل العددين متساويين."),
    (r"IndexError: (?:list|string|tuple) index out of range",
     "That position doesn't exist", "The sequence is shorter than the position you asked for. Counting starts at 0, so the last item is len(x) - 1. Check your loop range.",
     "هذا الموضع غير موجود", "القائمة أقصر من الموضع المطلوب. العدّ يبدأ من 0 لذلك آخر عنصر هو len(x) - 1. افحص نطاق الحلقة."),
    (r"KeyError: (.+)",
     "Key <1> not found", "The dictionary has no key <1>. Use d.get(key) to avoid the error, or check 'key in d' first.",
     "المفتاح <1> غير موجود", "القاموس لا يحتوي المفتاح <1>. استخدم d.get(key) لتجنب الخطأ، أو افحص 'key in d' أولًا."),
    (r"AttributeError: 'NoneType' object has no attribute '(\w+)'",
     "A value is None", "Something returned None (a function with no return, or a search that found nothing) and you used it as an object. Check the function's return and test for None first.",
     "القيمة هي None", "شيء ما أرجع None (دالة بدون return أو بحث لم يجد شيئًا) واستخدمته ككائن. افحص return في الدالة واختبر None قبل الاستخدام."),
    (r"AttributeError: '(\w+)' object has no attribute '(\w+)'",
     "<1> has no '<2>'", "Check the spelling and capital letters of '<2>', and whether the value really is the type you expect.",
     "<1> لا يحتوي '<2>'", "افحص إملاء '<2>' والحروف الكبيرة، وتأكد أن القيمة من النوع الذي تتوقعه."),
    (r"ZeroDivisionError",
     "Division by zero", "The divisor is 0. Check it before dividing, for example: if b != 0: ...",
     "قسمة على صفر", "المقسوم عليه يساوي 0. افحصه قبل القسمة، مثلًا: if b != 0: ..."),
    (r"ModuleNotFoundError: No module named '([\w.]+)'",
     "Package '<1>' is not installed", "Open a terminal and run: pip install <1>  (the install name can differ from the import name). Also check the spelling of the import.",
     "الحزمة '<1>' غير مثبتة", "افتح الطرفية ونفّذ: pip install <1>  (قد يختلف اسم التثبيت عن اسم الاستيراد). وتأكد من إملاء سطر import."),
    (r"FileNotFoundError",
     "File not found", "The path is wrong, or the file isn't in the folder the program runs from. Use the full path, or put the file next to your script.",
     "الملف غير موجود", "المسار خاطئ أو الملف ليس في مجلد تشغيل البرنامج. استخدم المسار الكامل أو ضع الملف بجانب السكربت."),
    (r"RecursionError",
     "A function calls itself forever", "Add a stopping condition (base case) to the recursive function, or use a loop instead.",
     "دالة تستدعي نفسها بلا نهاية", "أضف شرط توقف للدالة العودية، أو استخدم حلقة بدلًا منها."),
    (r"EOFError",
     "The program asked for input but none arrived", "Type the value in the Input box under the terminal and press Enter. Don't close input (EOF) before the program has read what it needs.",
     "البرنامج طلب إدخالًا ولم يصله", "اكتب القيمة في خانة الإدخال أسفل الطرفية واضغط Enter. لا تُغلق الإدخال (EOF) قبل أن يقرأ البرنامج ما يحتاجه."),
    (r"UnboundLocalError",
     "Variable used before it has a value", "A variable that is assigned inside a function is local to it. Give it a value before using it, or write 'global name' if you mean the outer one.",
     "متغير استُخدم قبل أن يأخذ قيمة", "المتغير الذي تُسند له قيمة داخل الدالة يصبح محليًا. أعطه قيمة قبل استخدامه أو اكتب 'global اسم' إن كنت تقصد الخارجي."),
    (r"PermissionError",
     "Not allowed to use this file", "Close the file in other programs, or choose a folder you are allowed to write to.",
     "غير مسموح باستخدام هذا الملف", "أغلق الملف في البرامج الأخرى أو اختر مجلدًا يُسمح لك بالكتابة فيه."),
    (r"Unicode(?:Decode|Encode)Error",
     "Text encoding problem", "Open files with the right encoding, for example open(path, encoding='utf-8').",
     "مشكلة في ترميز النص", "افتح الملفات بالترميز الصحيح، مثلًا open(path, encoding='utf-8')."),
    # ---- C / C++
    (r"error: expected '[;)}]' (?:before|at end)|error: expected ';'",
     "Missing ';' (or a bracket)", "A statement is missing its ending ';' - usually on the line ABOVE the one reported. Also remember ';' after a class or struct's closing '}'.",
     "نقص ';' (أو قوس)", "هناك جملة تنقصها الفاصلة المنقوطة ';' غالبًا في السطر الذي فوق السطر المذكور. وتذكّر ';' بعد قوس الإغلاق '}' للكلاس أو struct."),
    (r"error: '(\w+)' was not declared in this scope",
     "'<1>' is not declared", "Check the spelling and capital letters, declare it before use, or add the missing #include. For cout / cin / vector / string you also need: using namespace std;",
     "'<1>' غير معرّف", "افحص الإملاء والحروف الكبيرة، وعرّفه قبل الاستخدام، أو أضف #include الناقص. ومع cout وcin وvector وstring تحتاج أيضًا: using namespace std;"),
    (r"undefined reference to [`'\"]?([^'`\"\n]+)",
     "Linker: '<1>' has no body", "The function is declared but never written, its file isn't part of the build, or main() is missing or misspelled. For a single file, make sure the function body exists.",
     "المُرتبِط: '<1>' بلا تنفيذ", "الدالة معلنة لكن لم تُكتب، أو ملفها ليس ضمن البناء، أو دالة main() ناقصة أو مكتوبة خطأ. في ملف واحد تأكد من وجود جسم الدالة."),
    (r"fatal error: ([^:\n]+): No such file or directory",
     "Header '<1>' not found", "Check the name. Use <...> for system headers and \"...\" for your own files placed next to the code.",
     "ملف الترويسة '<1>' غير موجود", "افحص الاسم. استخدم <...> لترويسات النظام و \"...\" لملفاتك الموضوعة بجانب الكود."),
    (r"expected '\}' at end of input|expected declaration before '\}' token",
     "Brackets don't match", "There is one '{' without its '}' (or an extra '}'). Indent consistently so the mismatch is easy to spot.",
     "الأقواس غير متطابقة", "يوجد '{' بدون '}' المقابل (أو '}' زائد). حافظ على مسافات بادئة منتظمة لتكتشف الخلل بسهولة."),
    (r"error: (?:invalid conversion from|cannot convert) '([^']+)' to '([^']+)'",
     "Can't convert <1> to <2>", "Use an explicit conversion such as static_cast<...>(value), or change the variable's type.",
     "لا يمكن تحويل <1> إلى <2>", "استخدم تحويلًا صريحًا مثل static_cast<...>(value) أو غيّر نوع المتغير."),
    (r"error: no matching function for call to '([^']+)'",
     "No <1> accepts these values", "Compare the number and types of your arguments with the function's declaration.",
     "لا توجد <1> تقبل هذه القيم", "قارن عدد وأنواع القيم التي مررتها مع تعريف الدالة."),
    (r"missing terminating (?:\"|') character",
     "A quote is not closed", "A text or character starts with a quote but doesn't end. Add the closing quote.",
     "علامة اقتباس غير مغلقة", "بدأ نص أو حرف بعلامة اقتباس ولم ينتهِ. أضف علامة الاقتباس الختامية."),
    (r"error: '(\w+)' does not name a type",
     "'<1>' is not a type", "A missing #include / using, a typo in a type name, or code written outside a function.",
     "'<1>' ليس نوعًا", "قد يكون #include أو using ناقصًا، أو خطأ إملائي في اسم النوع، أو كود مكتوب خارج الدالة."),
    (r"error: redefinition of",
     "Defined twice", "The same function, variable or class is written twice. Remove one copy.",
     "معرّف مرتين", "الدالة أو المتغير أو الكلاس مكتوب مرتين. احذف إحدى النسختين."),
    (r"error: expected primary-expression before",
     "Something is missing before this symbol", "Often an extra or missing operator, comma or parenthesis near the reported position.",
     "شيء ناقص قبل هذا الرمز", "غالبًا يوجد رمز أو فاصلة أو قوس زائد أو ناقص قرب الموضع المذكور."),
    (r"warning: control reaches end of non-void function",
     "A function may end without returning", "Add a return statement on every path through the function.",
     "قد تنتهي الدالة بدون return", "أضف return في كل مسار من مسارات الدالة."),
    (r"warning: unused variable '(\w+)'",
     "Variable '<1>' is never used", "Harmless. Remove it or use it.",
     "المتغير '<1>' غير مستخدم", "غير مؤذٍ. احذفه أو استخدمه."),
    (r"warning: comparison of integer expressions of different signedness",
     "Comparing signed and unsigned numbers", "Use the same kind on both sides (for example size_t for sizes) or cast one side.",
     "مقارنة بين رقم بإشارة وآخر بدون إشارة", "استخدم نفس النوع في الطرفين (مثل size_t للأحجام) أو حوّل أحدهما."),
    (r"exit code (?:-1073741819|3221225477)",
     "Crash: invalid memory access", "Typical causes: an array index out of range, an uninitialised or null pointer, using deleted memory. Check every index and pointer.",
     "انهيار: وصول خاطئ للذاكرة", "الأسباب المعتادة: فهرس مصفوفة خارج النطاق، أو مؤشر غير مهيّأ أو null، أو استخدام ذاكرة محذوفة. افحص كل فهرس ومؤشر."),
    (r"exit code (?:-1073741571|3221225725)",
     "Stack overflow", "Recursion that goes too deep, or very large local arrays. Add a stopping condition, or make big arrays global / use std::vector.",
     "امتلاء المكدّس (Stack overflow)", "عودية عميقة جدًا أو مصفوفات محلية ضخمة. أضف شرط توقف، أو اجعل المصفوفة الكبيرة عامة / استخدم std::vector."),
    (r"exit code (?:-1073741676|3221225620)",
     "Division by zero", "An integer was divided by 0. Check the divisor first.",
     "قسمة على صفر", "تمت قسمة عدد صحيح على 0. افحص المقسوم عليه أولًا."),
    (r"stray '\\(\d+)' in program",
     "Strange character in the code", "Usually caused by copy-paste (curly quotes or invisible characters). Retype the reported line.",
     "رمز غريب في الكود", "غالبًا بسبب النسخ واللصق (علامات اقتباس منحنية أو رموز غير مرئية). أعد كتابة السطر المذكور."),
]
ERROR_GENERIC = {r"SyntaxError: invalid syntax"}


def explain_error(text, ar=False, limit=3):
    """Plain-language help for the common errors found in `text`. Instant, offline, free."""
    out, seen = [], 0
    for pat, te, be, ta, ba in ERROR_RULES:
        m = re.search(pat, text or "")
        if not m:
            continue
        if pat in ERROR_GENERIC and out:
            continue
        title, body = (ta, ba) if ar else (te, be)
        for i, g in enumerate(m.groups(), 1):
            title, body = title.replace("<%d>" % i, (g or "").strip()), body.replace("<%d>" % i, (g or "").strip())
        out.append("• " + title + "\n" + body)
        if len(out) >= limit:
            break
    return "\n\n".join(out)


# ----------------------------------------------------------------------------
#  Legend AI  -  no sign-up, no key, no cost by default
# ----------------------------------------------------------------------------
# Free online endpoints that speak the OpenAI chat protocol and need no key.
# They can change or get rate-limited, so the URL/model are editable in Settings > AI.
LLM7 = "https://api.llm7.io/v1/chat/completions"
FREE_CANDS = [(LLM7, "default", {"Authorization": "Bearer unused"}),        # anonymous: codestral, ~30 requests/min
              (LLM7, "fast", {"Authorization": "Bearer unused"}),
              ("https://text.pollinations.ai/openai", "openai", {})]           # anonymous: 1 reply / 30 s per IP
FREE_URLS = [c[0] for c in FREE_CANDS]
FREE_MODELS = ["default", "fast", "openai"]
CHAT_FREE = (LLM7, "fast")        # small talk: the light model (faster, saves the free quota)

_WORK_WORDS = ("code", "كود", "error", "خطأ", "غلط", "مشكلة", "bug", "fix", "صلح", "صحح", "اكتب", "write", "function", "دالة", "def ",
               "class", "كلاس", "loop", "لوب", "python", "بايثون", "c++", "cpp", "برنامج", "program", "run", "شغل", "file", "ملف",
               "explain", "اشرح", "شرح", "refactor", "حسن", "optimi", "test", "اختبار", "سطر", "line", "variable", "متغير",
               "هذا", "هذي", "هذه", "فيه", "this", "it ", "import", "compile", "traceback", "exception", "api", "sql", "html", "json")


def is_small_talk(text):
    """Greetings and chit-chat go to the light model; anything that smells like work goes to the strong one."""
    t = (text or "").strip().lower()
    if not t or len(t) > 140 or "\n" in t:
        return False
    if any(ch in t for ch in "()[]{}=<>;_`#/\\"):
        return False
    return not any(w in t for w in _WORK_WORDS)
UA = "LegendIDE/2.0 (+python-urllib)"


def total_ram_gb():
    """Best-effort physical RAM in GB (used to recommend a local model size)."""
    try:
        if IS_WIN:
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [("l", ctypes.c_ulong), ("m", ctypes.c_ulong), ("tp", ctypes.c_ulonglong),
                            ("ap", ctypes.c_ulonglong), ("tpf", ctypes.c_ulonglong), ("apf", ctypes.c_ulonglong),
                            ("tv", ctypes.c_ulonglong), ("av", ctypes.c_ulonglong), ("ae", ctypes.c_ulonglong)]
            s = MS()
            s.l = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(s))
            return s.tp / 2 ** 30
        if IS_MAC:
            return int(subprocess.check_output(["sysctl", "-n", "hw.memsize"]).strip()) / 2 ** 30
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemTotal"):
                    return int(line.split()[1]) / 2 ** 20
    except Exception:
        pass
    return 8.0


def recommended_local_model():
    gb = total_ram_gb()
    return "qwen2.5-coder:7b" if gb >= 15 else "qwen2.5-coder:3b" if gb >= 7 else "qwen2.5-coder:1.5b"


def ollama_models(url, timeout=0.9):
    """List of installed Ollama model names, or None when the server is not reachable."""
    try:
        req = urllib.request.Request(url.rstrip("/") + "/api/tags", headers={"User-Agent": UA})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
        return [m.get("name", "") for m in data.get("models", []) if m.get("name")]
    except Exception:
        return None


def ollama_pull(url, model, cb, cancel):
    """Download a model through the local Ollama server. cb(status, done, total). Returns True on success."""
    body = json.dumps({"name": model, "model": model, "stream": True}).encode("utf-8")
    req = urllib.request.Request(url.rstrip("/") + "/api/pull", data=body, method="POST",
                                 headers={"content-type": "application/json", "User-Agent": UA})
    with urllib.request.urlopen(req, timeout=90) as resp:
        for raw in resp:
            if cancel.is_set():
                return False
            line = raw.decode("utf-8", "replace").strip()
            if not line:
                continue
            ev = json.loads(line)
            if ev.get("error"):
                raise RuntimeError(str(ev["error"]))
            cb(ev.get("status", ""), int(ev.get("completed") or 0), int(ev.get("total") or 0))
            if ev.get("status") == "success":
                return True
    return True


class AIClient:
    """Streams a chat answer. Providers: 'auto' (local Ollama -> Claude key -> free online), 'free', 'ollama',
    'anthropic'. Nothing here needs an account unless the user chooses Claude."""

    def __init__(self, cfg):
        self.cfg = cfg
        self._probe_t = 0.0
        self._probe = None          # list of local models, [] (running but empty) or None (not running)
        self._probing = False

    # ---- provider resolution ------------------------------------------
    def api_key(self):
        return (self.cfg.get("ai_key") or os.environ.get("ANTHROPIC_API_KEY", "")).strip()

    def refresh_probe(self, force=False):
        """Check the local Ollama server in the background (never blocks the UI)."""
        if self._probing or (not force and time.time() - self._probe_t < 15):
            return
        self._probing = True

        def work():
            try:
                self._probe = ollama_models(self.cfg.get("ollama_url", "http://localhost:11434"))
                self._probe_t = time.time()
            finally:
                self._probing = False
        threading.Thread(target=work, daemon=True).start()

    def local_models(self, fresh=False):
        if fresh:                       # only call from a worker thread
            self._probe = ollama_models(self.cfg.get("ollama_url", "http://localhost:11434"))
            self._probe_t = time.time()
        return self._probe

    def provider(self, fresh=False):
        p = self.cfg.get("ai_provider", "auto")
        if p == "anthropic" and self.api_key():
            return "anthropic"
        if p in ("ollama", "free"):
            return p
        models = self.local_models(fresh)
        if models:
            return "ollama"
        if self.api_key():
            return "anthropic"
        return "free"

    def ollama_model(self, fresh=False):
        want = self.cfg.get("ollama_model", "qwen2.5-coder:7b")
        have = self.local_models(fresh) or []
        if not have or want in have:
            return want
        base = [m for m in have if m.split(":")[0] == want.split(":")[0]]
        coder = [m for m in have if "coder" in m]
        return (base or coder or have)[0]

    def ready(self):
        return True

    def describe(self):
        p = self.provider()
        if p == "ollama":
            return "Local · " + self.ollama_model()
        if p == "anthropic":
            return "Claude · " + self.cfg.get("ai_model", "")
        return "Free · built-in"

    def private(self):
        return self.provider() == "ollama"

    def system_prompt(self):
        rule = AI_LANG_RULE.get(self.cfg.get("ai_reply", "Arabic"), AI_LANG_RULE["Arabic"])
        name = (self.cfg.get("user_name") or "").strip()
        return AI_SYSTEM.format(lang_rule=rule) + ("\nThe user's name is %s." % name[:40] if name else "")

    # ---- running a request ----------------------------------------------
    def start(self, system, messages, q, rid, cancel, max_tokens=4096, chat=False):
        threading.Thread(target=self._run, args=(system, messages, q, rid, cancel, max_tokens, chat), daemon=True).start()

    def _run(self, system, messages, q, rid, cancel, max_tokens, chat=False):
        gen = None
        try:
            prov = self.provider(fresh=self.cfg.get("ai_provider", "auto") == "auto")
            if prov == "ollama":
                gen = self._ollama(system, messages, cancel)
            elif prov == "anthropic":
                gen = self._anthropic(system, messages, cancel, max_tokens)
            else:
                gen = self._free(system, messages, cancel, max_tokens, chat)
            for piece in gen:
                if cancel.is_set():
                    break
                q.put((rid, "delta", piece))
            q.put((rid, "done", None))
        except Exception as e:
            q.put((rid, "error", self.friendly(e)))
        finally:
            if gen is not None:
                try:
                    gen.close()
                except Exception:
                    pass

    def _openai_stream(self, url, model, system, messages, cancel, max_tokens, headers=None):
        body = json.dumps({"model": model, "stream": True, "max_tokens": max_tokens,
                           "messages": [{"role": "system", "content": system}] + messages}).encode("utf-8")
        h = {"content-type": "application/json", "accept": "text/event-stream", "User-Agent": UA}
        h.update(headers or {})
        req = urllib.request.Request(url, data=body, method="POST", headers=h)
        plain = []
        got = False
        with urllib.request.urlopen(req, timeout=25) as resp:
            for raw in resp:
                if cancel.is_set():
                    return
                line = raw.decode("utf-8", "replace").strip()
                if not line:
                    continue
                if not line.startswith("data:"):
                    plain.append(line)
                    continue
                data = line[5:].strip()
                if not data or data == "[DONE]":
                    continue
                try:
                    ev = json.loads(data)
                except ValueError:
                    continue
                if isinstance(ev, dict) and ev.get("error"):
                    err = ev["error"]
                    raise RuntimeError(err.get("message", "AI error") if isinstance(err, dict) else str(err))
                for ch in (ev.get("choices") or []) if isinstance(ev, dict) else []:
                    piece = (ch.get("delta") or {}).get("content") or (ch.get("message") or {}).get("content")
                    if piece:
                        got = True
                        yield piece
        if not got and plain:                       # server ignored stream=true: plain JSON or plain text
            text = "\n".join(plain)
            try:
                ev = json.loads(text)
                piece = ((ev.get("choices") or [{}])[0].get("message") or {}).get("content")
                if not piece and isinstance(ev, dict) and ev.get("error"):
                    raise RuntimeError(str(ev["error"]))
            except ValueError:
                piece = text
            if piece:
                yield piece

    def _free_get(self, system, messages, cancel):
        """Last resort: the simple GET text endpoint (works for anonymous users when the chat endpoint is refused)."""
        import urllib.parse
        last = messages[-1]["content"] if messages else ""
        prompt = (last[-6000:])
        url = "https://text.pollinations.ai/" + urllib.parse.quote(prompt, safe="") + "?" + urllib.parse.urlencode(
            {"system": system[:1500], "model": "openai"})
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        with urllib.request.urlopen(req, timeout=60) as r:
            text = r.read().decode("utf-8", "replace").strip()
        if not text:
            raise RuntimeError("The free AI service sent an empty answer.")
        yield text

    def _free(self, system, messages, cancel, max_tokens, chat=False):
        """Free online models, tried ONE at a time (parallel requests only burn the per-IP limits).
        The last one that worked goes first next time."""
        custom = (self.cfg.get("free_url") or "").strip()
        if custom:
            cands = [(custom, (self.cfg.get("free_model") or "").strip() or "default", {})]
        else:
            cands = list(FREE_CANDS)
            ok = (self.cfg.get("free_ok_url"), self.cfg.get("free_ok_model"))
            if chat:                                   # small talk: light model first, strong ones still behind it
                ok = CHAT_FREE
            for i, c in enumerate(cands):
                if (c[0], c[1]) == ok:
                    cands.insert(0, cands.pop(i))
                    break
        err = None
        for url, model, hdr in cands:
            if cancel.is_set():
                return
            got = False
            try:
                for piece in self._openai_stream(url, model, system, messages, cancel, max_tokens, headers=hdr):
                    if not got:
                        got = True
                        if not chat:
                            self.cfg["free_ok_url"], self.cfg["free_ok_model"] = url, model
                    yield piece
                if got:
                    return
                err = RuntimeError("The free AI service sent an empty answer.")
            except Exception as e:
                if got:                       # failed in the middle of an answer: say so, do not restart silently
                    raise
                err = e
        if cancel.is_set():
            return
        try:
            for piece in self._free_get(system, messages, cancel):
                yield piece
        except Exception:
            raise err or RuntimeError("No free AI service answered.")

    def _anthropic(self, system, messages, cancel, max_tokens):
        base = self.cfg.get("anthropic_url", "https://api.anthropic.com").rstrip("/")
        body = json.dumps({"model": self.cfg.get("ai_model", "claude-sonnet-5-5"), "max_tokens": max_tokens,
                           "system": system, "messages": messages, "stream": True}).encode("utf-8")
        req = urllib.request.Request(base + "/v1/messages", data=body, method="POST", headers={
            "content-type": "application/json", "x-api-key": self.api_key(), "anthropic-version": "2023-06-01",
            "User-Agent": UA})
        with urllib.request.urlopen(req, timeout=120) as resp:
            for raw in resp:
                if cancel.is_set():
                    return
                line = raw.decode("utf-8", "replace").strip()
                if not line.startswith("data:"):
                    continue
                data = line[5:].strip()
                if not data or data == "[DONE]":
                    continue
                ev = json.loads(data)
                t = ev.get("type")
                if t == "content_block_delta":
                    d = ev.get("delta", {})
                    if d.get("type") == "text_delta" and d.get("text"):
                        yield d["text"]
                elif t == "error":
                    raise RuntimeError((ev.get("error") or {}).get("message", "API error"))
                elif t == "message_stop":
                    return

    def _ollama(self, system, messages, cancel):
        base = self.cfg.get("ollama_url", "http://localhost:11434").rstrip("/")
        body = json.dumps({"model": self.ollama_model(), "stream": True,
                           "messages": [{"role": "system", "content": system}] + messages}).encode("utf-8")
        req = urllib.request.Request(base + "/api/chat", data=body, method="POST",
                                     headers={"content-type": "application/json", "User-Agent": UA})
        with urllib.request.urlopen(req, timeout=300) as resp:
            for raw in resp:
                if cancel.is_set():
                    return
                line = raw.decode("utf-8", "replace").strip()
                if not line:
                    continue
                ev = json.loads(line)
                if ev.get("error"):
                    raise RuntimeError(str(ev["error"]))
                piece = (ev.get("message") or {}).get("content")
                if piece:
                    yield piece
                if ev.get("done"):
                    return

    def friendly(self, e):
        prov = self.provider()
        if isinstance(e, urllib.error.HTTPError):
            try:
                detail = json.loads(e.read().decode("utf-8", "replace"))
                detail = (detail.get("error") or {}).get("message") if isinstance(detail.get("error"), dict) \
                    else detail.get("error")
            except Exception:
                detail = None
            c = e.code
            if prov == "free":
                if c in (402, 429):
                    return ("The free AI service is busy right now (rate limit). Wait a minute and try again, "
                            "or set up a local model in Settings > AI for unlimited use.")
                return "The free AI service answered with an error (%d). Try again, or set up a local model." % c
            if c == 401:
                return "Invalid API key (401). Check it in Settings > AI."
            if c == 403:
                return "Access denied (403). Your key may not have access to this model."
            if c == 404:
                return "Model not found (404): %s. Check the model name in Settings > AI%s." % (
                    self.ollama_model() if prov == "ollama" else self.cfg.get("ai_model"),
                    " - or run: ollama pull " + self.cfg.get("ollama_model", "") if prov == "ollama" else "")
            if c == 429:
                return "Rate limit reached (429). Wait a moment and try again."
            if c in (500, 502, 503, 529):
                return "The AI service is busy right now (%d). Try again shortly." % c
            return "AI error %d: %s" % (c, detail or e.reason)
        if isinstance(e, urllib.error.URLError) or isinstance(e, ConnectionError):
            if prov == "ollama":
                return ("Can't reach the local model at %s. Is Ollama running? (Settings > AI can set it up)"
                        % self.cfg.get("ollama_url"))
            r = str(getattr(e, "reason", e))
            if "CERTIFICATE" in r.upper():
                return "SSL certificate error. On macOS run 'Install Certificates.command' from your Python folder."
            if prov == "free":
                return ("Can't reach the free AI service - check your internet connection. "
                        "A local model (Settings > AI) works offline.")
            return "No internet connection to the AI service (%s)." % r
        if isinstance(e, TimeoutError) or "timed out" in str(e):
            return "The AI took too long to answer (timeout)."
        return "AI error: %s" % e




# ----------------------------------------------------------------------------
#  UI primitives: theme holder, vector icons, buttons, tooltips, menus, toasts
# ----------------------------------------------------------------------------
_CUR = {"theme": THEMES["Legend Dark"]}


def T():
    """The theme currently in use (primitives read it at paint time, so a theme switch is instant)."""
    return _CUR["theme"]


# ---- animation engine -------------------------------------------------------------------



class Anim:
    """ONE shared clock for every animation (~120 Hz while something moves, zero wake-ups while idle).
    Progress is time based, so motion keeps its speed on a slow machine (it just gets less fine-grained)."""
    TICK = 8

    def __init__(self, root, cfg, on_error=None):
        self.root, self.cfg, self.on_error = root, cfg, on_error
        self.jobs = {}
        self._after = None
        self._hires = False
        self.force_off = False
        self._tick_ms = 8.0
        self._ticking = False

    @property
    def on(self):
        return bool(self.cfg.get("animations", True)) and not self.cfg.get("lite") and not self.force_off

    def _hi_res(self, on):
        """Windows' default timer ticks every 15.6 ms; ask for 1 ms only while animating (then give it back)."""
        if IS_WIN and on != self._hires:
            try:
                import ctypes
                (ctypes.windll.winmm.timeBeginPeriod if on else ctypes.windll.winmm.timeEndPeriod)(1)
                self._hires = on
            except Exception:
                self._hires = on

    def run(self, key, ms, step, done=None, ease=ease_out, delay=0):
        """Call step(p) with eased progress 0..1 for `ms` ms. Re-using a key replaces the running animation."""
        if not self.on or ms <= 0:
            self.jobs.pop(key, None)
            step(1.0)
            if done:
                done()
            return
        lvl = self.cfg.get("anim_level")
        ms *= 0.65 if lvl == "subtle" else 1.3 if lvl == "expressive" else 1.0
        self.jobs[key] = [time.perf_counter() + delay / 1000.0, ms / 1000.0, step, done, ease]
        if self._after is None and not self._ticking:          # ONE clock only: a tween started inside a frame joins it
            self._hi_res(True)
            self._after = self.root.after(1, self._tick)

    def cancel(self, key):
        self.jobs.pop(key, None)

    def _tick(self):
        self._after = None
        self._ticking = True
        try:
            self._frame()
        finally:
            self._ticking = False
        if self.jobs:
            if self._after is None:
                self._after = self.root.after(int(self._tick_ms), self._tick)
        else:
            self._hi_res(False)

    def _frame(self):
        now = time.perf_counter()
        finished = []
        for key, job in list(self.jobs.items()):
            t0, dur, step, done, ease = job
            if now < t0 or self.jobs.get(key) is not job:
                continue
            p = min(1.0, (now - t0) / dur)
            try:
                step(ease(p))
            except tk.TclError:                         # the widget was destroyed mid-animation: just drop it
                finished.append((key, job, False))
                continue
            except Exception:
                finished.append((key, job, False))
                if self.on_error:
                    self.on_error(*sys.exc_info())
                continue
            if p >= 1.0:
                finished.append((key, job, True))
        for key, job, ok in finished:
            if self.jobs.get(key) is job:
                del self.jobs[key]
            if ok and job[3]:
                try:
                    job[3]()
                except tk.TclError:
                    pass
        try:
            self.root.update_idletasks()               # draw this frame NOW (otherwise Tk batches frames and motion stutters)
        except tk.TclError:
            pass
        work = (time.perf_counter() - now) * 1000.0
        self._tick_ms = max(8.0, min(33.0, 0.7 * self._tick_ms + 0.3 * (work * 1.15)))   # expensive frames -> fewer, steadier frames


ANIM = [None]


def tween(key, ms, step, done=None, ease=ease_out, delay=0):
    """Module-level shortcut: runs at once when no animation clock exists (e.g. in tests)."""
    a = ANIM[0]
    if a is None:
        step(1.0)
        if done:
            done()
        return
    a.run(key, ms, step, done, ease, delay)


def borderless(w):
    """Frameless window. On macOS a plain override-redirect window can't take keyboard focus, so use the native style."""
    if IS_MAC:
        try:
            w.tk.call("::tk::unsupported::MacWindowStyle", "style", w._w, "plain", "none")
            return
        except tk.TclError:
            pass
    w.wm_overrideredirect(True)


def show_window(w, x, y, dy=-8, ms=150):
    """Show a withdrawn borderless window with a short fade + slide (or immediately when animations are off).
    Expressive style: a longer drop with a small spring at the end."""
    a = ANIM[0]
    try:
        ease = ease_out
        if a is not None and a.on and a.cfg.get("anim_level") == "expressive":
            dy, ease = dy * 2.2, ease_out_back
        if a is not None and a.on:
            w.attributes("-alpha", 0.0)
            w.geometry("+%d+%d" % (x, y + dy))
            w.deiconify()
            w.lift()

            def step(p):
                w.attributes("-alpha", p)
                w.attributes("-alpha", max(0.0, min(1.0, p * 1.6)))
                w.geometry("+%d+%d" % (x, y + int(dy * (1 - ease(p)))))
            tween(("win", str(w)), ms, step, lambda: (w.attributes("-alpha", 1.0), w.geometry("+%d+%d" % (x, y))), ease=lambda p: p)
        else:
            w.geometry("+%d+%d" % (x, y))
            w.deiconify()
    except tk.TclError:
        pass


class SmoothWheel:
    """Eased mouse-wheel scrolling (inertia). kind 'text' scrolls in pixels, 'canvas' by fractions.
    Rides on the shared clock, so it costs nothing while you are not scrolling."""

    def __init__(self, w, kind="text", line_px=None, bind=True):
        self.w, self.kind, self.line_px = w, kind, line_px or (lambda: 40)
        self.pending = 0.0
        self.rem = 0.0
        self.last = 0.0
        self.key = ("wheel", id(w))
        if bind:
            w.bind("<MouseWheel>", self.on_wheel, add="+")
            w.bind("<Button-4>", lambda e: self.add_lines(-3), add="+")
            w.bind("<Button-5>", lambda e: self.add_lines(3), add="+")

    def on_wheel(self, e):
        if e.state & 0x0005:                    # Shift / Control are handled elsewhere (horizontal scroll, zoom)
            return None
        k = (ANIM[0].cfg.get("scroll_lines", 3) / 3.0) if ANIM[0] else 1.0
        self.add_lines((-e.delta if IS_MAC else -(e.delta / 120.0) * 3) * k)
        return "break"

    def add_lines(self, lines):
        self.pending += lines * self.line_px()
        a = ANIM[0]
        if a is None or not a.on or not a.cfg.get("smooth_scroll", True):
            self._apply(self.pending)
            self.pending = 0.0
            return "break"
        if self.key not in a.jobs:
            self.last = time.perf_counter()
            a.run(self.key, 600000, self._step)
        return "break"

    def _step(self, p):
        now = time.perf_counter()
        dt = min(now - self.last, 0.05)
        self.last = now
        move = self.pending if abs(self.pending) < 1.2 else self.pending * (1 - math.exp(-dt / 0.07))
        total = move + self.rem
        n = int(total)
        self.rem = total - n
        if n:
            self._apply(n)
        self.pending -= move
        if abs(self.pending) < 0.4 and abs(self.rem) < 1:
            self.pending = self.rem = 0.0
            ANIM[0].cancel(self.key)

    def _apply(self, n):
        n = int(round(n))
        if not n:
            return
        if self.kind == "text":
            self.w.yview_scroll(n, "pixels")
        else:
            top, bottom = self.w.yview()
            span = bottom - top
            if span >= 0.999:
                return
            total_px = max(self.w.winfo_height(), 1) / span
            self.w.yview_moveto(max(0.0, min(1.0 - span, top + n / total_px)))



def rr_points(x1, y1, x2, y2, r):
    r = max(0.0, min(r, (x2 - x1) / 2.0, (y2 - y1) / 2.0))
    return [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2, x1, y2,
            x1, y2 - r, x1, y1 + r, x1, y1]


def round_rect(c, x1, y1, x2, y2, r=6, **kw):
    if r < 1.5:
        return c.create_polygon(x1, y1, x2, y1, x2, y2, x1, y2, **kw)
    return c.create_polygon(rr_points(x1, y1, x2, y2, r), smooth=True, **kw)


def draw_icon(c, name, x, y, s, col, w=1.5):
    try:
        _draw_icon(c, name, x, y, s, col, w)
    except tk.TclError:
        pass


def _draw_icon(c, name, x, y, s, col, w=1.5):
    """Tiny vector icons drawn on a canvas (no image files). (x, y) = centre, s = half size."""
    ln = dict(fill=col, width=w, capstyle="round")
    if name == "files":
        c.create_polygon(x - s * .65, y - s, x + s * .15, y - s, x + s * .65, y - s * .45, x + s * .65, y + s,
                         x - s * .65, y + s, outline=col, fill="", width=w, joinstyle="round")
        c.create_line(x + s * .15, y - s, x + s * .15, y - s * .45, x + s * .65, y - s * .45, **ln)
        c.create_line(x - s * .3, y + s * .1, x + s * .3, y + s * .1, **ln)
        c.create_line(x - s * .3, y + s * .5, x + s * .3, y + s * .5, **ln)
    elif name == "search":
        c.create_oval(x - s, y - s, x + s * .35, y + s * .35, outline=col, width=w + .3)
        c.create_line(x + s * .25, y + s * .25, x + s, y + s, fill=col, width=w + .8, capstyle="round")
    elif name == "run":
        c.create_polygon(x - s * .55, y - s * .85, x + s * .85, y, x - s * .55, y + s * .85, fill=col, outline=col,
                         joinstyle="round", width=1)
    elif name == "stop":
        round_rect(c, x - s * .7, y - s * .7, x + s * .7, y + s * .7, 2, fill=col, outline=col)
    elif name == "build":
        c.create_line(x - s * .85, y + s * .85, x + s * .15, y - s * .15, fill=col, width=w + 1.2, capstyle="round")
        c.create_polygon(x - s * .05, y - s * .95, x + s * .95, y - s * .05, x + s * .55, y + s * .35,
                         x - s * .55, y - s * .65, outline=col, fill=col, joinstyle="round")
    elif name == "ai":
        def star(cx, cy, r):
            k = r * .26
            c.create_polygon(cx, cy - r, cx + k, cy - k, cx + r, cy, cx + k, cy + k, cx, cy + r, cx - k, cy + k,
                             cx - r, cy, cx - k, cy - k, fill=col, outline=col, joinstyle="round")
        star(x - s * .15, y + s * .1, s * .85)
        star(x + s * .72, y - s * .72, s * .38)
    elif name == "gear":
        import math
        for i in range(8):
            a = i * math.pi / 4
            c.create_line(x + math.cos(a) * s * .62, y + math.sin(a) * s * .62, x + math.cos(a) * s,
                          y + math.sin(a) * s, fill=col, width=w + 1.6, capstyle="butt")
        c.create_oval(x - s * .66, y - s * .66, x + s * .66, y + s * .66, outline=col, width=w)
        c.create_oval(x - s * .25, y - s * .25, x + s * .25, y + s * .25, outline=col, width=w)
    elif name == "plus":
        c.create_line(x - s * .8, y, x + s * .8, y, **ln)
        c.create_line(x, y - s * .8, x, y + s * .8, **ln)
    elif name == "close":
        c.create_line(x - s * .65, y - s * .65, x + s * .65, y + s * .65, **ln)
        c.create_line(x - s * .65, y + s * .65, x + s * .65, y - s * .65, **ln)
    elif name in ("folder", "openfolder"):
        c.create_polygon(x - s, y - s * .6, x - s * .35, y - s * .6, x - s * .05, y - s * .3, x + s, y - s * .3,
                         x + s, y + s * .75, x - s, y + s * .75, outline=col, fill="", width=w, joinstyle="round")
    elif name == "newfile":
        c.create_polygon(x - s * .65, y - s, x + s * .15, y - s, x + s * .65, y - s * .45, x + s * .65, y + s,
                         x - s * .65, y + s, outline=col, fill="", width=w, joinstyle="round")
        c.create_line(x - s * .2, y + s * .15, x + s * .2, y + s * .15, **ln)
        c.create_line(x, y - s * .05, x, y + s * .35, **ln)
    elif name == "newfolder":
        c.create_polygon(x - s, y - s * .6, x - s * .35, y - s * .6, x - s * .05, y - s * .3, x + s, y - s * .3,
                         x + s, y + s * .75, x - s, y + s * .75, outline=col, fill="", width=w, joinstyle="round")
        c.create_line(x - s * .25, y + s * .22, x + s * .25, y + s * .22, **ln)
        c.create_line(x, y - s * .05, x, y + s * .5, **ln)
    elif name == "refresh":
        c.create_arc(x - s * .8, y - s * .8, x + s * .8, y + s * .8, start=40, extent=285, style="arc",
                     outline=col, width=w)
        c.create_polygon(x + s * .55, y - s * 1.0, x + s * .95, y - s * .3, x + s * .2, y - s * .35, fill=col,
                         outline=col)
    elif name == "home":
        c.create_polygon(x - s, y, x, y - s * .9, x + s, y, outline=col, fill="", width=w, joinstyle="round")
        c.create_polygon(x - s * .65, y - s * .1, x - s * .65, y + s * .85, x + s * .65, y + s * .85, x + s * .65,
                         y - s * .1, outline=col, fill="", width=w)
    elif name == "save":
        c.create_polygon(x - s * .8, y - s * .8, x + s * .5, y - s * .8, x + s * .8, y - s * .5, x + s * .8,
                         y + s * .8, x - s * .8, y + s * .8, outline=col, fill="", width=w, joinstyle="round")
        c.create_rectangle(x - s * .4, y + s * .1, x + s * .4, y + s * .8, outline=col, width=w)
        c.create_rectangle(x - s * .35, y - s * .8, x + s * .15, y - s * .3, outline=col, width=w)
    elif name == "open":
        c.create_polygon(x - s, y - s * .6, x - s * .35, y - s * .6, x - s * .05, y - s * .3, x + s * .7, y - s * .3,
                         x + s * .7, y, outline=col, fill="", width=w, joinstyle="round")
        c.create_polygon(x - s, y + s * .75, x - s * .6, y - s * .05, x + s, y - s * .05, x + s * .6, y + s * .75,
                         outline=col, fill="", width=w, joinstyle="round")
    elif name == "file":
        c.create_polygon(x - s * .65, y - s, x + s * .15, y - s, x + s * .65, y - s * .45, x + s * .65, y + s,
                         x - s * .65, y + s, outline=col, fill="", width=w, joinstyle="round")
    elif name == "panel":
        c.create_rectangle(x - s, y - s * .8, x + s, y + s * .8, outline=col, width=w)
        c.create_line(x - s, y + s * .2, x + s, y + s * .2, fill=col, width=w)
    elif name == "sidebar":
        c.create_rectangle(x - s, y - s * .8, x + s, y + s * .8, outline=col, width=w)
        c.create_line(x - s * .3, y - s * .8, x - s * .3, y + s * .8, fill=col, width=w)
    elif name == "trash":
        c.create_line(x - s * .8, y - s * .55, x + s * .8, y - s * .55, **ln)
        c.create_polygon(x - s * .55, y - s * .4, x + s * .55, y - s * .4, x + s * .4, y + s * .9, x - s * .4,
                         y + s * .9, outline=col, fill="", width=w, joinstyle="round")
        c.create_line(x - s * .25, y - s * .8, x + s * .25, y - s * .8, **ln)
    elif name == "chev":
        c.create_line(x - s * .6, y - s * .3, x, y + s * .35, x + s * .6, y - s * .3, joinstyle="round", **ln)
    elif name == "terminal":
        c.create_line(x - s * .8, y - s * .5, x - s * .1, y, x - s * .8, y + s * .5, joinstyle="round", **ln)
        c.create_line(x + s * .1, y + s * .6, x + s * .85, y + s * .6, **ln)
    elif name == "warn":
        c.create_polygon(x, y - s * .9, x + s, y + s * .8, x - s, y + s * .8, outline=col, fill="", width=w,
                         joinstyle="round")
        c.create_line(x, y - s * .3, x, y + s * .25, **ln)
    elif name == "bolt":
        c.create_polygon(x + s * .2, y - s, x - s * .6, y + s * .15, x - s * .05, y + s * .15, x - s * .2, y + s,
                         x + s * .6, y - s * .2, x + s * .05, y - s * .2, fill=col, outline=col, joinstyle="round")


LOGO = dict(bg="#12151C", edge="#2B3141", amber="#F2B84B", cream="#F6EBD0")


def draw_logo(c, x, y, s, glow=False, fade=1.0):
    """Legend Code mark: a dark tile with a squared-C code bracket whose lower half is the letter L.
    (x, y) = centre, s = half of the tile size. The colours are fixed - it is a brand mark, not a theme colour."""
    th = T()
    k = 2.0 * s / 480.0
    if glow:
        for i in range(14, 0, -1):
            r = s * (1 + i * .16)
            c.create_oval(x - r, y - r, x + r, y + r, fill=mix(th["bg"], th["accent"], .014 * (15 - i) * fade), outline="")
    fz = lambda col: mix(th["bg"], col, fade)
    round_rect(c, x - s, y - s, x + s, y + s, 112 * k, fill=fz(LOGO["bg"]), outline=fz(LOGO["edge"] if s >= 14 else LOGO["bg"]))
    g = 1.28 if s < 14 else 1.0                       # tiny sizes: a slightly larger glyph stays readable

    def pts(lst):
        out = []
        for px, py in lst:
            out += [x + (256 + (px - 256) * g - 256) * k, y + (256 + (py - 256) * g - 256) * k]
        return out
    c.create_polygon(pts([(140, 110), (380, 110), (346, 194), (140, 194)]), fill=fz(LOGO["cream"]), outline="")
    c.create_polygon(pts([(140, 194), (224, 194), (224, 318), (380, 318), (346, 402), (140, 402)]), fill=fz(LOGO["amber"]), outline="")


# ---- tooltip ----------------------------------------------------------------
class Tooltip:
    def __init__(self, w, text, side="below", delay=500):
        self.w, self.text, self.side, self.delay = w, text, side, delay
        self.tw = None
        self.job = None
        w.bind("<Enter>", self._enter, add="+")
        w.bind("<Leave>", self._leave, add="+")
        w.bind("<ButtonPress>", self._leave, add="+")
        w.bind("<Destroy>", self._leave, add="+")

    def _enter(self, e=None):
        self._leave()
        self.job = self.w.after(self.delay, self._show)

    def _leave(self, e=None):
        if self.job:
            try:
                self.w.after_cancel(self.job)
            except Exception:
                pass
            self.job = None
        if self.tw is not None:
            try:
                self.tw.destroy()
            except Exception:
                pass
            self.tw = None

    def _show(self):
        self.job = None
        text = K(tr(self.text() if callable(self.text) else self.text))
        if not text:
            return
        try:
            th = T()
            tw = tk.Toplevel(self.w)
            tw.wm_overrideredirect(True)
            tw.configure(bg=th["border"])
            TLabel(tw, text=text, bg=th["pop"], fg=th["fg"], padx=9, pady=4, font=("Segoe UI" if IS_WIN else "TkDefaultFont", fs(9)),
                     justify="left").pack(padx=1, pady=1)
            if self.side == "right":
                x, y = self.w.winfo_rootx() + self.w.winfo_width() + 6, self.w.winfo_rooty() + 4
            else:
                x, y = self.w.winfo_rootx(), self.w.winfo_rooty() + self.w.winfo_height() + 6
            tw.geometry("+%d+%d" % (x, y))
            self.tw = tw
        except Exception:
            self.tw = None


# ---- buttons ----------------------------------------------------------------
def fade_attr(w, attr, target, ms=130, ease=ease_out, paint="paint"):
    """Ease w.<attr> to `target` and repaint every frame (hover, press and active states all use this)."""
    a = getattr(w, attr)
    fn = getattr(w, paint)
    tween((attr, id(w)), ms, lambda p: (setattr(w, attr, a + (target - a) * p), fn()), ease=ease)


class IconButton(tk.Canvas):
    """Square icon button. hover / pressed / active are three eased 0..1 values, so every state change glides."""

    def __init__(self, master, icon, command, tip="", size=32, role="bar", isize=8, side="below", mark=False, hue=None):
        super().__init__(master, width=size, height=size, highlightthickness=0, bd=0, cursor="hand2")
        self.icon, self.cmd, self.size, self.role, self.isize, self.mark, self.hue = icon, command, size, role, isize, mark, hue
        self.hover = self.active = False
        self.hv = self.pr = self.ap = 0.0
        self.enabled = True
        self.bind("<Enter>", lambda e: self._set(True))
        self.bind("<Leave>", lambda e: self._set(False))
        self.bind("<ButtonPress-1>", self._down)
        self.bind("<ButtonRelease-1>", self._click)
        if tip:
            Tooltip(self, tip, side=side)
        self.paint()

    def _set(self, hover):
        self.hover = hover
        fade_attr(self, "hv", 1.0 if hover else 0.0)

    def _down(self, e):
        if self.enabled:
            fade_attr(self, "pr", 1.0, 70)

    def _click(self, e):
        fade_attr(self, "pr", 0.0, 220, ease_out_quint)
        if self.enabled and 0 <= e.x < self.size and 0 <= e.y < self.size and self.cmd:
            self.cmd()

    def set_active(self, on):
        self.active = on
        fade_attr(self, "ap", 1.0 if on else 0.0, 260, ease_out_quint)

    def set_enabled(self, on):
        self.enabled = on
        self.configure(cursor="hand2" if on else "arrow")
        self.paint()

    def paint(self):
        th, s = T(), self.size
        self.delete("all")
        self.configure(bg=th[self.role])
        k = max(self.hv, self.ap) if self.enabled else 0.0
        self._imgs = []
        if not self.mark and (k > .01 or self.pr > .01):
            col = mix(th[self.role], th["hover"], k)
            if self.pr > .01:
                col = mix(col, th["accent"], .22 * self.pr)
            g = glass_colors(th, col, .6) if th.get("glass") else None
            aa_round_rect(self, 2, 2, s - 2, s - 2, R(9), col, grad=g[0] if g else None, rim=g[1] if g else None)
        hue = self.hue if th.get("hues") else None
        if self.mark and self.ap > .01:
            h = (s - 14) * self.ap
            self.create_rectangle(0, s / 2 - h / 2, 2, s / 2 + h / 2, fill=hue or th["accent"], outline="")
        if not self.enabled:
            col = th["dim"]
        elif hue:
            col = mix(th["muted"], hue, .45 + .55 * k)
        else:
            col = mix(th["muted"], th["fg"], k)
        draw_icon(self, self.icon, s / 2, s / 2, self.isize * (1 - .10 * self.pr), col)

    retheme = paint


class Btn(tk.Canvas):
    """Text button (optional icon). kind: ghost | primary | success | danger | outline | ai"""

    def __init__(self, master, text, command, icon=None, kind="ghost", role="bar", height=30, tip="", padx=12,
                 bold=None, minw=0, font=None):
        self.text, self.cmd, self.icon, self.kind, self.role, self.h, self.padx = tr(text), command, icon, kind, role, height, padx
        self.hover = False
        self.hv = self.pr = 0.0
        self.enabled = True
        self._minw = minw
        base = font or tkfont.nametofont("TkDefaultFont")
        self.f = tkfont.Font(family=base.cget("family"), size=int(abs(int(base.cget("size")))) or 10,
                             weight="bold" if (bold if bold is not None else kind in ("primary", "success", "ai")) else "normal")
        super().__init__(master, width=self._calc_w(), height=height, highlightthickness=0, bd=0, cursor="hand2")
        self.bind("<Enter>", lambda e: self._set(True))
        self.bind("<Leave>", lambda e: self._set(False))
        self.bind("<ButtonPress-1>", self._down)
        self.bind("<ButtonRelease-1>", self._click)
        if tip:
            Tooltip(self, tip)
        self.paint()

    def _calc_w(self):
        w = self.padx * 2 + self.f.measure(visual(self.text)) + (22 if self.icon else 0)
        return max(w, self._minw)

    def _set(self, v):
        self.hover = v
        fade_attr(self, "hv", 1.0 if v else 0.0, 150)

    def _down(self, e):
        if self.enabled:
            fade_attr(self, "pr", 1.0, 70)

    def _click(self, e):
        fade_attr(self, "pr", 0.0, 220, ease_out_quint)
        if self.enabled and 0 <= e.x < int(self.cget("width")) and 0 <= e.y < self.h and self.cmd:
            self.cmd()

    def set_text(self, text):
        self.text = tr(text)
        self.configure(width=self._calc_w())
        self.paint()

    def set_enabled(self, on):
        self.enabled = on
        self.configure(cursor="hand2" if on else "arrow")
        self.paint()

    def _style(self, th, hot):
        """(fill, text colour, outline) for one state; '' = transparent."""
        fill, fg, outline = "", th["fg"], ""
        if self.kind == "primary":
            fill, fg = (mix(th["accent"], "#ffffff", .14) if hot else th["accent"]), th["accent_fg"]
        elif self.kind == "success":
            fill, fg = (mix(th["green"], "#ffffff", .14) if hot else th["green"]), "#06210f"
        elif self.kind == "danger":
            fill, fg, outline = (th["red"] if hot else ""), ("#ffffff" if hot else th["red"]), th["red"]
        elif self.kind == "outline":
            fill, outline = (th["hover"] if hot else ""), (th["accent"] if hot else th["border"])
        elif self.kind == "ai":
            fill, fg, outline = (mix(th[self.role], th["accent"], .18) if hot else mix(th[self.role], th["accent"], .08)), th["accent"], mix(th[self.role], th["accent"], .55)
        else:
            fill = th["hover"] if hot else ""
        if not self.enabled:
            fill, fg, outline = "", th["dim"], (th["border"] if self.kind in ("danger", "outline", "ai") else "")
        return fill, fg, outline

    def paint(self):
        th = T()
        self.delete("all")
        w, h = int(self.cget("width")), self.h
        bgc = th[self.role]
        self.configure(bg=bgc)
        k = self.hv if self.enabled else 0.0
        f0, g0, o0 = self._style(th, False)
        f1, g1, o1 = self._style(th, True) if self.enabled else (f0, g0, o0)
        fill = mix(f0 or bgc, f1 or bgc, k)
        fg = mix(g0, g1, k)
        outline = mix(o0 or bgc, o1 or bgc, k)
        if self.pr > .01:
            fill = mix(fill, "#000000" if th["dark"] or self.kind in ("primary", "success") else th["accent"], .14 * self.pr)
        self._imgs = []
        if f0 or f1 or o0 or o1 or self.pr > .01:
            g = glass_colors(th, fill, .7) if (th.get("glass") and (f0 or f1)) else None
            gx, gy = 1 + 1.6 * (1 - k) + 1.2 * self.pr, 1 + 1.0 * (1 - k) + 0.8 * self.pr      # grows ~4% on hover, presses in
            aa_round_rect(self, gx, gy, w - gx, h - gy, R(9), fill, line=outline if (o0 or o1) else None,
                          grad=g[0] if g else None, rim=g[1] if g else None)
        x = self.padx
        label = visual(self.text)
        if self.icon:
            draw_icon(self, self.icon, x + 6, h / 2, 6.5, fg, 1.4)
            x += 22
            self.create_text(x, h / 2, text=label, anchor="w", fill=fg, font=self.f)
        else:
            self.create_text(w / 2, h / 2, text=label, anchor="center", fill=fg, font=self.f)

    retheme = paint


class Chip(TLabel):
    """Small clickable status-bar / toolbar label with hover effect."""

    def __init__(self, master, text="", command=None, role="bar", font=None, padx=8, pady=2, fg="muted", tip=""):
        super().__init__(master, text=text, padx=padx, pady=pady, font=font, cursor="hand2" if command else "arrow", bd=0)
        self.role, self.cmd, self.fgkey, self.hover = role, command, fg, False
        self.hv = 0.0
        self.pinned = False
        self.fg_override = None
        self.bind("<Enter>", lambda e: self._h(True))
        self.bind("<Leave>", lambda e: self._h(False))
        self.bind("<ButtonRelease-1>", lambda e: self.cmd() if self.cmd else None)
        if tip:
            Tooltip(self, tip)
        self.retheme()

    def _h(self, v):
        self.hover = v
        a, b = self.hv, 1.0 if (v and self.cmd) else 0.0
        tween(("hv", id(self)), 130, lambda p: (setattr(self, "hv", a + (b - a) * p), self.retheme()))

    def retheme(self):
        th = T()
        k = max(self.hv if self.cmd else 0.0, 1.0 if self.pinned else 0.0)
        fg0 = self.fg_override or th[self.fgkey]
        fg1 = fg0 if self.fg_override else th["fg"]
        self.configure(bg=mix(th[self.role], th["hover"], k), fg=mix(fg0, fg1, k))


# ---- popup menu (replaces the plain native Tk menus) -----------------------------
class PopupMenu:
    """Rounded menu drawn on ONE canvas (fast to build, no widget per row) with a highlight that glides between rows.
    items: (label, shortcut, callback[, icon[, colour]])  |  None = separator.  callback None = disabled row."""
    ROW, PADX, PADY = 32, 7, 8
    KEY = "#010203"                       # Windows treats this colour as transparent -> genuinely rounded corners

    def __init__(self, app, items, x, y, minw=230, on_close=None):
        app.close_popup()
        self.app, self.on_close = app, on_close
        self.closed = False
        self.sel = -1
        self._hy = None
        th = T()
        f = app.ui_font
        items = list(items)
        has_icon = any(it is not None and len(it) > 3 and it[3] for it in items)
        left = 46 if has_icon else 20
        mw = 0
        for it in items:
            if it is not None:
                mw = max(mw, f.measure(visual(tr(it[0]))) + (f.measure(K(it[1])) + 40 if it[1] else 0))
        W = int(max(minw, mw + left + 26))
        self.rows, seps = [], []
        yy = self.PADY
        for it in items:
            if it is None:
                seps.append(yy + 4)
                yy += 9
            else:
                self.rows.append(dict(y=yy, it=it))
                yy += self.ROW
        H = int(yy + self.PADY)
        x = max(4, min(int(x), app.root.winfo_screenwidth() - W - 8))
        y = max(4, min(int(y), app.root.winfo_screenheight() - H - 12))
        w = tk.Toplevel(app.root)
        self.w = w
        w.withdraw()
        borderless(w)
        try:
            w.attributes("-topmost", True)
        except tk.TclError:
            pass
        rounded = False
        br_, bg_, bb_ = _rgb(th["border"])
        key = "#%02x%02x%02x" % (br_, bg_, bb_ ^ 1)               # almost the border colour: no dark fringe on the curve
        if IS_WIN:
            try:
                w.attributes("-transparentcolor", key)
                rounded = True
            except tk.TclError:
                pass
        base = key if rounded else th["pop"]
        w.configure(bg=base)
        cv = tk.Canvas(w, width=W, height=H, highlightthickness=0, bd=0, bg=base, cursor="arrow")
        cv.pack()
        self.cv, self.W = cv, W
        cv._imgs = []
        g = glass_colors(th, th["pop"], .8) if th.get("glass") else None
        aa_round_rect(cv, 0, 0, W, H, R(16) if rounded else 0, th["pop"], line=th["border"], grad=g[0] if g else None, rim=g[1] if g else None)
        self.hl_col = mix(th["pop"], th["accent"], .22)
        aa_round_rect(cv, self.PADX, -300, W - self.PADX, -300 + self.ROW - 2, R(10), self.hl_col, tag="hl")
        for sy in seps:
            cv.create_line(self.PADX + 12, sy, W - self.PADX - 12, sy, fill=th["border"])
        hues = th.get("hues")
        for rw in self.rows:
            it = rw["it"]
            label, key, fn = it[0], it[1], it[2]
            icon = it[3] if len(it) > 3 else None
            hue = it[4] if len(it) > 4 else None
            cy = rw["y"] + self.ROW / 2
            if icon:
                draw_icon(cv, icon, 28, cy, 7, (hue if (hues and hue) else th["muted"]) if fn else th["dim"], 1.4)
            cv.create_text(left, cy, text=visual(tr(label)), anchor="w", fill=th["fg"] if fn else th["dim"], font=f)
            if key:
                cv.create_text(W - 20, cy, text=K(key), anchor="e", fill=th["muted"] if fn else th["dim"], font=f)
        cv.bind("<Motion>", self._motion)
        cv.bind("<ButtonRelease-1>", self._release)
        for seq, fn in (("<Up>", lambda e: self.move(-1)), ("<Down>", lambda e: self.move(1)),
                        ("<Home>", lambda e: self.move(0, "first")), ("<End>", lambda e: self.move(0, "last")),
                        ("<Return>", lambda e: self.activate(self.sel)), ("<KP_Enter>", lambda e: self.activate(self.sel)),
                        ("<Escape>", lambda e: self.close()), ("<Key>", self._typeahead)):
            w.bind(seq, fn)
        show_window(w, x, y, dy=-10, ms=200)
        app.root.after(40, self._focus)
        app.popup = self

    def _focus(self):
        try:
            if not self.closed:
                self.w.focus_force()
        except Exception:
            pass

    def _enabled(self, i):
        return 0 <= i < len(self.rows) and self.rows[i]["it"][2] is not None

    def _row_at(self, y):
        for i, rw in enumerate(self.rows):
            if rw["y"] <= y < rw["y"] + self.ROW:
                return i
        return None

    def _motion(self, e):
        i = self._row_at(e.y)
        if i is not None and self._enabled(i):
            self.select(i)

    def _release(self, e):
        i = self._row_at(e.y)
        if i is not None:
            self.activate(i)

    def select(self, i):
        """Move the highlight (it glides from the previous row)."""
        if i == self.sel or not self._enabled(i) or self.closed:
            return
        self.sel = i
        ty = self.rows[i]["y"] + 1

        def put(yv):
            yv = int(round(yv))
            self.cv.move("hl", 0, yv - self._hy)
            self._hy = yv
        if self._hy is None:
            self._hy = -300
            put(ty)
            return
        a = self._hy
        tween(("menu-hl", id(self)), 200, lambda p: put(a + (ty - a) * p), ease=ease_out_quint)

    def move(self, d, where=None):
        idx = [i for i in range(len(self.rows)) if self._enabled(i)]
        if not idx:
            return "break"
        if where == "first" or (self.sel < 0 and d > 0):
            self.select(idx[0])
        elif where == "last" or (self.sel < 0 and d < 0):
            self.select(idx[-1])
        else:
            k = idx.index(self.sel) if self.sel in idx else 0
            self.select(idx[(k + d) % len(idx)])
        return "break"

    def _typeahead(self, e):
        ch = (e.char or "").lower()
        if ch and ch.isprintable() and not ch.isspace():
            idx = [i for i in range(len(self.rows)) if self._enabled(i)]
            order = [i for i in idx if i > self.sel] + [i for i in idx if i <= self.sel]
            for i in order:
                if tr(self.rows[i]["it"][0]).lower().startswith(ch):
                    self.select(i)
                    break

    def activate(self, i):
        if i is None or not self._enabled(i) or self.closed:
            return "break"
        fn = self.rows[i]["it"][2]
        self.close()
        self.app.root.after(14, fn)
        return "break"

    def close(self, fast=False):
        if self.closed:
            return
        self.closed = True
        if self.app.popup is self:
            self.app.popup = None
            self.app.menu_name = None
        cb, self.on_close = self.on_close, None
        if cb:
            try:
                cb()
            except Exception:
                pass
        w = self.w

        def kill():
            try:
                w.destroy()
            except Exception:
                pass
        a = ANIM[0]
        if fast or a is None or not a.on:
            kill()
            return
        try:
            tween(("win-out", id(self)), 120, lambda p: w.attributes("-alpha", 1.0 - p), kill, ease=ease_in)
        except tk.TclError:
            kill()


class Toasts:
    ICON = {"info": "●", "success": "✔", "error": "✖", "warn": "▲"}

    def __init__(self, app):
        self.app = app
        self.items = []

    def show(self, text, kind="info", ms=2600, action=None):
        app, th = self.app, T()
        col = {"info": th["accent"], "success": th["green"], "error": th["red"], "warn": th["yellow"]}.get(kind, th["accent"])
        f = tk.Frame(app.root, bg=th["border"])
        inner = tk.Frame(f, bg=th["pop"])
        inner.pack(padx=1, pady=1)
        tk.Frame(inner, width=4, bg=col).pack(side="left", fill="y")
        TLabel(inner, text=self.ICON.get(kind, "●"), fg=col, bg=th["pop"], font=app.ui_bold, padx=10).pack(side="left")
        TLabel(inner, text=text, fg=th["fg"], bg=th["pop"], font=app.ui_font, padx=0, pady=11, justify="left",
               wraplength=420).pack(side="left", padx=(0, 16))
        if action:
            lab = TLabel(inner, text=action[0], fg=th["accent"], bg=th["pop"], font=app.ui_bold, cursor="hand2", padx=4)
            lab.pack(side="left", padx=(0, 14))
            lab.bind("<Button-1>", lambda e, fn=action[1], f=f: (self.dismiss(f), app.root.after(10, fn)))
        bar = tk.Frame(f, height=2, bg=col)
        bar.place(relx=0.0, rely=1.0, anchor="sw", relwidth=1.0, height=2)
        for wd in (f, inner):
            wd.bind("<Button-1>", lambda e, f=f: self.dismiss(f))
        it = dict(f=f, y=0.0, xo=90.0, dying=False)
        self.items.append(it)
        if len(self.items) > 4:
            self.dismiss(self.items[0]["f"])
        self.layout(new=it)
        tween(("toast-in", id(f)), 460, lambda p: (it.__setitem__("xo", 90.0 * (1 - p)), self._place(it)), ease=spring)
        tween(("toast-t", id(f)), ms, lambda p: bar.place(relx=0.0, rely=1.0, anchor="sw", relwidth=max(0.0, 1.0 - p), height=2), ease=lambda p: p)
        app.root.after(ms, lambda f=f: self.dismiss(f))

    def _place(self, it):
        try:
            it["f"].place(relx=1.0, rely=1.0, x=-18 + int(it["xo"]), y=-int(it["y"]), anchor="se")
            it["f"].lift()
        except tk.TclError:
            pass

    def layout(self, new=None):
        """Stack from the bottom up; toasts that are already on screen glide to their new slot."""
        y = 40.0
        for it in reversed(self.items):
            try:
                it["f"].update_idletasks()
                h = it["f"].winfo_reqheight() + 8
            except tk.TclError:
                continue
            if it is new:
                it["y"] = y
                it["xo"] = 90.0 if ANIM[0] and ANIM[0].on else 0.0
                self._place(it)
            else:
                a, b = it["y"], y
                tween(("toast-y", id(it)), 320, lambda p, it=it, a=a, b=b: (it.__setitem__("y", a + (b - a) * p), self._place(it)), ease=ease_out_quint)
            y += h

    def dismiss(self, f):
        it = next((i for i in self.items if i["f"] is f), None)
        if not it or it["dying"]:
            return
        it["dying"] = True
        a = it["xo"]

        def gone():
            if it in self.items:
                self.items.remove(it)
            try:
                f.destroy()
            except tk.TclError:
                pass
            self.layout()
        tween(("toast-out", id(f)), 200, lambda p: (it.__setitem__("xo", a + (120.0 - a) * p), self._place(it)), gone, ease=ease_in)


def quick_input(app, title, label, initial="", validate=None, ok="OK"):
    """Themed one-line prompt. Returns the text, or None if cancelled."""
    th = T()
    w = tk.Toplevel(app.root)
    w.title(title)
    w.transient(app.root)
    w.resizable(False, False)
    w.configure(bg=th["pop"])
    TLabel(w, text=title, bg=th["pop"], fg=th["fg"], font=app.ui_bold, anchor="w").pack(fill="x", padx=18, pady=(16, 2))
    TLabel(w, text=label, bg=th["pop"], fg=th["muted"], font=app.ui_font, anchor="w", justify="left").pack(fill="x", padx=18)
    var = tk.StringVar(value=initial)
    e = tk.Entry(w, textvariable=var, width=44, font=app.ui_font, bg=th["panel2"], fg=th["fg"], insertbackground=th["accent"],
                 relief="flat", highlightthickness=1, highlightbackground=th["border"], highlightcolor=th["accent"])
    e.pack(fill="x", padx=18, pady=(10, 2), ipady=6)
    err = TLabel(w, text="", bg=th["pop"], fg=th["red"], font=app.ui_font, anchor="w")
    err.pack(fill="x", padx=18)
    row = tk.Frame(w, bg=th["pop"])
    row.pack(fill="x", padx=18, pady=(6, 16))
    res = {"v": None}

    def submit(ev=None):
        v = var.get().strip()
        if validate:
            msg = validate(v)
            if msg:
                err.configure(text=msg)
                return "break"
        res["v"] = v
        w.destroy()
        return "break"
    Btn(row, ok, submit, kind="primary", role="pop", height=32, padx=18).pack(side="right")
    Btn(row, "Cancel", w.destroy, kind="outline", role="pop", height=32, padx=14).pack(side="right", padx=8)
    e.bind("<Return>", submit)
    w.bind("<Escape>", lambda ev: w.destroy())
    try:
        app.root.update_idletasks()
        w.update_idletasks()
        x = app.root.winfo_rootx() + (app.root.winfo_width() - w.winfo_reqwidth()) // 2
        y = app.root.winfo_rooty() + max(60, (app.root.winfo_height() - w.winfo_reqheight()) // 3)
        w.geometry("+%d+%d" % (x, y))
        w.grab_set()
    except tk.TclError:
        pass
    e.focus_force()
    e.select_range(0, "end")
    app.root.wait_window(w)
    return res["v"]


def shorten_path(p, n=46):
    p = p.replace("\\", "/")
    return p if len(p) <= n else p[:14] + "…" + p[-(n - 15):]


def fold_ranges(text, lang):
    """{start_line: last_hidden_line} (1-based) for blocks that can be folded. Pure function."""
    out = {}
    lines = text.split("\n")
    if lang == "python":
        stack, last = [], -1
        for k, l in enumerate(lines):
            if not l.strip():
                continue
            d = len(l.expandtabs(4)) - len(l.expandtabs(4).lstrip())
            while stack and stack[-1][0] >= d:
                _, s0 = stack.pop()
                if last > s0:
                    out[s0 + 1] = last + 1
            stack.append((d, k))
            last = k
        for _, s0 in stack:
            if last > s0:
                out[s0 + 1] = last + 1
    elif lang in ("cpp", "c"):
        clean = re.sub(r'/\*.*?\*/|//[^\n]*|"(?:\\.|[^"\\\n])*"|\'(?:\\.|[^\'\\\n])*\'',
                       lambda m: re.sub(r"[^\n]", " ", m.group()), text, flags=re.S)
        stack = []
        for k, l in enumerate(clean.split("\n")):
            for ch in l:
                if ch == "{":
                    stack.append(k)
                elif ch == "}" and stack:
                    s0 = stack.pop()
                    if k - 1 >= s0 + 1:
                        out[s0 + 1] = k       # keep the closing-brace line visible
    return out


class Completion:
    def __init__(self, ed):
        self.ed = ed
        self.win = None
        self.lb = None
        self.items = []
        self.prefix = ""

    @property
    def visible(self):
        return self.win is not None

    def show(self, items, prefix):
        self.hide()
        t = self.ed.text
        bb = t.bbox("insert")
        if not bb:
            return
        th = self.ed.app.theme
        x = t.winfo_rootx() + bb[0]
        y = t.winfo_rooty() + bb[1] + bb[3] + 2
        w = tk.Toplevel(t)
        w.wm_overrideredirect(True)
        w.wm_geometry("+%d+%d" % (x, y))
        w.configure(bg=th["border"])
        width = min(max(max(len(n) for n, k in items), 12), 40)
        lb = tk.Listbox(w, height=min(10, len(items)), width=width + 14, bg=th["panel2"], fg=th["fg"],
                        selectbackground=th["accent"], selectforeground="#ffffff", bd=0, relief="flat",
                        highlightthickness=0, activestyle="none", font=self.ed.app.font, exportselection=False)
        lb.pack(padx=1, pady=1)
        colors = {"v": th["fg"], "f": th["fn"], "c": th["ty"], "m": th["pp"], "s": th["dc"], "k": th["kw"],
                  "b": th["bi"], "t": th["ty"], "p": th["fn"], "w": th["muted"]}
        for i, (name, kind) in enumerate(items):
            lb.insert("end", " %s  %s" % (name.ljust(width), KIND_LABEL[kind]))
            lb.itemconfigure(i, foreground=colors.get(kind, th["fg"]))
        lb.selection_set(0)
        lb.bind("<Double-Button-1>", lambda e: self.accept())
        self.win, self.lb, self.items, self.prefix = w, lb, items, prefix
        t.after_idle(t.focus_set)

    def move(self, d):
        if not self.lb:
            return
        cur = self.lb.curselection()
        i = max(0, min(len(self.items) - 1, (cur[0] if cur else 0) + d))
        self.lb.selection_clear(0, "end")
        self.lb.selection_set(i)
        self.lb.see(i)

    def accept(self):
        if not self.lb:
            return "break"
        cur = self.lb.curselection()
        name, kind = self.items[cur[0] if cur else 0]
        prefix = self.prefix
        self.hide()
        self.ed.apply_completion(name, kind, prefix)
        return "break"

    def hide(self):
        if self.win is not None:
            try:
                self.win.destroy()
            except Exception:
                pass
        self.win = self.lb = None


# ----------------------------------------------------------------------------
#  Editor (one per tab)
# ----------------------------------------------------------------------------
class Editor(tk.Frame):
    def __init__(self, master, app, path=None, content="", lang=None):
        super().__init__(master)
        self.app = app
        self.path = path
        self.lang = lang or detect_lang(path)
        self.dirty = False
        self.untitled_n = None
        self.syn_line = None
        self.syn_msg = ""
        self.run_errs = set()
        self.windowed = False
        self.rev = 0
        self.fold_cands = {}
        self.folded = {}
        self._fold_n = 0
        self._hl = self._chk = self._cc = self._hlv = self._ln_job = self._fold_job = None
        self.popup = Completion(self)

        self.ln = tk.Canvas(self, width=64, highlightthickness=0, bd=0, cursor="arrow")
        self.text = tk.Text(self, wrap="none", undo=True, maxundo=-1, autoseparators=True, bd=0,
                            highlightthickness=0, padx=10, pady=8, font=app.font, insertwidth=2, spacing1=1,
                            spacing3=1)
        self.vbar = ttk.Scrollbar(self, orient="vertical", command=self.text.yview, style="Legend.Vertical.TScrollbar")
        self.hbar = ttk.Scrollbar(self, orient="horizontal", command=self.text.xview, style="Legend.Horizontal.TScrollbar")
        self.text.configure(yscrollcommand=self._yscroll, xscrollcommand=self.hbar.set)
        self.ln.grid(row=0, column=0, sticky="ns")
        self.text.grid(row=0, column=1, sticky="nsew")
        self.vbar.grid(row=0, column=2, sticky="ns")
        self.hbar.grid(row=1, column=1, sticky="ew")
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)

        self.text.insert("1.0", content)
        self.text.edit_reset()
        self.text.edit_modified(False)
        self._setup_bindings()
        self.ln.bind("<Button-1>", self._gutter_click)
        self.apply_theme()
        self.apply_settings()
        self.highlight()
        self.check_python()
        self.refresh_folds()

    @property
    def tab(self):
        return " " * max(1, min(8, int(self.app.cfg.get("tab_size", 4) or 4)))

    def selected_text(self):
        t = self.text
        return t.get("sel.first", "sel.last") if t.tag_ranges("sel") else ""

    def apply_settings(self):
        """Re-read editor settings (wrap, gutter, tab width ...). Safe to call any time."""
        cfg, t = self.app.cfg, self.text
        t.configure(wrap="word" if cfg.get("word_wrap") else "none")
        if cfg.get("word_wrap"):
            self.hbar.grid_remove()
        else:
            self.hbar.grid()
        if cfg.get("line_numbers", True):
            self.ln.grid()
        else:
            self.ln.grid_remove()
        try:
            t.configure(tabs=(str(self.app.font.measure("0") * len(self.tab)),))
        except tk.TclError:
            pass
        try:
            style = cfg.get("cursor_style", "line")
            t.configure(insertwidth={"line": 2, "thick": 4, "block": max(6, self.app.font.measure("0"))}.get(style, 2),
                        insertofftime=300 if cfg.get("cursor_blink", True) else 0, insertontime=600)
            ls = int(cfg.get("line_spacing", 1))
            t.configure(spacing1=ls, spacing3=ls)
        except (tk.TclError, ValueError):
            pass
        self.on_cursor()
        self.schedule_ln()

    # ---- basics -------------------------------------------------------
    def title(self):
        if self.path:
            return os.path.basename(self.path)
        return "untitled-%d%s" % (self.untitled_n or 1, LANG_EXT.get(self.lang, ".txt"))

    def get_text(self):
        return self.text.get("1.0", "end-1c")

    def comment_token(self):
        return "// " if self.lang in ("cpp", "c") else "# "

    def set_lang(self, lang):
        self.lang = lang
        self.highlight()
        self.check_python()
        self.app.update_status()

    # ---- bindings -----------------------------------------------------
    def _setup_bindings(self):
        t = self.text

        def B(seq, fn, ctrl=True):
            """Bind a Ctrl shortcut and, on a Mac, its Command twin (Ctrl+A is the emacs 'line start' there, so skip it)."""
            t.__dict__.setdefault("_ctrl_fns", {})[seq[9:-1]] = fn
            if ctrl or not IS_MAC:
                t.bind(seq, fn)
            if IS_MAC:
                try:
                    t.bind(seq.replace("Control-", "Command-"), fn)
                except tk.TclError:
                    pass
        t.bind("<<Modified>>", self._on_modified)
        t.bind("<KeyPress>", self._on_keypress)
        self.app._ctrl_hook(t)
        t.bind("<KeyRelease>", self._on_keyrelease)
        t.bind("<ButtonRelease-1>", lambda e: self.on_cursor())
        t.bind("<Button-1>", lambda e: (self.popup.hide(), self.app.close_popup()))
        t.bind("<FocusOut>", lambda e: self.popup.hide())
        t.bind("<Configure>", lambda e: self.schedule_ln())
        t.bind("<Return>", self._on_return)
        t.bind("<KP_Enter>", self._on_return)
        t.bind("<Tab>", self._on_tab)
        t.bind("<BackSpace>", self._on_backspace)
        for seq in ("<Shift-Tab>", "<ISO_Left_Tab>"):
            try:
                t.bind(seq, lambda e: (self.indent_selection(-1), "break")[1])
            except tk.TclError:
                pass
        B("<Control-slash>", lambda e: (self.toggle_comment(), "break")[1])
        B("<Control-d>", lambda e: (self.duplicate_line(), "break")[1])
        B("<Control-K>", lambda e: (self.delete_line(), "break")[1])
        t.bind("<Alt-Up>", lambda e: (self.move_lines(-1), "break")[1])
        t.bind("<Alt-Down>", lambda e: (self.move_lines(1), "break")[1])
        B("<Control-a>", lambda e: (self.select_all(), "break")[1], ctrl=False)
        B("<Control-y>", lambda e: (self.redo(), "break")[1])
        B("<Control-space>", lambda e: (self.try_complete(force=True), "break")[1])
        if IS_MAC:
            t.bind("<Option-space>", lambda e: (self.try_complete(force=True), "break")[1])
        B("<Control-bracketleft>", lambda e: (self.toggle_fold(int(t.index("insert").split(".")[0])), "break")[1])
        t.bind("<Control-MouseWheel>", lambda e: (self.app.zoom(1 if e.delta > 0 else -1), "break")[1])
        t.bind("<Control-Button-4>", lambda e: (self.app.zoom(1), "break")[1])
        t.bind("<Control-Button-5>", lambda e: (self.app.zoom(-1), "break")[1])
        SmoothWheel(t, "text", lambda: self.app.font.metrics("linespace") + 2)
        for seq in RIGHT_CLICK:
            t.bind(seq, lambda e: (self.app.editor_menu(self, e), "break")[1])
        self.app.bind_shortcuts(t)

    def select_all(self):
        self.text.tag_add("sel", "1.0", "end-1c")
        self.text.mark_set("insert", "end-1c")

    def redo(self):
        try:
            self.text.edit_redo()
        except tk.TclError:
            pass

    # ---- theme --------------------------------------------------------
    def apply_theme(self):
        th = T()
        t = self.text
        t.configure(bg=th["bg"], fg=th["fg"], insertbackground=th["accent"], selectbackground=th["sel"],
                    selectforeground=th["fg"], inactiveselectbackground=th["sel"])
        self.ln.configure(bg=th["bg"])
        self.configure(bg=th["bg"])
        for tag in TAGS:
            t.tag_configure(tag, foreground=th[tag])
        t.tag_configure("cm", foreground=th["cm"], font=self.app.font_i)
        t.tag_configure("curline", background=th["cur"])
        t.tag_configure("runerr", background=th["err"])
        t.tag_configure("synerr", background=th["err"])
        t.tag_configure("bracket", background=th["bracket"])
        t.tag_configure("match", background=th["match"])
        t.tag_configure("matchcur", background=th["accent"], foreground=th["accent_fg"])
        for name in list(self.folded):
            t.tag_configure("fold_%d" % name, elide=True)
        t.tag_lower("curline")
        t.tag_raise("sel")
        self.schedule_ln()

    # ---- line numbers -------------------------------------------------
    def _yscroll(self, a, b):
        self.vbar.set(a, b)
        self.schedule_ln()
        if self.windowed:
            if self._hlv:
                self.after_cancel(self._hlv)
            self._hlv = self.after(80, self._highlight_visible)

    def _highlight_visible(self):
        self._hlv = None
        self.highlight()

    def schedule_ln(self):
        """Coalesce gutter redraws: at most one per idle moment."""
        if self._ln_job is None:
            self._ln_job = self.after_idle(self.redraw_ln)

    def redraw_ln(self):
        self._ln_job = None
        c, t, th = self.ln, self.text, T()
        if not self.app.cfg.get("line_numbers", True):
            return
        total = int(t.index("end-1c").split(".")[0])
        w = self.app.font.measure("0") * max(3, len(str(total))) + 44
        if int(c.cget("width")) != w:
            c.configure(width=w)
        c.delete("all")
        cur = int(t.index("insert").split(".")[0])
        starts = set(self._fold_starts())
        height = max(t.winfo_height(), 1)
        y, prev, guard = 0, -1, 0
        while y < height and guard < 600:
            guard += 1
            try:
                idx = t.index("@0,%d" % y)
                d = t.dlineinfo(idx)
            except tk.TclError:
                break
            if not d:
                break
            ln = int(str(idx).split(".")[0])
            if ln != prev:
                prev = ln
                ty = d[1]
                col = th["ln_cur"] if ln == cur else th["ln_fg"]
                c.create_text(w - 26, ty + 1, anchor="ne", text=str(ln), fill=col, font=self.app.font)
                if ln == self.syn_line:
                    c.create_oval(8, ty + 5, 16, ty + 13, fill=th["red"], outline="")
                elif ln in self.run_errs:
                    c.create_oval(8, ty + 5, 16, ty + 13, fill=th["yellow"], outline="")
                if ln in starts or ln in self.fold_cands:
                    fx, fy = w - 13, ty + 9
                    folded = ln in starts
                    fc = th["accent"] if folded else (th["muted"] if ln == cur else th["dim"])
                    if folded:
                        c.create_polygon(fx - 3, fy - 4, fx + 3, fy, fx - 3, fy + 4, fill=fc, outline=fc)
                    else:
                        c.create_polygon(fx - 4, fy - 2, fx + 4, fy - 2, fx, fy + 3, fill=fc, outline=fc)
            ny = d[1] + max(d[3], 1) + 1
            if ny <= y:                      # below the last line Tk keeps answering with that line -> stop
                break
            y = ny

    # ---- change handling ----------------------------------------------
    def _on_modified(self, e=None):
        if not self.text.edit_modified():
            return
        self.text.edit_modified(False)
        self.rev += 1
        if not self.dirty:
            self.dirty = True
            self.app.tabbar.refresh()
            self.app.update_title()
        n = int(self.text.index("end-1c").split(".")[0])
        if self._hl:
            self.after_cancel(self._hl)
        self._hl = self.after(70 if n < 800 else 160, self.highlight)
        if self._chk:
            self.after_cancel(self._chk)
        self._chk = self.after(650 if n < 2500 else 1500, self.check_python)
        if self._fold_job:
            self.after_cancel(self._fold_job)
        self._fold_job = self.after(500 if n < 2500 else 1500, self.refresh_folds)
        self.schedule_ln()

    def highlight(self):
        """Colour the code. Small files are coloured whole; big files only around the visible part."""
        self._hl = None
        t = self.text
        nlines = int(t.index("end-1c").split(".")[0])
        self.windowed = nlines > FULL_HL_LINES
        if self.lang == "text":
            for tag in TAGS:
                t.tag_remove(tag, "1.0", "end")
            return
        if self.windowed:
            top = int(t.index("@0,0").split(".")[0])
            bot = int(t.index("@0,%d" % max(1, t.winfo_height())).split(".")[0])
            a_line, b_line = max(1, top - 150), min(nlines, bot + 150)
        else:
            a_line, b_line = 1, nlines
        a_idx, b_idx = "%d.0" % a_line, "%d.end" % b_line
        s = t.get(a_idx, b_idx)
        if len(s) > MAX_HL:
            return
        for tag in TAGS:
            t.tag_remove(tag, a_idx, b_idx)
        rngs = compute_ranges(s, self.lang)
        starts = line_starts(s)

        def idx(off):
            ln = bisect.bisect_right(starts, off) - 1
            return "%d.%d" % (ln + a_line, off - starts[ln])
        for tag, lst in rngs.items():
            if not lst:
                continue
            args = []
            for a, b in lst:
                args += [idx(a), idx(b)]
            for k in range(0, len(args), 4000):
                t.tag_add(tag, *args[k:k + 4000])
        t.tag_raise("sel")

    def check_python(self):
        self._chk = None
        t = self.text
        t.tag_remove("synerr", "1.0", "end")
        self.syn_line, self.syn_msg = None, ""
        if self.lang == "python" and int(t.index("end-1c").split(".")[0]) <= 6000:
            try:
                compile(self.get_text(), self.title(), "exec")
            except SyntaxError as e:
                if e.lineno:
                    self.syn_line = e.lineno
                    t.tag_add("synerr", "%d.0" % e.lineno, "%d.0" % (e.lineno + 1))
                self.syn_msg = "%s (line %s)" % (e.msg, e.lineno)
            except Exception:
                pass
        self.schedule_ln()
        self.app.update_status()
        self.app.update_problems_syntax(self)

    def set_run_errors(self, lines):
        self.clear_run_errors()
        self.run_errs = set(lines)
        for ln in self.run_errs:
            self.text.tag_add("runerr", "%d.0" % ln, "%d.0" % (ln + 1))
        self.redraw_ln()

    def clear_run_errors(self):
        if self.run_errs:
            self.text.tag_remove("runerr", "1.0", "end")
            self.run_errs = set()
            self.redraw_ln()

    # ---- cursor -------------------------------------------------------
    def on_cursor(self):
        t, cfg = self.text, self.app.cfg
        t.tag_remove("curline", "1.0", "end")
        if cfg.get("highlight_line", True):
            t.tag_add("curline", "insert linestart", "insert lineend +1c")
        t.tag_remove("bracket", "1.0", "end")
        if cfg.get("bracket_match", True):
            win = t.get("insert-4000c", "insert+4000c")
            pos = len(t.get("insert-4000c", "insert"))
            m = match_bracket(win, pos)
            if m:
                for off in m:
                    rel = off - pos
                    t.tag_add("bracket", "insert%+dc" % rel, "insert%+dc" % (rel + 1))
        self.schedule_ln()
        self.app.update_status()

    def goto(self, line, col=1):
        self.unfold_at(line)
        self.text.mark_set("insert", "%d.%d" % (max(1, line), max(0, col - 1)))
        self.text.see("insert")
        self.text.focus_set()
        self.on_cursor()

    # ---- keyboard: pairs, indent, backspace ----------------------------
    def _on_keypress(self, e):
        p = self.popup
        if p.visible:
            if e.keysym == "Up":
                p.move(-1)
                return "break"
            if e.keysym == "Down":
                p.move(1)
                return "break"
            if e.keysym == "Escape":
                p.hide()
                return "break"
        ch = e.char
        if not ch or len(ch) != 1 or not ch.isprintable():
            return None
        t = self.text
        has_sel = bool(t.tag_ranges("sel"))
        before = t.get("insert linestart", "insert")
        after = t.get("insert", "insert lineend")
        if ch in PAIRS or ch in "\"'":
            if self.lang == "text" or not self.app.cfg.get("auto_pair", True):
                return None
            close = PAIRS.get(ch, ch)
            if has_sel:
                a = t.index("sel.first")
                sel = t.get("sel.first", "sel.last")
                t.delete("sel.first", "sel.last")
                t.insert(a, ch + sel + close)
                t.mark_set("insert", "%s+%dc" % (a, len(sel) + 2))
                return "break"
            if ch in "\"'":
                if after[:1] == ch:
                    t.mark_set("insert", "insert+1c")
                    return "break"
                if not can_pair_quote(before, after, ch):
                    return None
            else:
                nxt = after[:1]
                if nxt and not nxt.isspace() and nxt not in ")]}":
                    return None
            t.insert("insert", ch + close)
            t.mark_set("insert", "insert-1c")
            return "break"
        if ch in ")]}":
            if after[:1] == ch and not has_sel:
                t.mark_set("insert", "insert+1c")
                return "break"
            if ch == "}" and before.strip() == "" and before.endswith(" ") and self.lang in ("cpp", "c"):
                n = min(len(self.tab), len(before) - len(before.rstrip(" ")))
                t.delete("insert-%dc" % n, "insert")
        return None

    def _on_keyrelease(self, e):
        ks = e.keysym
        if ks in ("Up", "Down", "Left", "Right", "Home", "End", "Prior", "Next", "Return", "Escape"):
            if ks in ("Left", "Right", "Home", "End", "Return", "Escape"):
                self.popup.hide()
            self.on_cursor()
            return
        if len(e.char or "") == 1 and e.char.isprintable() or ks == "BackSpace":
            if self._cc:
                self.after_cancel(self._cc)
            self._cc = self.after(140, self.try_complete)
        self.on_cursor()

    def _on_return(self, e=None):
        if self.popup.visible:
            return self.popup.accept()
        t = self.text
        if t.tag_ranges("sel"):
            t.delete("sel.first", "sel.last")
        before = t.get("insert linestart", "insert")
        after = t.get("insert", "insert lineend")
        ins, back = newline_indent(before, after, self.lang, self.tab)
        t.insert("insert", ins)
        if back:
            t.mark_set("insert", "insert-%dc" % back)
        t.see("insert")
        return "break"

    def _on_tab(self, e=None):
        if self.popup.visible:
            return self.popup.accept()
        t = self.text
        if t.tag_ranges("sel"):
            self.indent_selection(1)
            return "break"
        if self.try_snippet():
            return "break"
        col = int(t.index("insert").split(".")[1])
        n = len(self.tab)
        t.insert("insert", " " * (n - col % n))
        return "break"

    def _on_backspace(self, e=None):
        t = self.text
        if t.tag_ranges("sel"):
            return None
        before = t.get("insert linestart", "insert")
        after = t.get("insert", "insert lineend")
        if before and after and PAIRS.get(before[-1]) == after[0]:
            t.delete("insert-1c", "insert+1c")
            return "break"
        if before[-1:] in ("\"", "'") and after[:1] == before[-1:] and can_unpair(before):
            t.delete("insert-1c", "insert+1c")
            return "break"
        if before and before.strip() == "" and before.endswith(" "):
            n = len(before) % len(self.tab) or len(self.tab)
            n = min(n, len(before) - len(before.rstrip(" ")))
            t.delete("insert-%dc" % n, "insert")
            return "break"
        return None

    # ---- line helpers -------------------------------------------------
    def _sel_lines(self):
        t = self.text
        if t.tag_ranges("sel"):
            a, b = t.index("sel.first"), t.index("sel.last")
            l1, l2 = int(a.split(".")[0]), int(b.split(".")[0])
            if b.endswith(".0") and l2 > l1:
                l2 -= 1
            return l1, l2
        l = int(t.index("insert").split(".")[0])
        return l, l

    def _replace_lines(self, l1, l2, lines):
        t = self.text
        t.edit_separator()
        a, b = "%d.0" % l1, "%d.end" % l2
        t.delete(a, b)
        t.insert(a, "\n".join(lines))
        t.edit_separator()

    def _get_lines(self, l1, l2):
        return self.text.get("%d.0" % l1, "%d.end" % l2).split("\n")

    def indent_selection(self, direction):
        t = self.text
        had_sel = bool(t.tag_ranges("sel"))
        l1, l2 = self._sel_lines()
        lines = self._get_lines(l1, l2)
        new = indent_lines(lines, self.tab) if direction > 0 else dedent_lines(lines, self.tab)
        cur = t.index("insert")
        self._replace_lines(l1, l2, new)
        if had_sel:
            t.tag_add("sel", "%d.0" % l1, "%d.end" % l2)
        else:
            cl, cc = [int(x) for x in cur.split(".")]
            delta = len(new[0]) - len(lines[0])
            t.mark_set("insert", "%d.%d" % (cl, max(0, cc + delta)))

    def toggle_comment(self):
        if self.lang == "text":
            return
        l1, l2 = self._sel_lines()
        t = self.text
        had_sel = bool(t.tag_ranges("sel"))
        lines = self._get_lines(l1, l2)
        self._replace_lines(l1, l2, toggle_comment(lines, self.comment_token()))
        if had_sel:
            t.tag_add("sel", "%d.0" % l1, "%d.end" % l2)

    def duplicate_line(self):
        t = self.text
        if t.tag_ranges("sel"):
            s = t.get("sel.first", "sel.last")
            t.edit_separator()
            t.insert("sel.last", s)
            t.edit_separator()
            return
        l, c = [int(x) for x in t.index("insert").split(".")]
        line = t.get("%d.0" % l, "%d.end" % l)
        t.edit_separator()
        t.insert("%d.end" % l, "\n" + line)
        t.edit_separator()
        t.mark_set("insert", "%d.%d" % (l + 1, c))

    def delete_line(self):
        t = self.text
        l1, l2 = self._sel_lines()
        last = int(t.index("end-1c").split(".")[0])
        t.edit_separator()
        if l2 < last:
            t.delete("%d.0" % l1, "%d.0" % (l2 + 1))
        elif l1 > 1:
            t.delete("%d.end" % (l1 - 1), "%d.end" % l2)
        else:
            t.delete("1.0", "end-1c")
        t.edit_separator()

    def move_lines(self, d):
        t = self.text
        l1, l2 = self._sel_lines()
        last = int(t.index("end-1c").split(".")[0])
        cl, cc = [int(x) for x in t.index("insert").split(".")]
        had_sel = bool(t.tag_ranges("sel"))
        if d < 0 and l1 > 1:
            prev = self._get_lines(l1 - 1, l1 - 1)
            block = self._get_lines(l1, l2)
            self._replace_lines(l1 - 1, l2, block + prev)
            n1, n2 = l1 - 1, l2 - 1
        elif d > 0 and l2 < last:
            nxt = self._get_lines(l2 + 1, l2 + 1)
            block = self._get_lines(l1, l2)
            self._replace_lines(l1, l2 + 1, nxt + block)
            n1, n2 = l1 + 1, l2 + 1
        else:
            return
        t.mark_set("insert", "%d.%d" % (cl + (n1 - l1), cc))
        if had_sel:
            t.tag_add("sel", "%d.0" % n1, "%d.end" % n2)

    # ---- autocomplete & snippets --------------------------------------
    def try_complete(self, force=False):
        self._cc = None
        if self.lang == "text" or not self.winfo_exists():
            return
        if not force and not self.app.cfg.get("autocomplete", True):
            return
        t = self.text
        if t.tag_ranges("sel"):
            return
        before = t.get("insert linestart", "insert")
        after = t.get("insert", "insert lineend")
        cm = "#" if self.lang == "python" else "//"
        if after[:1].isalnum() or after[:1] == "_" or in_string(before) or \
                (cm in before and not re.search(r"['\"].*" + re.escape(cm), before)):
            self.popup.hide()
            return
        line = int(t.index("insert").split(".")[0])
        doc = self.get_text()
        if len(doc) > 250_000:                               # keep completion fast on huge files
            ls = doc.split("\n")
            lo = max(0, line - 2500)
            doc, line = "\n".join(ls[lo:line + 2500]), line - lo
        items, prefix = completions(self.lang, before, doc, force, line)
        if not items:
            self.popup.hide()
            return
        self.popup.show(items, prefix)

    def apply_completion(self, name, kind, prefix):
        t = self.text
        if kind == "s" and self.expand_snippet(name, len(prefix)):
            return
        if prefix:
            t.delete("insert-%dc" % len(prefix), "insert")
        t.insert("insert", name)

    def expand_snippet(self, key, delete_len):
        snips = PY_SNIPS if self.lang == "python" else CPP_SNIPS if self.lang in ("cpp", "c") else {}
        body = snips.get(key)
        if body is None:
            return False
        t = self.text
        before = t.get("insert linestart", "insert")
        base = re.match(r"[ \t]*", before).group()
        body = body.replace("\n", "\n" + base)
        pos = body.find("$0")
        tail = 0
        if pos >= 0:
            tail = len(body) - pos - 2
            body = body.replace("$0", "", 1)
        t.edit_separator()
        if delete_len:
            t.delete("insert-%dc" % delete_len, "insert")
        t.insert("insert", body)
        if tail:
            t.mark_set("insert", "insert-%dc" % tail)
        t.edit_separator()
        return True

    def try_snippet(self):
        before = self.text.get("insert linestart", "insert")
        m = re.search(r"(?:^|[\s;{(])([A-Za-z_]+)$", before)
        if not m:
            return False
        return self.expand_snippet(m.group(1), len(m.group(1)))

    def destroy(self):
        """Cancel pending timers first - a timer that fires after its widget is gone pops up a Tcl error dialog."""
        for name in ("_hl", "_chk", "_cc", "_hlv", "_ln_job", "_fold_job"):
            job = getattr(self, name, None)
            if job:
                try:
                    self.after_cancel(job)
                except Exception:
                    pass
                setattr(self, name, None)
        super().destroy()

    # ---- code folding -----------------------------------------------------
    def _fold_starts(self):
        """Line numbers of the currently folded blocks (derived from marks, so they survive edits)."""
        out = []
        for n in list(self.folded):
            try:
                out.append(int(self.text.index("fa_%d" % n).split(".")[0]))
            except tk.TclError:
                self.folded.pop(n, None)
        return out

    def refresh_folds(self):
        self._fold_job = None
        t = self.text
        if self.lang in ("python", "cpp", "c") and int(t.index("end-1c").split(".")[0]) <= 20000:
            self.fold_cands = fold_ranges(self.get_text(), self.lang)
        else:
            self.fold_cands = {}
        for n in list(self.folded):                       # drop folds whose block no longer exists
            try:
                ln = int(t.index("fa_%d" % n).split(".")[0])
            except tk.TclError:
                self.folded.pop(n, None)
                continue
            if ln not in self.fold_cands:
                self._unfold(n)
        self.schedule_ln()

    def toggle_fold(self, line):
        for n in list(self.folded):
            if int(self.text.index("fa_%d" % n).split(".")[0]) == line:
                self._unfold(n)
                self.schedule_ln()
                return True
        end = self.fold_cands.get(line)
        if not end or end <= line:
            return False
        t = self.text
        self._fold_n += 1
        n = self._fold_n
        t.mark_set("fa_%d" % n, "%d.end" % line)
        t.mark_gravity("fa_%d" % n, "left")
        t.mark_set("fb_%d" % n, "%d.end" % end)
        t.mark_gravity("fb_%d" % n, "right")
        t.tag_configure("fold_%d" % n, elide=True)
        t.tag_add("fold_%d" % n, "fa_%d" % n, "fb_%d" % n)
        self.folded[n] = line
        cl = int(t.index("insert").split(".")[0])
        if line < cl <= end:
            t.mark_set("insert", "%d.end" % line)
        self.schedule_ln()
        return True

    def _unfold(self, n):
        t = self.text
        try:
            t.tag_remove("fold_%d" % n, "1.0", "end")
            t.tag_delete("fold_%d" % n)
            t.mark_unset("fa_%d" % n, "fb_%d" % n)
        except tk.TclError:
            pass
        self.folded.pop(n, None)

    def unfold_at(self, line):
        for n in list(self.folded):
            try:
                a = int(self.text.index("fa_%d" % n).split(".")[0])
                b = int(self.text.index("fb_%d" % n).split(".")[0])
            except tk.TclError:
                self.folded.pop(n, None)
                continue
            if a < line <= b:
                self._unfold(n)
        self.schedule_ln()

    def fold_all(self):
        for ln in sorted(self.fold_cands, reverse=True):
            if all(ln != int(self.text.index("fa_%d" % n).split(".")[0]) for n in self.folded):
                self.toggle_fold(ln)

    def unfold_all(self):
        for n in list(self.folded):
            self._unfold(n)
        self.schedule_ln()

    def _gutter_click(self, e):
        t = self.text
        try:
            ln = int(str(t.index("@0,%d" % max(0, e.y))).split(".")[0])
        except tk.TclError:
            return
        if e.x >= int(self.ln.cget("width")) - 24 and self.toggle_fold(ln):
            return
        t.tag_remove("sel", "1.0", "end")
        t.tag_add("sel", "%d.0" % ln, "%d.0" % (ln + 1))
        t.mark_set("insert", "%d.0" % ln)
        t.focus_set()
        self.on_cursor()

    # ---- formatting ---------------------------------------------------------
    def format_document(self):
        """Light, safe clean-up: leading tabs -> spaces, trailing spaces removed, one final newline."""
        t = self.text
        old = self.get_text()
        lines = [re.sub(r"^\t+", lambda m: self.tab * len(m.group()), l.rstrip()) for l in old.split("\n")]
        while len(lines) > 1 and lines[-1] == "":
            lines.pop()
        new = "\n".join(lines) + "\n"
        if new == old:
            return 0
        cl, cc = [int(x) for x in t.index("insert").split(".")]
        top = t.yview()[0]
        t.edit_separator()
        t.delete("1.0", "end-1c")
        t.insert("1.0", new)
        t.edit_separator()
        t.mark_set("insert", "%d.%d" % (cl, cc))
        t.yview_moveto(top)
        return sum(1 for a, b in zip(old.split("\n"), new.split("\n")) if a != b)


def can_unpair(before):
    return len(before) < 2 or before[-2:-1] != before[-1:]



# ----------------------------------------------------------------------------
#  Form widgets: entry style, switch, select
# ----------------------------------------------------------------------------
def style_entry(e, role="panel2"):
    th = T()
    e.configure(bg=th[role], fg=th["fg"], insertbackground=th["accent"], relief="flat", bd=0, highlightthickness=1,
                highlightbackground=th["border"], highlightcolor=th["accent"], selectbackground=th["sel"],
                selectforeground=th["fg"])
    try:
        e.configure(disabledbackground=th["panel"], disabledforeground=th["dim"])
    except tk.TclError:
        pass


class Switch(tk.Canvas):
    """Modern on/off toggle."""

    def __init__(self, master, value=False, command=None, role="pop"):
        super().__init__(master, width=40, height=22, highlightthickness=0, bd=0, cursor="hand2")
        self.value, self.cmd, self.role = bool(value), command, role
        self.pos = 1.0 if self.value else 0.0
        self.bind("<ButtonRelease-1>", lambda e: self.toggle())
        self.paint()

    def get(self):
        return self.value

    def set(self, v):
        self.value = bool(v)
        self.pos = 1.0 if self.value else 0.0
        self.paint()

    def toggle(self):
        self.value = not self.value
        a, b = self.pos, 1.0 if self.value else 0.0
        tween(("sw", id(self)), 180, lambda p: (setattr(self, "pos", a + (b - a) * p), self.paint()))
        if self.cmd:
            self.cmd(self.value)

    def paint(self):
        th = T()
        self.delete("all")
        self.configure(bg=th[self.role])
        k = self.pos
        self._imgs = []
        aa_round_rect(self, 1, 2, 39, 20, 9 if SHAPE["k"] > .5 else R(9), mix(th["border"], th["accent"], k))
        x = 11 + 18 * k
        if SHAPE["k"] > .5:
            aa_circle(self, x, 11, 7, mix(th["muted"], th["accent_fg"], k))
        else:
            aa_round_rect(self, x - 7, 4, x + 7, 18, R(7), mix(th["muted"], th["accent_fg"], k))

    retheme = paint


class Select(tk.Frame):
    """Drop-down made of our own PopupMenu (so it matches the rest of the UI)."""

    def __init__(self, master, app, options, value, command=None, width=22, role="panel2"):
        super().__init__(master, bd=0, highlightthickness=1, cursor="hand2")
        self.app, self.options, self.value, self.cmd, self.role = app, list(options), value, command, role
        self.lab = TLabel(self, text=str(value), anchor="w", font=app.ui_font, width=width, padx=10, pady=5, cursor="hand2")
        self.lab.pack(side="left", fill="x", expand=True)
        self.chev = tk.Canvas(self, width=26, height=26, highlightthickness=0, bd=0, cursor="hand2")
        self.chev.pack(side="right")
        for wd in (self, self.lab, self.chev):
            wd.bind("<ButtonRelease-1>", lambda e: self.open())
            wd._menu_trigger = True
        self.paint()

    def get(self):
        return self.value

    def set(self, v):
        self.value = v
        self.lab.configure(text=str(v))

    def open(self):
        items = [(("✓  " if o == self.value else "     ") + tr(str(o)), "", lambda o=o: self._pick(o)) for o in self.options]
        PopupMenu(self.app, items, self.winfo_rootx(), self.winfo_rooty() + self.winfo_height() + 2, minw=self.winfo_width())

    def _pick(self, o):
        self.set(o)
        if self.cmd:
            self.cmd(o)

    def paint(self):
        th = T()
        self.configure(bg=th[self.role], highlightbackground=th["border"], highlightcolor=th["border"])
        self.lab.configure(bg=th[self.role], fg=th["fg"])
        self.chev.configure(bg=th[self.role])
        self.chev.delete("all")
        draw_icon(self.chev, "chev", 13, 13, 5, th["muted"])

    retheme = paint


# ----------------------------------------------------------------------------
#  Find / Replace bar (sits above the editor)
# ----------------------------------------------------------------------------
class ToggleChip(TLabel):
    def __init__(self, master, text, command, tip=""):
        super().__init__(master, text=text, padx=7, pady=3, cursor="hand2", bd=0)
        self.on, self.cmd, self.hover = False, command, False
        self.hv = 0.0
        self.bind("<ButtonRelease-1>", lambda e: self.toggle())
        self.bind("<Enter>", lambda e: self._h(True))
        self.bind("<Leave>", lambda e: self._h(False))
        if tip:
            Tooltip(self, tip)
        self.retheme()

    def _h(self, v):
        self.hover = v
        a, b = self.hv, 1.0 if v else 0.0
        tween(("hv", id(self)), 130, lambda p: (setattr(self, "hv", a + (b - a) * p), self.retheme()))

    def toggle(self):
        self.on = not self.on
        self.retheme()
        self.cmd()

    def retheme(self):
        th = T()
        if self.on:
            self.configure(bg=mix(th["panel"], th["accent"], .28), fg=th["accent"])
        else:
            self.configure(bg=mix(th["panel"], th["hover"], self.hv), fg=mix(th["muted"], th["fg"], self.hv))


class FindBar(tk.Frame):
    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self.fv, self.rv = tk.StringVar(), tk.StringVar()
        self.cnt = tk.StringVar(value="")
        self.matches = []
        self.shown = False
        self.replace_mode = False
        self._job = None
        f = app.ui_font
        self.row1 = tk.Frame(self)
        self.row2 = tk.Frame(self)
        self.row1.pack(fill="x", padx=10, pady=(8, 3))
        self.fe = tk.Entry(self.row1, textvariable=self.fv, width=30, font=f)
        self.fe.pack(side="left", fill="x", expand=True, ipady=4)
        self.chips = [ToggleChip(self.row1, "Aa", self._opt_changed, "Match case"),
                      ToggleChip(self.row1, "W", self._opt_changed, "Whole word"),
                      ToggleChip(self.row1, ".*", self._opt_changed, "Regular expression")]
        for c in self.chips:
            c.pack(side="left", padx=(5, 0))
        self.cl = TLabel(self.row1, textvariable=self.cnt, font=f, width=11, anchor="e")
        self.cl.pack(side="left", padx=(8, 4))
        self.bp = Chip(self.row1, "↑", lambda: self.step(-1), role="panel", font=app.ui_bold, padx=8, tip="Previous (Shift+Enter)")
        self.bn = Chip(self.row1, "↓", lambda: self.step(1), role="panel", font=app.ui_bold, padx=8, tip="Next (Enter)")
        self.bx = Chip(self.row1, "✕", self.hide, role="panel", font=f, padx=8, tip="Close (Esc)")
        for c in (self.bp, self.bn, self.bx):
            c.pack(side="left")
        self.re_ = tk.Entry(self.row2, textvariable=self.rv, width=30, font=f)
        self.re_.pack(side="left", fill="x", expand=True, ipady=4)
        self.br = Btn(self.row2, "Replace", self.replace_one, kind="outline", role="panel", height=28, padx=10)
        self.ba = Btn(self.row2, "Replace all", self.replace_all, kind="outline", role="panel", height=28, padx=10)
        self.br.pack(side="left", padx=(8, 0))
        self.ba.pack(side="left", padx=(6, 0))
        self.line = tk.Frame(self, height=1)
        self.line.pack(side="bottom", fill="x")
        self.fv.trace_add("write", lambda *a: self._soon())
        self.fe.bind("<Return>", lambda e: (self.step(1), "break")[1])
        self.fe.bind("<Shift-Return>", lambda e: (self.step(-1), "break")[1])
        self.fe.bind("<Escape>", lambda e: self.hide())
        self.re_.bind("<Return>", lambda e: (self.replace_one(), "break")[1])
        self.re_.bind("<Escape>", lambda e: self.hide())
        self.retheme()

    @property
    def case(self):
        return self.chips[0].on

    @property
    def word(self):
        return self.chips[1].on

    @property
    def regex(self):
        return self.chips[2].on

    def retheme(self):
        th = T()
        for w in (self, self.row1, self.row2):
            w.configure(bg=th["panel"])
        self.line.configure(bg=th["border"])
        self.cl.configure(bg=th["panel"], fg=th["muted"])
        for e in (self.fe, self.re_):
            style_entry(e)
        for c in self.chips + [self.bp, self.bn, self.bx]:
            c.retheme()
        for b in (self.br, self.ba):
            b.retheme()

    def show(self, replace=False):
        self.replace_mode = replace
        if not self.shown:
            self.pack(side="top", fill="x", before=self.app.host)
            self.shown = True
        if replace:
            self.row2.pack(fill="x", padx=10, pady=(0, 8), before=self.line)
        else:
            self.row2.pack_forget()
        ed = self.app.cur
        if ed and ed.text.tag_ranges("sel"):
            sel = ed.text.get("sel.first", "sel.last")
            if "\n" not in sel and sel.strip():
                self.fv.set(sel)
        self.fe.focus_set()
        self.fe.select_range(0, "end")
        self.refresh_matches()

    def hide(self):
        if self.shown:
            self.pack_forget()
            self.shown = False
        ed = self.app.cur
        if ed:
            ed.text.tag_remove("match", "1.0", "end")
            ed.text.tag_remove("matchcur", "1.0", "end")
            ed.text.focus_set()
        return "break"

    def _opt_changed(self):
        self.refresh_matches()

    def _soon(self):
        if self._job:
            self.after_cancel(self._job)
        self._job = self.after(110, self.refresh_matches)

    def _pattern(self):
        q = self.fv.get()
        if not q:
            return None
        try:
            body = q if self.regex else re.escape(q)
            if self.word and (self.regex or (q[0].isalnum() or q[0] == "_") and (q[-1].isalnum() or q[-1] == "_")):
                body = r"\b(?:%s)\b" % body
            return re.compile(body, 0 if self.case else re.I)
        except re.error:
            return None

    def refresh_matches(self):
        self._job = None
        ed = self.app.cur
        if not ed or not self.shown:
            return
        t = ed.text
        t.tag_remove("match", "1.0", "end")
        t.tag_remove("matchcur", "1.0", "end")
        self.matches = []
        pat = self._pattern()
        if not pat:
            self.cnt.set("")
            return
        s = ed.get_text()
        starts = line_starts(s)
        args = []
        for m in pat.finditer(s):
            if m.end() == m.start():
                continue
            self.matches.append((m.start(), m.end()))
            args += [off2idx(starts, m.start()), off2idx(starts, m.end())]
            if len(self.matches) >= 5000:
                break
        for k in range(0, len(args), 4000):
            t.tag_add("match", *args[k:k + 4000])
        t.tag_raise("sel")
        self.cnt.set("%d found" % len(self.matches) if self.matches else "No results")

    def step(self, d):
        ed = self.app.cur
        if not ed:
            return
        self.refresh_matches()
        if not self.matches:
            return
        t = ed.text
        cur = len(t.get("1.0", "insert"))
        if d > 0:
            nxt = next((m for m in self.matches if m[0] >= cur), self.matches[0])
        else:
            if t.tag_ranges("sel"):
                cur = len(t.get("1.0", "sel.first"))
            nxt = next((m for m in reversed(self.matches) if m[1] <= cur), self.matches[-1])
        starts = line_starts(ed.get_text())
        a, b = off2idx(starts, nxt[0]), off2idx(starts, nxt[1])
        ed.unfold_at(int(a.split(".")[0]))
        t.tag_remove("matchcur", "1.0", "end")
        t.tag_add("matchcur", a, b)
        t.tag_remove("sel", "1.0", "end")
        t.tag_add("sel", a, b)
        t.mark_set("insert", b)
        t.see(a)
        ed.schedule_ln()
        self.cnt.set("%d of %d" % (self.matches.index(nxt) + 1, len(self.matches)))

    def replace_one(self):
        ed = self.app.cur
        pat = self._pattern()
        if not ed or not pat:
            return
        t = ed.text
        if t.tag_ranges("sel"):
            sel = t.get("sel.first", "sel.last")
            m = pat.fullmatch(sel)
            if m:
                try:
                    rep = m.expand(self.rv.get()) if self.regex else self.rv.get()
                except (re.error, IndexError) as e:
                    self.app.toast("Bad replacement: %s" % e, "error")
                    return
                t.edit_separator()
                a = t.index("sel.first")
                t.delete("sel.first", "sel.last")
                t.insert(a, rep)
                t.edit_separator()
        self.step(1)

    def replace_all(self):
        ed = self.app.cur
        pat = self._pattern()
        if not ed or not pat:
            return
        s = ed.get_text()
        try:
            new, n = pat.subn((lambda m: m.expand(self.rv.get())) if self.regex else (lambda m: self.rv.get()), s)
        except (re.error, IndexError) as e:
            self.app.toast("Bad replacement: %s" % e, "error")
            return
        if n:
            t = ed.text
            cur = t.index("insert")
            t.edit_separator()
            t.delete("1.0", "end-1c")
            t.insert("1.0", new)
            t.edit_separator()
            t.mark_set("insert", cur)
        self.refresh_matches()
        self.cnt.set("%d replaced" % n)
        self.app.toast("%d replacement%s" % (n, "" if n == 1 else "s"), "success" if n else "info")


# ----------------------------------------------------------------------------
#  Tab strip
# ----------------------------------------------------------------------------
class TabStrip(tk.Frame):
    H = 38

    def __init__(self, master, app):
        super().__init__(master, height=self.H)
        self.app = app
        self.pack_propagate(False)
        self.right = tk.Frame(self)
        self.right.pack(side="right", fill="y")
        self.list_btn = IconButton(self.right, "chev", self._list_menu, "Open files", size=30, role="act", isize=6)
        self.list_btn.pack(side="left", pady=4)
        self.list_btn._menu_trigger = True
        self.plus = IconButton(self.right, "plus", lambda: app.new_file(), "New file (Ctrl+N)", size=30, role="act", isize=6)
        self.plus.pack(side="left", padx=(0, 6), pady=4)
        self.canvas = tk.Canvas(self, height=self.H, highlightthickness=0, bd=0)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.inner = tk.Frame(self.canvas)
        self.win = self.canvas.create_window(0, 0, window=self.inner, anchor="nw", height=self.H)
        self.ind = tk.Frame(self.inner, height=2)
        self._ind_pos = None
        self.home_tab = None
        self.inner.bind("<Configure>", lambda e: self._sync())
        self.canvas.bind("<Configure>", lambda e: self._sync())
        for wd in (self.canvas, self.inner):
            wd.bind("<MouseWheel>", self._wheel)
            wd.bind("<Button-4>", lambda e: self.canvas.xview_scroll(-2, "units"))
            wd.bind("<Button-5>", lambda e: self.canvas.xview_scroll(2, "units"))
        self.tabs = {}

    def _wheel(self, e):
        self.canvas.xview_scroll(-2 if e.delta > 0 else 2, "units")

    def _sync(self):
        try:
            bbox = (0, 0, self.inner.winfo_reqwidth(), self.H)
            self.canvas.configure(scrollregion=bbox)
        except tk.TclError:
            pass

    def retheme(self):
        th = T()
        self.configure(bg=th["act"])
        self.right.configure(bg=th["act"])
        self.canvas.configure(bg=th["act"])
        self.list_btn.retheme()
        self.plus.retheme()
        self.refresh()

    def _list_menu(self):
        app = self.app
        items = [(("●  " if e.dirty else "     ") + e.title(), "", lambda e=e: app.switch_to(e)) for e in app.editors]
        if not items:
            items = [("No open files", "", None)]
        PopupMenu(app, items, self.list_btn.winfo_rootx() - 180, self.list_btn.winfo_rooty() + self.list_btn.winfo_height() + 2)

    def refresh(self):
        app, th = self.app, T()
        for w in self.inner.winfo_children():
            if w is not self.ind:
                w.destroy()
        self.inner.configure(bg=th["act"])
        self.canvas.configure(bg=th["act"])
        self.tabs = {}
        self._make_tab("Home", None, app.home_visible or not app.editors, None)
        for ed in app.editors:
            self._make_tab(ed.title(), ed, ed is app.cur and not app.home_visible, ed.dirty)
        self.after_idle(self._reveal)
        self.after_idle(self._move_ind)

    def _move_ind(self):
        """Glide the accent line under the active tab (one persistent frame, so it can slide between tabs)."""
        app = self.app
        try:
            target = self.home_tab if (app.home_visible or app.cur not in self.tabs) else self.tabs[app.cur]
            if target is None:
                return
            self.update_idletasks()
            x, w = target.winfo_x(), target.winfo_width()
            self.ind.configure(bg=T()["accent"])
        except tk.TclError:
            return
        old = self._ind_pos
        self._ind_pos = (x, w)

        def put(px, pw):
            self.ind.place(x=int(px), y=0, width=max(int(pw), 1), height=2)
            self.ind.lift()
        if old is None:
            put(x, w)
            return
        ox, ow = old
        tween(("ind", id(self)), 260, lambda p: put(ox + (x - ox) * p, ow + (w - ow) * p), ease=ease_in_out)

    def _lang_color(self, ed):
        th = T()
        return {"python": th["bi"], "cpp": th["kw"], "c": th["cyan"]}.get(ed.lang, th["muted"])

    def _make_tab(self, title, ed, active, dirty):
        app, th = self.app, T()
        bg = th["bg"] if active else th["act"]
        f = tk.Frame(self.inner, bg=bg, cursor="hand2")
        f.pack(side="left", fill="y", padx=(0, 1))
        tk.Frame(f, height=2, bg=bg).pack(side="top", fill="x")
        body = tk.Frame(f, bg=bg)
        body.pack(fill="both", expand=True)
        widgets = [f, body]
        if ed is None:                                      # the Home tab
            self.home_tab = f
            ic = tk.Canvas(body, width=22, height=22, highlightthickness=0, bd=0, bg=bg, cursor="hand2")
            draw_icon(ic, "home", 11, 12, 6, th["accent"] if active else th["muted"], 1.4)
            ic.pack(side="left", padx=(12, 0), pady=(4, 0))
            widgets.append(ic)
            lab = TLabel(body, text="Home", bg=bg, fg=th["fg"] if active else th["muted"], font=app.ui_font, padx=6, pady=6, cursor="hand2")
            lab.pack(side="left", padx=(0, 12))
            widgets.append(lab)
            for w in widgets:
                w.bind("<Button-1>", lambda e: app.show_home())
            return
        dot = tk.Canvas(body, width=18, height=22, highlightthickness=0, bd=0, bg=bg, cursor="hand2")
        dot.create_oval(5, 8, 13, 16, fill=self._lang_color(ed), outline="")
        dot.pack(side="left", padx=(8, 0), pady=(4, 0))
        lab = TLabel(body, text=title, bg=bg, fg=th["fg"] if active else th["muted"], font=app.ui_font, padx=4, pady=6, cursor="hand2")
        lab.pack(side="left")
        x = TLabel(body, text="●" if dirty else "✕", bg=bg, fg=th["accent"] if dirty else th["dim"], font=app.ui_font, padx=8, cursor="hand2")
        x.pack(side="left", padx=(0, 4))
        x.bind("<Enter>", lambda e, x=x: x.configure(text="✕", fg=th["red"]))
        x.bind("<Leave>", lambda e, x=x, d=dirty: x.configure(text="●" if d else "✕", fg=th["accent"] if d else th["dim"]))
        x.bind("<Button-1>", lambda e, ed=ed: app.close_tab(ed))
        for w in (f, body, dot, lab):
            w.bind("<Button-1>", lambda e, ed=ed: app.switch_to(ed))
            w.bind(MIDDLE_CLICK, lambda e, ed=ed: app.close_tab(ed))
            for seq in RIGHT_CLICK:
                w.bind(seq, lambda e, ed=ed: app.tab_menu(ed, e))
        if not active:
            def hov(on, w=body, ws=(f, body, dot, lab, x)):
                for q in ws:
                    try:
                        q.configure(bg=th["panel"] if on else th["act"])
                    except tk.TclError:
                        pass
            for w in (f, body, dot, lab):
                w.bind("<Enter>", lambda e, h=hov: h(True), add="+")
                w.bind("<Leave>", lambda e, h=hov: h(False), add="+")
        self.tabs[ed] = f

    def _reveal(self):
        """Scroll so the active tab is fully visible."""
        try:
            app = self.app
            if app.home_visible or app.cur not in self.tabs:
                return
            f = self.tabs[app.cur]
            self.update_idletasks()
            total = max(self.inner.winfo_reqwidth(), 1)
            x1, x2 = f.winfo_x(), f.winfo_x() + f.winfo_width()
            lo, hi = self.canvas.xview()
            vis_a, vis_b = lo * total, hi * total
            if x1 < vis_a:
                self.canvas.xview_moveto(max(0, (x1 - 8) / total))
            elif x2 > vis_b:
                self.canvas.xview_moveto(min(1, (x2 - (hi - lo) * total + 8) / total))
        except tk.TclError:
            pass


# ----------------------------------------------------------------------------
#  Explorer (sidebar)
# ----------------------------------------------------------------------------
def make_tree_icons(th):
    try:
        return _make_tree_icons(th)
    except tk.TclError:
        blank = tk.PhotoImage(width=16, height=16)
        return {k: blank for k in ("folder", "folder_open", "file", "py", "cpp", "c", "h", "json", "txt")}


def _make_tree_icons(th):
    """16x16 file/folder icons built from coloured rectangles (no image files needed)."""
    def blank():
        return tk.PhotoImage(width=16, height=16)

    def box(im, col, x1, y1, x2, y2):
        im.put(col, to=(x1, y1, x2, y2))
    icons = {}
    fol, fol2 = th["accent"], mix(th["accent"], "#ffffff", .25)
    im = blank()
    box(im, mix(fol, th["side"], .25), 1, 3, 7, 5)
    box(im, fol, 1, 5, 15, 13)
    icons["folder"] = im
    im = blank()
    box(im, mix(fol, th["side"], .25), 1, 3, 7, 5)
    box(im, mix(fol, th["side"], .45), 1, 5, 14, 8)
    box(im, fol2, 3, 7, 16, 13)
    icons["folder_open"] = im
    pg = mix(th["side"], th["fg"], .30)
    for key, col in (("file", th["muted"]), ("py", th["bi"]), ("cpp", th["kw"]), ("c", th["cyan"]), ("h", th["ty"]),
                     ("json", th["yellow"]), ("txt", th["muted"])):
        im = blank()
        box(im, pg, 3, 1, 13, 15)
        box(im, mix(pg, th["side"], .5), 9, 1, 13, 5)
        box(im, col, 5, 8, 11, 10)
        box(im, col, 5, 11, 9, 13)
        icons[key] = im
    return icons


FILE_KIND = {".py": "py", ".pyw": "py", ".cpp": "cpp", ".cc": "cpp", ".cxx": "cpp", ".hpp": "h", ".h": "h", ".c": "c",
             ".json": "json", ".txt": "txt", ".md": "txt"}


class Explorer(tk.Frame):
    SKIP = {".git", "__pycache__", "node_modules", ".idea", ".vscode", ".venv", "venv", ".mypy_cache", ".pytest_cache"}

    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self.paths, self.kinds, self.by_path = {}, {}, {}
        self.root_path = None
        self.icons = {}
        f = app.ui_font
        self.head = tk.Frame(self)
        self.head.pack(fill="x")
        self.title = TLabel(self.head, text="Explorer", font=app.ui_bold, anchor="w", padx=14, pady=10)
        self.title.pack(side="left")
        self.btns = []
        for icon, tip, cmd in (("openfolder", "Open folder", app.open_folder), ("refresh", "Refresh", self.refresh),
                               ("newfolder", "New folder", lambda: self.new_folder()), ("newfile", "New file", lambda: self.new_file())):
            b = IconButton(self.head, icon, cmd, tip, size=28, role="side", isize=6)
            b.pack(side="right", padx=(0, 2), pady=4)
            self.btns.append(b)
        self.body = tk.Frame(self)
        self.body.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(self.body, show="tree", selectmode="browse", style="Legend.Treeview")
        self.sb = ttk.Scrollbar(self.body, orient="vertical", command=self.tree.yview, style="Legend.Vertical.TScrollbar")
        self.tree.configure(yscrollcommand=self.sb.set)
        self.empty = tk.Frame(self.body)
        self.empty_l = TLabel(self.empty, text="No folder open", font=app.ui_bold, pady=4)
        self.empty_l.pack(pady=(40, 2))
        self.empty_s = TLabel(self.empty, text="Open a folder to browse and\nmanage its files here.", font=f, justify="center")
        self.empty_s.pack()
        self.empty_b = Btn(self.empty, "Open Folder", app.open_folder, icon="openfolder", kind="primary", role="side", height=34, padx=16)
        self.empty_b.pack(pady=16)
        self.tree.bind("<<TreeviewOpen>>", self._expand)
        self.tree.bind("<ButtonRelease-1>", self._click)
        self.tree.bind("<Return>", self._activate)
        self.tree.bind("<F2>", lambda e: self.rename())
        self.tree.bind("<Delete>", lambda e: self.delete())
        for seq in RIGHT_CLICK:
            self.tree.bind(seq, self._menu)
        self._show_empty(True)
        self.retheme()

    def _show_empty(self, on):
        if on:
            self.tree.pack_forget()
            self.sb.pack_forget()
            self.empty.pack(fill="both", expand=True)
        else:
            self.empty.pack_forget()
            self.sb.pack(side="right", fill="y")
            self.tree.pack(fill="both", expand=True)

    def retheme(self):
        th = T()
        self.configure(bg=th["side"])
        for w in (self.head, self.body, self.empty):
            w.configure(bg=th["side"])
        self.title.configure(bg=th["side"], fg=th["fg"])
        self.empty_l.configure(bg=th["side"], fg=th["fg"])
        self.empty_s.configure(bg=th["side"], fg=th["muted"])
        for b in self.btns:
            b.retheme()
        self.empty_b.retheme()
        self.icons = make_tree_icons(th)
        for iid, kind in self.kinds.items():
            try:
                self.tree.item(iid, image=self.icons[kind if kind != "folder" or not self.tree.item(iid, "open") else "folder_open"])
            except tk.TclError:
                pass

    # ---- tree content ------------------------------------------------------
    def _kind(self, path):
        if os.path.isdir(path):
            return "folder"
        return FILE_KIND.get(os.path.splitext(path)[1].lower(), "file")

    def set_root(self, path):
        self.root_path = path
        self.tree.delete(*self.tree.get_children())
        self.paths, self.kinds, self.by_path = {}, {}, {}
        if not path or not os.path.isdir(path):
            self._show_empty(True)
            return
        self._show_empty(False)
        iid = self.tree.insert("", "end", text="  " + (os.path.basename(path.rstrip("/\\")) or path), open=True,
                               image=self.icons["folder_open"])
        self._add_node(iid, path, "folder")
        self._fill(iid)

    def _add_node(self, iid, path, kind):
        self.paths[iid] = path
        self.kinds[iid] = kind
        self.by_path[os.path.normcase(os.path.abspath(path))] = iid

    def _fill(self, parent):
        path = self.paths[parent]
        for c in self.tree.get_children(parent):
            self._forget(c)
            self.tree.delete(c)
        try:
            names = sorted(os.listdir(path), key=lambda n: (not os.path.isdir(os.path.join(path, n)), n.lower()))
        except Exception:
            return
        for n in names:
            if n in self.SKIP or n.startswith("."):
                continue
            p = os.path.join(path, n)
            kind = self._kind(p)
            iid = self.tree.insert(parent, "end", text="  " + n, image=self.icons[kind])
            self._add_node(iid, p, kind)
            if kind == "folder":
                self.tree.insert(iid, "end", text="…")

    def _forget(self, iid):
        for c in self.tree.get_children(iid):
            self._forget(c)
        p = self.paths.pop(iid, None)
        self.kinds.pop(iid, None)
        if p:
            self.by_path.pop(os.path.normcase(os.path.abspath(p)), None)

    def _expand(self, e=None):
        iid = self.tree.focus()
        if iid in self.paths and self.kinds.get(iid) == "folder":
            self._fill(iid)
            self.tree.item(iid, image=self.icons["folder_open"])

    def refresh(self):
        if not self.root_path:
            return
        open_dirs = {p for i, p in self.paths.items() if self.kinds.get(i) == "folder" and self.tree.item(i, "open")}
        self.set_root(self.root_path)

        def reopen(parent):
            for c in self.tree.get_children(parent):
                p = self.paths.get(c)
                if p and p in open_dirs:
                    self._fill(c)
                    self.tree.item(c, open=True, image=self.icons["folder_open"])
                    reopen(c)
        top = self.tree.get_children("")
        if top:
            reopen(top[0])
        self.app.toast("Explorer refreshed", "info", 1200)

    def reveal(self, path):
        """Select (and expand to) a file in the tree, if it lives inside the opened folder."""
        if not self.root_path or not path:
            return
        root = os.path.normcase(os.path.abspath(self.root_path))
        full = os.path.normcase(os.path.abspath(path))
        if not full.startswith(root + os.sep):
            return
        parts = os.path.relpath(path, self.root_path).split(os.sep)
        cur = os.path.abspath(self.root_path)
        for part in parts[:-1]:
            cur = os.path.join(cur, part)
            iid = self.by_path.get(os.path.normcase(cur))
            if iid is None:
                return
            self._fill(iid)
            self.tree.item(iid, open=True, image=self.icons["folder_open"])
        iid = self.by_path.get(full)
        if iid:
            self.tree.selection_set(iid)
            self.tree.see(iid)

    # ---- interaction -----------------------------------------------------------
    def _click(self, e):
        iid = self.tree.identify_row(e.y)
        if not iid or iid not in self.paths:
            return
        self.tree.selection_set(iid)
        self.tree.focus(iid)
        if self.kinds.get(iid) == "folder":
            if self.tree.identify_element(e.x, e.y) == "Treeitem.indicator":
                return
            opening = not self.tree.item(iid, "open")
            if opening:
                self._fill(iid)
            self.tree.item(iid, open=opening, image=self.icons["folder_open" if opening else "folder"])
        else:
            self.app.open_file(self.paths[iid])

    def _activate(self, e=None):
        iid = self.tree.focus()
        p = self.paths.get(iid)
        if p and os.path.isfile(p):
            self.app.open_file(p)

    def _target_dir(self, path=None):
        path = path or self.paths.get(self.tree.focus()) or self.root_path
        if not path:
            return None
        return path if os.path.isdir(path) else os.path.dirname(path)

    def _menu(self, e):
        iid = self.tree.identify_row(e.y)
        if iid:
            self.tree.selection_set(iid)
            self.tree.focus(iid)
        p = self.paths.get(iid) if iid else self.root_path
        isfile = bool(p and os.path.isfile(p))
        items = []
        if isfile:
            items += [("Open", "", lambda: self.app.open_file(p)), None]
        items += [("New File…", "", lambda: self.new_file(p)), ("New Folder…", "", lambda: self.new_folder(p)), None]
        if iid and p != self.root_path:
            items += [("Rename…", "F2", lambda: self.rename(p)), ("Delete", "Del", lambda: self.delete(p)), None]
        if p:
            items += [("Copy path", "", lambda: self.app.copy_text(p, "Path copied")),
                      ("Reveal in file manager", "", lambda: self.app.reveal_in_os(p))]
        items += [None, ("Refresh", "", self.refresh)]
        PopupMenu(self.app, items, e.x_root, e.y_root)

    def _valid_name(self, folder):
        def check(v):
            if not v:
                return "Enter a name."
            if any(ch in v for ch in '/\\:*?"<>|'):
                return 'A name can\'t contain / \\ : * ? " < > |'
            if os.path.exists(os.path.join(folder, v)):
                return "That name already exists."
            return None
        return check

    def new_file(self, path=None):
        d = self._target_dir(path)
        if not d:
            self.app.open_folder()
            return
        name = quick_input(self.app, "New file", "Create in " + shorten_path(d, 52), "untitled.py", self._valid_name(d), "Create")
        if not name:
            return
        p = os.path.join(d, name)
        try:
            open(p, "a", encoding="utf-8").close()
        except Exception as ex:
            messagebox.showerror(APP, "Could not create the file:\n%s" % ex)
            return
        self.refresh_dir(d)
        self.app.open_file(p)
        self.app.toast("Created " + name, "success")

    def new_folder(self, path=None):
        d = self._target_dir(path)
        if not d:
            self.app.open_folder()
            return
        name = quick_input(self.app, "New folder", "Create in " + shorten_path(d, 52), "", self._valid_name(d), "Create")
        if not name:
            return
        try:
            os.makedirs(os.path.join(d, name))
        except Exception as ex:
            messagebox.showerror(APP, "Could not create the folder:\n%s" % ex)
            return
        self.refresh_dir(d)
        self.app.toast("Created folder " + name, "success")

    def rename(self, path=None):
        p = path or self.paths.get(self.tree.focus())
        if not p or p == self.root_path:
            return
        d = os.path.dirname(p)
        name = quick_input(self.app, "Rename", "New name for " + os.path.basename(p), os.path.basename(p),
                           lambda v: None if v == os.path.basename(p) else self._valid_name(d)(v), "Rename")
        if not name or name == os.path.basename(p):
            return
        new = os.path.join(d, name)
        try:
            os.rename(p, new)
        except Exception as ex:
            messagebox.showerror(APP, "Could not rename:\n%s" % ex)
            return
        self.app.on_path_renamed(p, new)
        self.refresh_dir(d)
        self.app.toast("Renamed to " + name, "success")

    def delete(self, path=None):
        p = path or self.paths.get(self.tree.focus())
        if not p or p == self.root_path:
            return
        what = "folder" if os.path.isdir(p) else "file"
        if not messagebox.askyesno(APP, "Delete the %s '%s'?\nThis cannot be undone." % (what, os.path.basename(p)), icon="warning"):
            return
        try:
            shutil.rmtree(p) if os.path.isdir(p) else os.remove(p)
        except Exception as ex:
            messagebox.showerror(APP, "Could not delete:\n%s" % ex)
            return
        self.app.on_path_deleted(p)
        self.refresh_dir(os.path.dirname(p))
        self.app.toast("Deleted " + os.path.basename(p), "info")

    def refresh_dir(self, d):
        iid = self.by_path.get(os.path.normcase(os.path.abspath(d)))
        if iid:
            self._fill(iid)
            self.tree.item(iid, open=True, image=self.icons["folder_open"])
        elif self.root_path:
            self.set_root(self.root_path)


# ----------------------------------------------------------------------------
#  Search in files (sidebar)
# ----------------------------------------------------------------------------
TEXT_EXT = {".py", ".pyw", ".c", ".cpp", ".cc", ".cxx", ".h", ".hpp", ".txt", ".md", ".json", ".cfg", ".ini", ".toml",
            ".yaml", ".yml", ".html", ".css", ".js", ".ts", ".csv", ".xml", ".sh", ".bat", ".cmake", ".mk", ""}


class SearchView(tk.Frame):
    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self.q = queue.Queue()
        self.gen = 0
        self.hits = []
        self.var = tk.StringVar()
        f = app.ui_font
        self.title = TLabel(self, text="Search", font=app.ui_bold, anchor="w", padx=14, pady=10)
        self.title.pack(fill="x")
        self.box = tk.Frame(self)
        self.box.pack(fill="x", padx=12)
        self.entry = tk.Entry(self.box, textvariable=self.var, font=f)
        self.entry.pack(side="left", fill="x", expand=True, ipady=5)
        self.chip_case = ToggleChip(self.box, "Aa", self._go, "Match case")
        self.chip_re = ToggleChip(self.box, ".*", self._go, "Regular expression")
        self.chip_case.pack(side="left", padx=(5, 0))
        self.chip_re.pack(side="left", padx=(3, 0))
        self.status = TLabel(self, text="Type to search the open folder and open files.", font=f, anchor="w", justify="left",
                               padx=14, pady=8, wraplength=240)
        self.status.pack(fill="x")
        self.body = tk.Frame(self)
        self.body.pack(fill="both", expand=True)
        self.lb = tk.Listbox(self.body, activestyle="none", bd=0, highlightthickness=0, font=f, exportselection=False)
        self.sb = ttk.Scrollbar(self.body, orient="vertical", command=self.lb.yview, style="Legend.Vertical.TScrollbar")
        self.lb.configure(yscrollcommand=self.sb.set)
        self.sb.pack(side="right", fill="y")
        self.lb.pack(fill="both", expand=True, padx=(8, 0))
        self.lb.bind("<ButtonRelease-1>", self._open)
        self.lb.bind("<Return>", self._open)
        self._job = None
        self.var.trace_add("write", lambda *a: self._soon())
        self.entry.bind("<Return>", lambda e: (self._go(), "break")[1])
        self.entry.bind("<Down>", lambda e: (self.lb.focus_set(), self.lb.selection_set(0), "break")[2])
        self.retheme()

    def retheme(self):
        th = T()
        self.configure(bg=th["side"])
        for w in (self.box, self.body):
            w.configure(bg=th["side"])
        self.title.configure(bg=th["side"], fg=th["fg"])
        self.status.configure(bg=th["side"], fg=th["muted"])
        style_entry(self.entry)
        self.chip_case.retheme()
        self.chip_re.retheme()
        self.lb.configure(bg=th["side"], fg=th["fg"], selectbackground=mix(th["side"], th["accent"], .25), selectforeground=th["fg"])

    def focus_entry(self):
        self.entry.focus_set()
        self.entry.select_range(0, "end")

    def _soon(self):
        if self._job:
            self.after_cancel(self._job)
        self._job = self.after(380, self._go)

    def _pattern(self):
        q = self.var.get()
        if not q:
            return None
        try:
            return re.compile(q if self.chip_re.on else re.escape(q), 0 if self.chip_case.on else re.I)
        except re.error:
            return None

    def _go(self):
        self._job = None
        self.gen += 1
        self.hits = []
        self.lb.delete(0, "end")
        pat = self._pattern()
        if not pat:
            self.status.configure(text="Type to search the open folder and open files." if not self.var.get() else "Invalid regular expression.")
            return
        app = self.app
        buffers = {}
        for ed in app.editors:
            key = os.path.normcase(os.path.abspath(ed.path)) if ed.path else "untitled:%s" % ed.title()
            buffers[key] = (ed.path or ed.title(), ed.get_text())
        root = app.explorer.root_path
        self.status.configure(text="Searching…")
        threading.Thread(target=self._work, args=(self.gen, pat, root, buffers), daemon=True).start()
        self.after(60, self._pump, self.gen)

    def _work(self, gen, pat, root, buffers):
        count = 0
        seen = set()

        def scan(label, path, text):
            nonlocal count
            for i, line in enumerate(text.split("\n"), 1):
                m = pat.search(line)
                if m:
                    count += 1
                    self.q.put((gen, "hit", (path, i, m.start() + 1, line.strip()[:160])))
                    if count >= 500:
                        return False
            return True
        for key, (path, text) in buffers.items():
            seen.add(key)
            if not scan(path, path, text):
                self.q.put((gen, "done", count))
                return
        if root:
            for dp, dns, fns in os.walk(root):
                if gen != self.gen:
                    return
                dns[:] = [d for d in dns if d not in Explorer.SKIP and not d.startswith(".")]
                for fn in fns:
                    p = os.path.join(dp, fn)
                    if os.path.splitext(fn)[1].lower() not in TEXT_EXT or os.path.normcase(os.path.abspath(p)) in seen:
                        continue
                    try:
                        if os.path.getsize(p) > 1_000_000:
                            continue
                        with open(p, "r", encoding="utf-8") as f:
                            text = f.read()
                    except Exception:
                        continue
                    if not scan(p, p, text):
                        self.q.put((gen, "done", count))
                        return
        self.q.put((gen, "done", count))

    def _pump(self, gen):
        if gen != self.gen:
            return
        finished = False
        try:
            for _ in range(200):
                g, kind, data = self.q.get_nowait()
                if g != self.gen:
                    continue
                if kind == "hit":
                    path, ln, col, text = data
                    self.hits.append((path, ln, col))
                    self.lb.insert("end", "%s:%d   %s" % (os.path.basename(path), ln, text))
                else:
                    finished = True
                    n = data
                    self.status.configure(text=("%d result%s%s" % (n, "" if n == 1 else "s", " (first 500)" if n >= 500 else ""))
                                          if n else "No results.")
        except queue.Empty:
            pass
        if not finished:
            self.after(80, self._pump, gen)

    def _open(self, e=None):
        sel = self.lb.curselection()
        if sel and sel[0] < len(self.hits):
            path, ln, col = self.hits[sel[0]]
            self.app.goto_file(path, ln, col)


# ----------------------------------------------------------------------------
#  Run & Build (sidebar)
# ----------------------------------------------------------------------------
class RunView(tk.Frame):
    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        f = app.ui_font
        self.title = TLabel(self, text="Run & Build", font=app.ui_bold, anchor="w", padx=14, pady=10)
        self.title.pack(fill="x")
        self.run_b = Btn(self, "Run current file", app.run_current, icon="run", kind="success", role="side", height=36, padx=14, minw=210)
        self.run_b.pack(anchor="w", padx=14, pady=(2, 6))
        row = tk.Frame(self)
        row.pack(anchor="w", padx=14)
        self.row = row
        self.stop_b = Btn(row, "Stop", app.stop_run, icon="stop", kind="danger", role="side", height=30, padx=12)
        self.stop_b.pack(side="left")
        self.build_b = Btn(row, "Build only", lambda: app.run_current(build_only=True), icon="build", kind="outline", role="side", height=30, padx=12)
        self.build_b.pack(side="left", padx=(8, 0))
        self.lab_args = TLabel(self, text="Program arguments", font=f, anchor="w", padx=14, pady=0)
        self.lab_args.pack(fill="x", pady=(16, 4))
        self.args_var = tk.StringVar(value=app.cfg.get("run_args", ""))
        self.args = tk.Entry(self, textvariable=self.args_var, font=f)
        self.args.pack(fill="x", padx=14, ipady=5)
        self.args_var.trace_add("write", lambda *a: app.cfg.__setitem__("run_args", self.args_var.get()))
        self.opts = []
        for text, key in (("Save the file before running", "autosave_on_run"), ("Clear the terminal on each run", "clear_on_run")):
            r = tk.Frame(self)
            r.pack(fill="x", padx=14, pady=(12, 0))
            sw = Switch(r, app.cfg.get(key, True), lambda v, k=key: app.cfg.__setitem__(k, v), role="side")
            sw.pack(side="left")
            lb = TLabel(r, text=text, font=f, anchor="w", padx=10)
            lb.pack(side="left")
            self.opts.append((r, sw, lb))
        self.tool = TLabel(self, text="", font=f, anchor="w", justify="left", padx=14, pady=0)
        self.tool.pack(fill="x", pady=(22, 4))
        self.set_b = Btn(self, "Compiler settings", lambda: app.open_settings("C/C++"), icon="gear", kind="outline", role="side", height=30, padx=12)
        self.set_b.pack(anchor="w", padx=14, pady=(4, 0))
        self.note = TLabel(self, text="Tip: errors in the Terminal and Problems list are clickable and jump to the exact line.\n"
                             "Step-by-step debugging isn't built in yet.", font=f, anchor="w", justify="left", wraplength=240, padx=14)
        self.note.pack(fill="x", pady=(18, 0))
        self.retheme()

    def retheme(self):
        th = T()
        self.configure(bg=th["side"])
        self.row.configure(bg=th["side"])
        for w in (self.title, self.lab_args, self.tool):
            w.configure(bg=th["side"], fg=th["fg"] if w is self.title else th["muted"])
        self.note.configure(bg=th["side"], fg=th["dim"])
        style_entry(self.args)
        for r, sw, lb in self.opts:
            r.configure(bg=th["side"])
            sw.retheme()
            lb.configure(bg=th["side"], fg=th["fg"])
        for b in (self.run_b, self.stop_b, self.build_b, self.set_b):
            b.retheme()

    def refresh(self):
        app = self.app
        py, cx, cc = app.toolchain()
        self.tool.configure(text="Toolchain\n  Python    %s\n  C++ (g++) %s\n  C (gcc)   %s" % (
            "✔ " + shorten_path(py, 30), "✔ " + shorten_path(cx, 30) if cx else "✖ not found",
            "✔ " + shorten_path(cc, 30) if cc else "✖ not found"))
        self.stop_b.set_enabled(app.runner.running)
        self.args_var.set(app.cfg.get("run_args", ""))
        for (r, sw, lb), key in zip(self.opts, ("autosave_on_run", "clear_on_run")):
            sw.set(app.cfg.get(key, True))


# ----------------------------------------------------------------------------
#  Log view (terminal / output / debug console) with clickable error lines
# ----------------------------------------------------------------------------
class LogView(tk.Frame):
    def __init__(self, master, app, name="log"):
        super().__init__(master)
        self.app, self.name = app, name
        self.link_n = 0
        self._pend = None            # last Python traceback frame waiting for its "XxxError: ..." line
        self.text = tk.Text(self, wrap="word", bd=0, highlightthickness=0, padx=14, pady=8, font=app.font, height=6,
                            state="disabled", cursor="arrow", spacing1=1, spacing3=1)
        self.sb = ttk.Scrollbar(self, orient="vertical", command=self.text.yview, style="Legend.Vertical.TScrollbar")
        self.text.configure(yscrollcommand=self.sb.set)
        self.sb.pack(side="right", fill="y")
        self.text.pack(fill="both", expand=True)
        self.text.mark_set("scan", "1.0")
        self.text.mark_gravity("scan", "left")
        SmoothWheel(self.text, "text", lambda: app.font.metrics("linespace") + 2)
        self.retheme()

    def retheme(self):
        th = T()
        t = self.text
        t.configure(bg=th["panel"], fg=th["fg"], insertbackground=th["fg"], selectbackground=th["sel"], font=self.app.font)
        t.tag_configure("out", foreground=th["fg"])
        t.tag_configure("err", foreground=th["red"])
        t.tag_configure("warn", foreground=th["yellow"])
        t.tag_configure("info", foreground=th["cyan"])
        t.tag_configure("in", foreground=th["green"])
        t.tag_configure("dim", foreground=th["muted"])
        for tag in t.tag_names():
            if tag.startswith("lnk"):
                t.tag_configure(tag, foreground=th["cyan"], underline=True)

    def append(self, text, tag="out"):
        t = self.text
        at_bottom = t.yview()[1] > 0.97
        t.configure(state="normal")
        t.insert("end", visual(text) if (_NEED_BIDI[0] and _has_rtl(text)) else text, tag)
        self._scan()
        t.configure(state="disabled")
        if at_bottom:
            t.see("end")

    def clear(self):
        t = self.text
        t.configure(state="normal")
        t.delete("1.0", "end")
        t.configure(state="disabled")
        t.mark_set("scan", "1.0")
        self._pend = None

    def get_all(self):
        return self.text.get("1.0", "end-1c")

    def _scan(self):
        t, app, th = self.text, self.app, T()
        start = t.index("scan")
        end = t.index("end-1c")
        chunk = t.get(start, end)
        if "\n" not in chunk:
            return
        complete = chunk[:chunk.rfind("\n") + 1]
        base_line = int(start.split(".")[0])
        for i, line in enumerate(complete.split("\n")[:-1]):
            info = parse_error_line(line)
            if info:
                path, ln, col, kind = info
                full = path if os.path.isabs(path) else os.path.join(app.last_run_dir(), path)
                self.link_n += 1
                tag = "lnk%d" % self.link_n
                ls, le = "%d.0" % (base_line + i), "%d.end" % (base_line + i)
                t.tag_configure(tag, foreground=th["cyan"], underline=True)
                t.tag_add(tag, ls, le)
                t.tag_bind(tag, "<Button-1>", lambda e, p=full, l=ln, cc=col: app.goto_file(p, l, cc))
                t.tag_bind(tag, "<Enter>", lambda e: t.configure(cursor="hand2"))
                t.tag_bind(tag, "<Leave>", lambda e: t.configure(cursor="arrow"))
                if PYTB_RE.match(line):
                    self._pend = (full, ln, col)
                elif kind in ("error", "fatal error", "warning"):
                    parts = re.split(r"(?:fatal error|error|warning):\s*", line, maxsplit=1, flags=re.I)
                    app.add_diag("warning" if kind == "warning" else "error", full, ln, col, (parts[1] if len(parts) > 1 else line).strip())
            elif self._pend and line.strip() and not line.startswith((" ", "\t")) and not line.startswith("Traceback"):
                app.add_diag("error", self._pend[0], self._pend[1], self._pend[2], line.strip())
                self._pend = None
        t.mark_set("scan", "%d.0" % (base_line + complete.count("\n")))


# ----------------------------------------------------------------------------
#  Problems list
# ----------------------------------------------------------------------------
class ProblemsView(tk.Frame):
    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self.items = {}
        self.tree = ttk.Treeview(self, show="tree", selectmode="browse", style="Legend.Panel.Treeview")
        self.sb = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview, style="Legend.Vertical.TScrollbar")
        self.tree.configure(yscrollcommand=self.sb.set)
        self.sb.pack(side="right", fill="y")
        self.tree.pack(fill="both", expand=True)
        self.empty = TLabel(self, text="No problems found", font=app.ui_font)
        self.tree.bind("<ButtonRelease-1>", self._open)
        self.tree.bind("<Return>", self._open)
        self.retheme()

    def retheme(self):
        th = T()
        self.configure(bg=th["panel"])
        self.empty.configure(bg=th["panel"], fg=th["muted"])
        self.tree.tag_configure("error", foreground=th["red"])
        self.tree.tag_configure("warning", foreground=th["yellow"])

    def refresh(self, diags):
        self.tree.delete(*self.tree.get_children())
        self.items = {}
        for d in diags:
            icon = "✖" if d["kind"] == "error" else "▲"
            text = "%s  %s      %s:%d" % (icon, d["msg"][:160], os.path.basename(d["path"]), d["line"])
            iid = self.tree.insert("", "end", text=text, tags=(d["kind"],))
            self.items[iid] = d
        if diags:
            self.empty.place_forget()
        else:
            self.empty.place(relx=.5, rely=.45, anchor="center")

    def _open(self, e=None):
        iid = self.tree.identify_row(e.y) if (e is not None and hasattr(e, "y")) else self.tree.focus()
        d = self.items.get(iid or self.tree.focus())
        if d:
            self.app.goto_file(d["path"], d["line"], d["col"])


# ----------------------------------------------------------------------------
#  Bottom panel: Terminal | Output | Problems | Debug Console
# ----------------------------------------------------------------------------
class BottomPanel(tk.Frame):
    TABS = ("Terminal", "Output", "Problems", "Debug Console")

    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        f = app.ui_font
        self.tab = "Terminal"
        self.head = tk.Frame(self, height=38)
        self.head.pack(fill="x")
        self.head.pack_propagate(False)
        self.tab_w = {}
        for name in self.TABS:
            box = tk.Frame(self.head, cursor="hand2")
            box.pack(side="left", fill="y", padx=(10 if name == "Terminal" else 0, 0))
            lab = TLabel(box, text=name, font=f, padx=10, cursor="hand2")
            lab.pack(fill="both", expand=True, pady=(8, 0))
            bar = tk.Frame(box, height=2)
            bar.pack(side="bottom", fill="x", padx=8)
            for w in (box, lab):
                w.bind("<Button-1>", lambda e, n=name: self.show_tab(n))
            self.tab_w[name] = (box, lab, bar)
        self.close_b = IconButton(self.head, "close", app.hide_panel, "Hide panel (Ctrl+J)", size=28, role="panel", isize=5)
        self.close_b.pack(side="right", padx=(0, 8), pady=4)
        self.clear_b = IconButton(self.head, "trash", self.clear_current, "Clear", size=28, role="panel", isize=6)
        self.clear_b.pack(side="right", pady=4)
        self.fix_b = Btn(self.head, "Fix with AI", app.ai_fix_error, icon="ai", kind="ai", role="panel", height=26, padx=10, tip="Ask the assistant to fix the last error")
        self.fix_b.pack(side="right", padx=8, pady=6)
        self.line = tk.Frame(self, height=1)
        self.line.pack(fill="x")
        self.body = tk.Frame(self)
        self.body.pack(fill="both", expand=True)
        # terminal = program output + a stdin line
        self.term_f = tk.Frame(self.body)
        self.term = LogView(self.term_f, app, "terminal")
        self.inrow = tk.Frame(self.term_f)
        self.inrow.pack(side="bottom", fill="x")
        self.term.pack(fill="both", expand=True)
        self.in_label = TLabel(self.inrow, text="  input ›", font=f)
        self.in_label.pack(side="left")
        self.stdin_var = tk.StringVar()
        self.stdin = tk.Entry(self.inrow, textvariable=self.stdin_var, font=app.font)
        self.stdin.pack(side="left", fill="x", expand=True, pady=6, padx=(6, 6), ipady=3)
        self.send_b = Btn(self.inrow, "Send", app.send_stdin, kind="outline", role="panel", height=28, padx=12)
        self.send_b.pack(side="left")
        self.eof_b = Btn(self.inrow, "EOF", app.close_stdin, kind="ghost", role="panel", height=28, padx=10, tip="Close input (Ctrl+D)")
        self.eof_b.pack(side="left", padx=(2, 8))
        self.stdin.bind("<Return>", lambda e: (app.send_stdin(), "break")[1])
        self.stdin.bind("<Control-d>", lambda e: (app.close_stdin(), "break")[1])
        self.output = LogView(self.body, app, "output")
        self.problems = ProblemsView(self.body, app)
        self.debug = LogView(self.body, app, "debug")
        self.views = {"Terminal": self.term_f, "Output": self.output, "Problems": self.problems, "Debug Console": self.debug}
        self.retheme()
        self.show_tab("Terminal")

    def retheme(self):
        th = T()
        for w in (self, self.head, self.body, self.term_f, self.inrow):
            w.configure(bg=th["panel"])
        self.line.configure(bg=th["border"])
        self.in_label.configure(bg=th["panel"], fg=th["green"])
        style_entry(self.stdin)
        for b in (self.close_b, self.clear_b, self.fix_b, self.send_b, self.eof_b):
            b.retheme()
        for v in (self.term, self.output, self.problems, self.debug):
            v.retheme()
        self._paint_tabs()

    def _paint_tabs(self):
        th = T()
        for name, (box, lab, bar) in self.tab_w.items():
            on = name == self.tab
            box.configure(bg=th["panel"])
            lab.configure(bg=th["panel"], fg=th["fg"] if on else th["muted"])
            bar.configure(bg=th["accent"] if on else th["panel"])

    def show_tab(self, name):
        self.tab = name
        for n, v in self.views.items():
            v.pack_forget()
        self.views[name].pack(fill="both", expand=True)
        self._paint_tabs()
        self.fix_b.pack_forget()
        if name in ("Terminal", "Output", "Problems"):
            self.fix_b.pack(side="right", padx=8, pady=6)
        self.app.cfg["panel_tab"] = name

    def set_problem_count(self, errors, warnings):
        th = T()
        lab = self.tab_w["Problems"][1]
        n = errors + warnings
        lab.configure(text="Problems  %d" % n if n else "Problems")
        if n and self.tab != "Problems":
            lab.configure(fg=th["red"] if errors else th["yellow"])
        else:
            self._paint_tabs()

    def clear_current(self):
        self.app.clear_view(self.tab)

    def view(self, name):
        return {"terminal": self.term, "output": self.output, "debug": self.debug}[name]


# ----------------------------------------------------------------------------
#  AI chat panel (docked on the right)
# ----------------------------------------------------------------------------
class AIPanel(tk.Frame):
    QUICK = [("Explain", "explain"), ("Fix", "fix"), ("Improve", "improve"), ("Refactor", "refactor"),
             ("Generate", "generate"), ("Comment", "comment"), ("Tests", "tests"), ("Error help", "error_help")]
    HINT = ("Hi! I'm your coding assistant.\n\nAsk me anything, or press a button above. "
            "Select some code first to work on just that part.\n\n"
            "No account, no key, no cost. When something fails, press Error help - it works even offline.")
    PLACEHOLDER = "Ask the assistant…   Enter = send · Shift+Enter = new line"

    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self.msgs = load_chat()
        self.busy = False
        self.rid = None
        self.need = False
        self.mark_n = 0
        self.gen_mode = False
        self._ph_on = False
        f = app.ui_font
        # header
        self.head = tk.Frame(self)
        self.head.pack(side="top", fill="x")
        self.spark = tk.Canvas(self.head, width=26, height=26, highlightthickness=0, bd=0)
        self.spark.pack(side="left", padx=(12, 0), pady=8)
        self.title_l = TLabel(self.head, text="Assistant", font=app.ui_bold, padx=6)
        self.title_l.pack(side="left")
        self.model_chip = Chip(self.head, "", lambda: app.open_settings("AI"), role="panel", font=f, tip="AI settings")
        self.model_chip.pack(side="left", padx=2)
        self.hbtns = []
        for icon, tip, cmd in (("close", "Hide (Ctrl+L)", app.hide_ai), ("trash", "Clear chat", self.clear), ("gear", "AI settings", lambda: app.open_settings("AI"))):
            b = IconButton(self.head, icon, cmd, tip, size=28, role="panel", isize=6)
            b.pack(side="right", padx=(0, 2), pady=6)
            self.hbtns.append(b)
        self.line1 = tk.Frame(self, height=1)
        self.line1.pack(side="top", fill="x")
        # first-use notice (built-in AI sends code to a free online service)
        self.notice = tk.Frame(self)
        self.notice_l = TLabel(self.notice, justify="left", anchor="w", wraplength=330, font=f, padx=12, pady=8,
                                 text="The assistant is built in and free - no account needed. It uses a free online model, "
                                      "so your code is sent to that service. For fully private, offline use, set up a local model.")
        self.notice_l.pack(fill="x")
        nb = tk.Frame(self.notice)
        nb.pack(anchor="w", padx=12, pady=(0, 10))
        self.nb = nb
        self.notice_b1 = Btn(nb, "Set up local AI", lambda: self.enable_local_ai(), kind="primary", role="pop", height=28, padx=12)
        self.notice_b1.pack(side="left")
        self.notice_b2 = Btn(nb, "Got it", self.dismiss_notice, kind="outline", role="pop", height=28, padx=12)
        self.notice_b2.pack(side="left", padx=8)
        # context + quick actions
        self.ctx_l = TLabel(self, text="", font=f, anchor="w", padx=14, pady=5)
        self.ctx_l.pack(side="top", fill="x")
        self.quick_f = tk.Frame(self)
        self.quick_f.pack(side="top", fill="x", padx=10, pady=(0, 6))
        self.qb = []
        for i, (text, kind) in enumerate(self.QUICK):
            b = Btn(self.quick_f, text, lambda k=kind: self.quick(k), kind="outline", role="panel", height=26, padx=4, minw=76)
            b.grid(row=i // 4, column=i % 4, sticky="ew", padx=2, pady=2)
            self.qb.append(b)
        for c in range(4):
            self.quick_f.grid_columnconfigure(c, weight=1)
        # footer (input) is packed before the chat so it never gets squeezed out
        self.foot = tk.Frame(self)
        self.foot.pack(side="bottom", fill="x")
        self.opt = tk.Frame(self.foot)
        self.opt.pack(fill="x", padx=12, pady=(8, 4))
        self.t_file = ToggleChip(self.opt, "Current file", lambda: None, "Send the open file with your question")
        self.t_file.on = True
        self.t_file.retheme()
        self.t_out = ToggleChip(self.opt, "Terminal output", lambda: None, "Send the program output (useful for errors)")
        self.t_file.pack(side="left")
        self.t_out.pack(side="left", padx=6)
        self.row = tk.Frame(self.foot)
        self.row.pack(fill="x", padx=12, pady=(0, 12))
        self.send_b = Btn(self.row, "Send", self.on_send, kind="primary", role="panel", height=34, padx=14)
        self.send_b.pack(side="right", padx=(8, 0), anchor="s")          # packed first so the input can never push it away
        self.inp = tk.Text(self.row, height=3, width=10, wrap="word", bd=0, highlightthickness=1, padx=10, pady=8, font=f, undo=True)
        self.app._ctrl_hook(self.inp)
        self.inp.pack(side="left", fill="x", expand=True)
        self.inp.bind("<Return>", lambda e: (self.on_send(), "break")[1])
        self.inp.bind("<Shift-Return>", lambda e: None)
        self.inp.bind("<Escape>", lambda e: (self.stop() if self.busy else None, "break")[1])
        self.inp.bind("<FocusIn>", self._focus_in)
        self.inp.bind("<FocusOut>", self._focus_out)
        self.sb = ttk.Scrollbar(self, orient="vertical", style="Legend.Vertical.TScrollbar")
        self.chat = tk.Text(self, wrap="word", bd=0, highlightthickness=0, padx=14, pady=10, font=f, state="disabled", cursor="arrow")
        self.chat.configure(yscrollcommand=self.sb.set)
        self.sb.configure(command=self.chat.yview)
        self.sb.pack(side="right", fill="y")
        self.chat.pack(side="top", fill="both", expand=True)
        self._cw, self._cjob = 0, None
        self.chat.bind("<Configure>", self._on_chat_resize)
        SmoothWheel(self.chat, "text", lambda: app.font.metrics("linespace") + 4)
        self.retheme()
        self._set_placeholder()
        self.render()

    # ---- look ----------------------------------------------------------
    def retheme(self):
        th, app = T(), self.app
        for w in (self, self.head, self.foot, self.opt, self.row, self.quick_f, self.nb):
            w.configure(bg=th["panel"])
        self.nb.configure(bg=th["pop"])
        self.line1.configure(bg=th["border"])
        self.spark.configure(bg=th["panel"])
        self.spark.delete("all")
        draw_icon(self.spark, "ai", 12, 14, 8, th["accent"])
        self.title_l.configure(bg=th["panel"], fg=th["fg"])
        self.model_chip.retheme()
        for b in self.hbtns + self.qb + [self.send_b, self.notice_b1, self.notice_b2]:
            b.retheme()
        self.t_file.retheme()
        self.t_out.retheme()
        self.ctx_l.configure(bg=th["panel"], fg=th["muted"])
        self.notice.configure(bg=th["pop"], highlightthickness=1, highlightbackground=th["border"])
        self.notice_l.configure(bg=th["pop"], fg=th["fg"])
        self.inp.configure(bg=th["panel2"], insertbackground=th["accent"], highlightbackground=th["border"],
                           highlightcolor=th["accent"], selectbackground=th["sel"], fg=th["muted"] if self._ph_on else th["fg"])
        c = self.chat
        c.configure(bg=th["bg"], fg=th["fg"], selectbackground=th["sel"], insertbackground=th["bg"])
        self._cfont = tkfont.Font(family=app.font.cget("family"), size=max(8, int(app.font.cget("size")) - 2))
        self._bold = tkfont.Font(family=app.ui_font.cget("family"), size=fs(10), weight="bold")
        c.tag_configure("who_user", foreground=th["muted"], font=self._bold, spacing1=10)
        c.tag_configure("who_ai", foreground=th["accent"], font=self._bold, spacing1=10)
        c.tag_configure("user", foreground=th["fg"], background=th["panel2"], lmargin1=8, lmargin2=8, rmargin=8, spacing1=3, spacing3=3)
        c.tag_configure("ai", foreground=th["fg"], lmargin1=2, lmargin2=2, spacing1=1)
        c.tag_configure("bold", foreground=th["fg"], font=self._bold)
        c.tag_configure("icode", foreground=th["dc"], background=th["panel2"], font=self._cfont)
        c.tag_configure("code", foreground=th["fg"], background=th["panel"], font=self._cfont, lmargin1=10, lmargin2=10,
                        rmargin=10, spacing1=1, spacing3=1)
        c.tag_configure("hint", foreground=th["muted"])
        c.tag_configure("rtl", justify="right", wrap="none")
        c.tag_configure("err", foreground=th["red"])
        self.refresh_ready()

    def dismiss_notice(self):
        self.app.cfg["ai_notice_seen"] = True
        self.refresh_ready()

    def enable_local_ai(self):
        """Free, no account: install Ollama (Windows) and download a small coding model, all from inside the app."""
        app = self.app
        if getattr(self, "_setting_up", False):
            return
        self._setting_up = True
        q = queue.Queue()
        url = app.cfg.get("ollama_url", "http://localhost:11434")
        model = recommended_local_model()

        def say(t):
            q.put(("msg", t))

        def work():
            try:
                if ollama_models(url, 1.5) is None:
                    if not IS_WIN:
                        q.put(("err", "Install Ollama from ollama.com, then press the button again.")); return
                    exe = os.path.join(tempfile.gettempdir(), "OllamaSetup.exe")
                    say(tr("Downloading the free local assistant…"))
                    req = urllib.request.Request("https://ollama.com/download/OllamaSetup.exe", headers={"User-Agent": UA})
                    with urllib.request.urlopen(req, timeout=60) as r, open(exe, "wb") as fo:
                        total = int(r.headers.get("content-length") or 0); done = 0
                        while True:
                            b = r.read(1 << 16)
                            if not b:
                                break
                            fo.write(b); done += len(b)
                            if total:
                                q.put(("pct", done * 100.0 / total))
                    say(tr("Installing…"))
                    subprocess.run([exe, "/VERYSILENT", "/NORESTART", "/SUPPRESSMSGBOXES"], timeout=600, creationflags=subprocess.CREATE_NO_WINDOW)
                    for _ in range(60):
                        if ollama_models(url, 1.5) is not None:
                            break
                        lp = os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Ollama", "ollama app.exe")
                        if os.path.exists(lp):
                            subprocess.Popen([lp], creationflags=subprocess.CREATE_NO_WINDOW)
                        time.sleep(2)
                if model not in (ollama_models(url, 2) or []):
                    say(tr("Downloading the model (one time)…"))
                    ok = ollama_pull(url, model, lambda st, d, t: q.put(("pct", d * 100.0 / t)) if t else None, threading.Event())
                    if not ok:
                        q.put(("err", "Download stopped.")); return
                app.cfg["ollama_model"] = model
                app.cfg["ai_provider"] = "auto"
                app.ai.refresh_probe(force=True)
                q.put(("done", None))
            except Exception as e:
                q.put(("err", str(e)))

        def pump():
            try:
                while True:
                    k, v = q.get_nowait()
                    if k == "msg":
                        app.set_status(v); app.toast(v, "info", 2500)
                    elif k == "pct":
                        app.set_status("%s %d%%" % (tr("Setting up the assistant"), v))
                    elif k == "done":
                        self._setting_up = False
                        app.toast(tr("The assistant is ready - free, private, works offline"), "success", 4000)
                        self.refresh_ready(); return
                    elif k == "err":
                        self._setting_up = False
                        app.toast(tr("Setup failed: ") + v, "error", 6000); return
            except queue.Empty:
                pass
            app.root.after(300, pump)
        threading.Thread(target=work, daemon=True).start()
        pump()

    def refresh_ready(self):
        ai, cfg = self.app.ai, self.app.cfg
        self.model_chip.configure(text=ai.describe() + "  ▾")
        want = ai.provider() == "free" and not cfg.get("ai_notice_seen")
        if want:
            self.notice.pack(side="top", fill="x", padx=10, pady=(8, 0), before=self.ctx_l)
        else:
            self.notice.pack_forget()
        self.refresh_context()

    def refresh_context(self):
        ed = self.app.cur
        if not ed:
            self.ctx_l.configure(text="No file open")
            return
        n = 0
        t = ed.text
        if t.tag_ranges("sel"):
            n = t.get("sel.first", "sel.last").count("\n") + 1
        self.ctx_l.configure(text=("%s  ·  %d line%s selected" % (ed.title(), n, "" if n == 1 else "s")) if n else "%s  ·  whole file" % ed.title())

    def show_setup(self):
        self.app.open_settings("AI")

    # ---- input placeholder -------------------------------------------------
    def _set_placeholder(self):
        self.inp.delete("1.0", "end")
        self.inp.insert("1.0", "Describe the code to generate…" if self.gen_mode else self.PLACEHOLDER)
        self.inp.configure(fg=T()["muted"])
        self._ph_on = True

    def _focus_in(self, e=None):
        if self._ph_on:
            self.inp.delete("1.0", "end")
            self.inp.configure(fg=T()["fg"])
            self._ph_on = False

    def _focus_out(self, e=None):
        if not self.inp.get("1.0", "end-1c").strip():
            self._set_placeholder()

    def get_input(self):
        return "" if self._ph_on else self.inp.get("1.0", "end-1c").strip()

    def focus_input(self):
        self.inp.focus_set()

    # ---- rendering ----------------------------------------------------------
    def clear(self):
        if self.busy:
            self.stop()
        self.msgs = []
        self.render()

    def render(self, streaming=False):
        t = self.chat
        t.configure(state="normal")
        t.delete("1.0", "end")
        if not self.msgs:
            t.insert("end", K(self.HINT), "hint")
        last = len(self.msgs) - 1
        for i, m in enumerate(self.msgs):
            if i == last and m["role"] == "assistant":
                t.mark_set("last_ai", "end-1c")
                t.mark_gravity("last_ai", "left")
            self._render_msg(m, streaming and i == last)
        t.configure(state="disabled")
        t.see("end")

    def _render_msg(self, m, streaming):
        t = self.chat
        if m["role"] == "user":
            t.insert("end", tr("You") + "\n", "who_user")
            for ln in m["content"].split("\n"):
                if _NEED_BIDI[0] and _has_rtl(ln):
                    self._rtl_line(ln, "user")
                else:
                    t.insert("end", ln + "\n", "user")
            t.insert("end", "\n")
        else:
            t.insert("end", tr("Assistant") + "\n", "who_ai")
            if not m["content"] and streaming:
                t.insert("end", "thinking…\n", "hint")
            self._md(m["content"], m, final=not streaming)
            t.insert("end", "\n")

    def _stream_render(self):
        """While the answer streams in, only the last message is redrawn (keeps long chats fast)."""
        t = self.chat
        try:
            at_bottom = t.yview()[1] > 0.97
            t.configure(state="normal")
            t.delete("last_ai", "end")
            self._render_msg(self.msgs[-1], True)
            t.configure(state="disabled")
            if at_bottom:
                t.see("end")
        except tk.TclError:
            self.render(streaming=True)

    def _md(self, text, msg, final):
        t = self.chat
        for blk in split_blocks(text):
            if blk[0] == "text":
                self._inline(blk[1])
            else:
                _, lang, code, closed = blk
                t.insert("end", code + "\n", "code")
                if final and closed:
                    self._code_buttons(code, msg)

    def _on_chat_resize(self, e):
        """Arabic lines are wrapped by us, so they are laid out again when the panel changes width."""
        if abs(e.width - self._cw) < 24:
            return
        self._cw = e.width
        if self._cjob:
            self.after_cancel(self._cjob)
        self._cjob = self.after(250, self._relayout)

    def _relayout(self):
        self._cjob = None
        if not self.busy and any(_has_rtl(m["content"]) for m in self.msgs):
            self.render()

    def _rtl_line(self, line, tag):
        """Arabic text: wrap first (logical order), then reorder each line for the left-to-right-only Tk and right-align it."""
        t = self.chat
        txt = re.sub(r"^\s{0,3}#{1,6}\s+", "", line)
        txt = re.sub(r"^(\s*)[-*]\s+", lambda m: m.group(1) + "• ", txt).replace("**", "").replace("`", "")
        px = max(160, t.winfo_width() - 60)
        for part in wrap_logical(txt, self.app.ui_font, px):
            t.insert("end", visual(part) + "\n", (tag, "rtl"))

    def _inline(self, s):
        t = self.chat
        s = s.strip("\n")
        if not s:
            return
        for line in s.split("\n"):
            if _NEED_BIDI[0] and _has_rtl(line):
                self._rtl_line(line, "ai")
                continue
            tag = "ai"
            m = re.match(r"^\s{0,3}#{1,6}\s+(.*)$", line)
            if m:
                line, tag = m.group(1), "bold"
            else:
                m = re.match(r"^(\s*)[-*]\s+(.*)$", line)
                if m:
                    line = m.group(1) + "• " + m.group(2)
            for part in re.split(r"(`[^`\n]+`|\*\*[^*\n]+\*\*)", line):
                if len(part) > 2 and part.startswith("`") and part.endswith("`"):
                    t.insert("end", part[1:-1], "icode")
                elif len(part) > 4 and part.startswith("**") and part.endswith("**"):
                    t.insert("end", part[2:-2], "bold")
                else:
                    t.insert("end", part, tag)
            t.insert("end", "\n", "ai")

    def _code_buttons(self, code, msg):
        th, app = T(), self.app
        fr = tk.Frame(self.chat, bg=th["bg"])
        ctx = msg.get("ctx") or {}
        gen = ctx.get("mode") == "generate"
        rep = "Replace selection" if ctx.get("sel") else "Replace file"
        if gen:
            Btn(fr, "Insert at cursor", lambda: app.ai_apply(code, "insert", ctx), kind="primary", role="bg", height=26, padx=10).pack(side="left", padx=(0, 5))
            Btn(fr, "Copy", lambda: self._copy(code), kind="outline", role="bg", height=26, padx=10).pack(side="left")
        else:
            Btn(fr, rep, lambda: app.ai_review(code, ctx), kind="primary", role="bg", height=26, padx=10).pack(side="left", padx=(0, 5))
            Btn(fr, "Insert at cursor", lambda: app.ai_apply(code, "insert", ctx), kind="outline", role="bg", height=26, padx=10).pack(side="left", padx=(0, 5))
            Btn(fr, "Copy", lambda: self._copy(code), kind="outline", role="bg", height=26, padx=10).pack(side="left")
        self.chat.window_create("end", window=fr, padx=6, pady=4)
        self.chat.insert("end", "\n")

    def _copy(self, code):
        self.app.copy_text(code, "Code copied")

    # ---- sending --------------------------------------------------------------
    def build_context(self, include_file, include_out, mode="ask"):
        app, ed = self.app, self.app.cur
        parts, ctx = [], {"ed": ed, "sel": None, "mode": mode}
        scope = "[Scope: the whole file. If you change code, return the complete updated file.]"
        if mode == "generate":
            scope = ("[Scope: write NEW code for the request. Return ONLY the new code in one fenced code block; "
                     "it will be inserted at the cursor. Match the language and style of the file.]")
        if ed:
            t = ed.text
            lang = LANG_LABEL[ed.lang]
            fence = ed.lang if ed.lang != "text" else ""
            sel = ""
            if t.tag_ranges("sel"):
                a, b = t.index("sel.first"), t.index("sel.last")
                sel = t.get(a, b)
                self.mark_n += 1
                na, nb = "ai_a%d" % self.mark_n, "ai_b%d" % self.mark_n
                t.mark_set(na, a)
                t.mark_gravity(na, "left")
                t.mark_set(nb, b)
                t.mark_gravity(nb, "right")
                ctx["sel"] = (na, nb)
                if mode != "generate":
                    scope = "[Scope: ONLY the selected code. Return just the replacement for the selection.]"
            if include_file and not sel:                 # a selection is all the model needs: less to send = faster answer
                code = ed.get_text()
                if len(code) > 12000:
                    code = code[:12000] + "\n... (truncated)"
                parts.append("File: %s (%s)\n```%s\n%s\n```" % (ed.title(), lang, fence, code))
            if sel:
                parts.append("Selected code:\n```%s\n%s\n```" % (fence, sel))
        if include_out:
            out = app.bottom.term.get_all().strip() or app.bottom.output.get_all().strip()
            if out:
                parts.append("Program output / errors:\n```\n%s\n```" % out[-5000:])
        parts.append(scope)
        return "\n\n".join(parts), ctx

    def on_send(self):
        if self.busy:
            self.stop()
            return
        prompt = self.get_input()
        if not prompt:
            return
        self.inp.delete("1.0", "end")
        if self.gen_mode:
            self.gen_mode = False
            ed = self.app.cur
            lang = LANG_LABEL[ed.lang] if ed else "Python"
            self.send("Write %s code for this task: %s" % (lang, prompt), self.t_file.on, self.t_out.on, mode="generate")
        else:
            self.send(prompt, self.t_file.on, self.t_out.on)
        self.inp.focus_set()

    def ask(self, text, include_file=True):
        """Programmatic entry (welcome page, menus)."""
        self.app.show_ai(True)
        self.send(text, include_file and self.app.cur is not None, False)

    def quick(self, kind):
        self.app.show_ai(True)
        if self.busy:
            return
        ed = self.app.cur
        if kind == "generate":
            self.gen_mode = True
            self._set_placeholder()
            self.inp.focus_set()
            self._focus_in()
            self.inp.delete("1.0", "end")
            self.inp.insert("1.0", "")
            return
        if kind == "error_help":
            err = self.app.last_error_text()
            if not err.strip():
                self.app.toast(tr("Nothing to explain yet - run your program first"), "info")
                return
            doc = explain_error(err, self.app.reply_ar())
            self.msgs.append({"role": "user", "content": tr("Explain the last error"), "api": ""})
            self.msgs.append({"role": "assistant", "content": ("**" + tr("Quick diagnosis (works offline)") + "**\n\n" + doc) if doc else
                              tr("I could not recognise this error offline. Press Fix and I will ask the online assistant."),
                              "ctx": {"ed": ed, "sel": None, "mode": "ask"}})
            self.render()
            return
        if not ed:
            self.app.toast("Open a file first", "warn")
            return
        if kind == "convert":
            prompt = ("Convert this code to idiomatic C++17." if ed.lang == "python" else "Convert this code to clean, idiomatic Python 3.")
        else:
            prompt = AI_PROMPTS[kind]
        prefix = ""
        if kind == "fix":
            doc = explain_error(self.app.last_error_text(), self.app.reply_ar())
            if doc:
                prefix = "**" + tr("Quick diagnosis (works offline)") + "**\n\n" + doc + "\n\n---\n\n"
        self.send(prompt, True, kind == "fix", prefix=prefix)

    def send(self, prompt, include_file=True, include_out=False, mode="ask", prefix=""):
        app = self.app
        if self.busy:
            return
        chat = mode == "ask" and not prefix and not include_out and is_small_talk(prompt)
        if chat:                                       # no file attached to a 'hello': fewer tokens, faster answer
            include_file = False
        ctx_text, ctx = self.build_context(include_file, include_out, mode)
        extra = self._mentioned_files(prompt)
        if extra:
            ctx_text = extra + "\n\n" + ctx_text
        self.msgs.append({"role": "user", "content": prompt, "api": prompt + "\n\n" + ctx_text})
        self.msgs.append({"role": "assistant", "content": prefix, "pre": prefix, "raw": "", "ctx": ctx})
        self.busy = True
        self.send_b.set_text("Stop")
        self.render(streaming=True)
        self.rid = app.ai_request(app.ai.system_prompt(), self._api_messages(), on_delta=self.on_delta,
                                  on_done=self.on_done, on_error=self.on_error,
                                  max_tokens=500 if chat else 2400, chat=chat)
        if self.rid is None:
            self.msgs = self.msgs[:-2]
            self.busy = False
            self.send_b.set_text("Send")
            self.render()
            return
        self._tick()

    def _mentioned_files(self, prompt, limit=2, size=8000):
        """Files of the open folder that the question names (e.g. 'utils.py') are attached - only those, never the project."""
        folder = self.app.cfg.get("folder") or ""
        if not folder or not os.path.isdir(folder):
            return ""
        names = set(re.findall(r"[\w\-]+\.(?:py|pyw|c|cc|cpp|cxx|h|hpp|txt|json|md|csv)", prompt or "", re.I))
        cur = self.app.cur.path if self.app.cur else None
        out = []
        for root, dirs, files in os.walk(folder):
            dirs[:] = [d for d in dirs if not d.startswith(".") and d not in ("__pycache__", "node_modules", "venv", ".venv", "build")]
            for f in files:
                if f in names and len(out) < limit:
                    p = os.path.join(root, f)
                    if cur and os.path.abspath(p) == os.path.abspath(cur):
                        continue
                    try:
                        with open(p, "r", encoding="utf-8", errors="replace") as fh:
                            txt = fh.read(size + 1)
                    except OSError:
                        continue
                    out.append("File: %s\n```\n%s\n```" % (os.path.relpath(p, folder), txt[:size] + ("\n... (truncated)" if len(txt) > size else "")))
            if len(out) >= limit:
                break
        return "\n\n".join(out)

    def _api_messages(self):
        hist = [m for m in self.msgs[:-1]][-12:]
        while hist and hist[0]["role"] != "user":
            hist = hist[1:]
        out = []
        for i, m in enumerate(hist):
            is_last = i == len(hist) - 1
            text = m.get("api") if (m["role"] == "user" and is_last) else m["content"]
            if text and not is_last and len(text) > 2000:      # older turns: keep the gist, not every line of code again
                text = text[:1400] + "\n…\n" + text[-500:]
            if text:
                out.append({"role": m["role"], "content": text})
        return out

    def on_delta(self, text):
        m = self.msgs[-1]
        if "raw" not in m:
            m["content"] += text
        else:                                  # some free models think out loud: hide '<think>...</think>' (and never send it back)
            m["raw"] += text
            r = m["raw"]
            if "</think>" in r:
                r = r.split("</think>")[-1].lstrip()
            elif r.lstrip().startswith("<think>"):
                r = ""
            m["content"] = m.get("pre", "") + r
        self.need = True

    def on_done(self):
        self.busy = False
        threading.Thread(target=save_chat, args=([dict(role=m["role"], content=m["content"]) for m in self.msgs],), daemon=True).start()
        self.send_b.set_text("Send")
        self.render()
        self.app.set_status(tr("Assistant") + ": done")

    def on_error(self, msg):
        self.busy = False
        self.send_b.set_text("Send")
        m = self.msgs[-1]
        m["content"] += ("\n\n" if m["content"] else "") + "⚠ " + msg
        if self.app.ai.provider() == "free":
            m["content"] += "\n\n" + tr("The free online service is not answering. Press 'Set up local AI' above: it installs a free assistant on this PC (no account) in one step.")
            self.app.toast(tr("Set up the free local assistant?"), "info", 9000, action=(tr("Set up"), self.enable_local_ai))
        doc = explain_error(self.app.last_error_text(), self.app.reply_ar())
        if doc and doc not in m["content"]:
            m["content"] += "\n\n**" + tr("Meanwhile, from the error text (offline)") + "**\n\n" + doc
        self.render()
        self.app.set_status(tr("Assistant") + ": error")
        self.app.toast(msg, "error", 5000)

    def stop(self):
        self.app.ai_cancel(self.rid)
        self.busy = False
        self.send_b.set_text("Send")
        if self.msgs and self.msgs[-1]["role"] == "assistant":
            self.msgs[-1]["content"] += "\n\n(stopped)"
        self.render()

    def _tick(self):
        if not self.busy:
            return
        if self.need:
            self.need = False
            self._stream_render()
        self.after(70, self._tick)


# ----------------------------------------------------------------------------
#  Home / welcome page
# ----------------------------------------------------------------------------
class CardStrip(tk.Canvas):
    """The start cards on ONE canvas: rounded (follows the Shapes setting), one hue each in colourful mode,
    they float in one after another and lift when you point at them."""
    H = 124

    def __init__(self, master, app, specs, role="bg"):
        super().__init__(master, height=self.H, highlightthickness=0, bd=0)
        self.app, self.specs, self.role = app, specs, role
        n = len(specs)
        self.hv, self.pr, self.intro = [0.0] * n, [0.0] * n, [1.0] * n
        self.hot = -1
        self.bind("<Configure>", lambda e: self.paint())
        self.bind("<Motion>", self._move)
        self.bind("<Leave>", lambda e: self._hot(-1))
        self.bind("<ButtonPress-1>", self._down)
        self.bind("<ButtonRelease-1>", self._up)

    def _box(self, i):
        n, w, gap = len(self.specs), max(self.winfo_width(), 400), 14
        cw = (w - gap * (n - 1)) / n
        return i * (cw + gap), cw

    def _at(self, x, y):
        for i in range(len(self.specs)):
            x0, cw = self._box(i)
            if x0 <= x <= x0 + cw and 4 <= y <= self.H - 4:
                return i
        return -1

    def _ease(self, arr, i, target, ms, name):
        a = arr[i]
        tween((name, id(self), i), ms, lambda p: (arr.__setitem__(i, a + (target - a) * p), self.paint()), ease=ease_out_quint)

    def _hot(self, i):
        if i == self.hot:
            return
        for k in range(len(self.specs)):
            self._ease(self.hv, k, 1.0 if k == i else 0.0, 220, "card-hv")
        self.hot = i
        self.configure(cursor="hand2" if i >= 0 else "arrow")

    def _move(self, e):
        self._hot(self._at(e.x, e.y))

    def _down(self, e):
        i = self._at(e.x, e.y)
        if i >= 0:
            self._ease(self.pr, i, 1.0, 70, "card-pr")

    def _up(self, e):
        i = self._at(e.x, e.y)
        for k in range(len(self.specs)):
            if self.pr[k] > 0:
                self._ease(self.pr, k, 0.0, 240, "card-pr")
        if i >= 0:
            self.app.root.after(60, self.specs[i][3])

    def play_intro(self):
        for i in range(len(self.specs)):
            self.intro[i] = 0.0
            tween(("card-in", id(self), i), 640, lambda p, i=i: (self.intro.__setitem__(i, p), self.paint()), delay=i * 90, ease=ease_out_expo)
        self.paint()

    def paint(self):
        th = T()
        self.delete("all")
        self._imgs = []
        self.configure(bg=th[self.role])
        f_b, f_s = self.app.ui_bold, self.app.ui_font
        for i, (icon, title, hint, fn, hue) in enumerate(self.specs):
            x0, cw = self._box(i)
            a = max(0.0, min(1.0, self.intro[i]))
            if a <= 0.01:
                continue
            a = 1.0 if a > 0.97 else round(a * 5) / 5.0            # 5 fade levels: corner images are reused from the cache
            col = hue if th.get("hues") else th["accent"]
            hv, pr = self.hv[i], self.pr[i]
            y0 = 8 + (1 - a) * 22 - hv * 4 + pr * 2
            y1 = y0 + self.H - 20
            fz = lambda c: mix(th["bg"], c, a)
            fill = fz(mix(th["panel"], th["panel2"], hv * .6))
            g = glass_colors(th, fill, 1.0) if th.get("glass") else None
            aa_round_rect(self, x0, y0, x0 + cw, y1, R(16), fill, line=fz(mix(th["border"], col, hv)), grad=g[0] if g else None,
                          rim=((fz(g[1][0]), fz(g[1][1])) if g else None))
            aa_round_rect(self, x0 + 16, y0 + 16, x0 + 58, y0 + 58, R(12), fz(mix(fill, col, .18 + .1 * hv)))
            draw_icon(self, icon, x0 + 37, y0 + 37, 9, fz(col), 1.7)
            self.create_text(x0 + 16, y0 + 74, text=visual(tr(title)), anchor="w", fill=fz(th["fg"]), font=f_b)
            self.create_text(x0 + 16, y0 + 94, text=visual(K(tr(hint))), anchor="w", fill=fz(th["muted"]), font=f_s)

    retheme = paint


class WelcomePage(tk.Frame):
    W = 760

    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self.canvas = tk.Canvas(self, highlightthickness=0, bd=0)
        self.canvas.pack(fill="both", expand=True)
        self.inner = tk.Frame(self.canvas)
        self.win = self.canvas.create_window(0, 210, window=self.inner, anchor="n", width=self.W)
        self.sw = SmoothWheel(self.canvas, "canvas", bind=False)
        self.canvas.bind("<Configure>", self._layout)
        self.inner.bind("<Configure>", self._sync)
        for wd in (self.canvas, self.inner):
            wd.bind("<MouseWheel>", self._wheel)
            wd.bind("<Button-4>", lambda e: self._scroll(-3))
            wd.bind("<Button-5>", lambda e: self._scroll(3))
        self.retheme()

    def _wheel(self, e):
        return self.sw.on_wheel(e)

    def _scroll(self, n):
        self.sw.add_lines(n)

    def _sync(self, e=None):
        try:
            self.canvas.configure(scrollregion=(0, 0, max(self.canvas.winfo_width(), 1), 210 + self.inner.winfo_reqheight() + 30))
        except tk.TclError:
            pass

    def _layout(self, e=None):
        w = max(self.canvas.winfo_width(), 1)
        self.canvas.coords(self.win, w / 2, 210)
        self._hero(w)
        self._sync()

    def _hero(self, w, a=1.0):
        """Logo + name + tagline, drawn straight on the canvas. `a` (0..1) fades it in during the intro."""
        th, c = T(), self.canvas
        c.delete("hero")
        cx = w / 2
        before = set(c.find_all())
        fam = self.app.ui_font.cget("family")
        if getattr(self, "_hf", (None,))[0] != fam:
            self._hf = (fam, tkfont.Font(family=fam, size=fs(30), weight="bold"), tkfont.Font(family=fam, size=fs(30)), tkfont.Font(family=fam, size=fs(13)))
        _, fb, fr, ft = self._hf
        fz = lambda col: mix(th["bg"], col, a)
        draw_logo(c, cx, 78, 31 + 3 * a, glow=True, fade=a)
        w1, w2, gap = fb.measure("Legend"), fr.measure("Code"), 10
        x0 = cx - (w1 + gap + w2) / 2
        c.create_text(x0, 146, text="Legend", anchor="w", fill=fz(th["fg"]), font=fb)
        c.create_text(x0 + w1 + gap, 146, text="Code", anchor="w", fill=fz(th["accent"]), font=fr)
        c.create_text(cx, 184, text=tr("Code. Build. Create."), fill=fz(th["muted"]), font=ft)
        for i in set(c.find_all()) - before:
            c.addtag_withtag("hero", i)
        c.tag_lower("hero")

    def play_intro(self):
        """Entrance: the hero fades in while the content glides up (instant when animations are off)."""
        def go():
            try:
                w = max(self.canvas.winfo_width(), 1)

                def step(p):
                    self.canvas.coords(self.win, w / 2, 210 + 30 * (1 - p))
                    self._hero(w, p)
                tween(("welcome", id(self)), 700, step, self._layout, ease=ease_out_expo)
                self.cards.play_intro()
            except tk.TclError:
                pass
        self.after_idle(go)

    def retheme(self):
        th = T()
        self.configure(bg=th["bg"])
        self.canvas.configure(bg=th["bg"])
        self.inner.configure(bg=th["bg"])
        self.rebuild()
        self._layout()

    def rebuild(self):
        app, th = self.app, T()
        for w in self.inner.winfo_children():
            w.destroy()
        f, fb = app.ui_font, app.ui_bold
        self.cards = CardStrip(self.inner, app, [
            ("newfile", "New Python File", "Ctrl+N", lambda: app.new_file("python"), HUES["files"]),
            ("newfile", "New C++ File", "Start a C++ program", lambda: app.new_file("cpp", starter=True), HUES["search"]),
            ("open", "Open File", "Ctrl+O", app.open_file, HUES["run"]),
            ("openfolder", "Open Folder", "Ctrl+Shift+O", app.open_folder, HUES["ai"])], "bg")
        self.cards.pack(fill="x", padx=26)
        cols = tk.Frame(self.inner, bg=th["bg"])
        cols.pack(fill="x", padx=26, pady=(28, 0))
        cols.grid_columnconfigure(0, weight=1, uniform="r")
        cols.grid_columnconfigure(1, weight=1, uniform="r")
        self._recent(cols, 0, "Recent projects", app.cfg.get("recent_folders", []), app.open_recent_folder,
                     "Folders you open will appear here.")
        self._recent(cols, 1, "Recent files", app.cfg.get("recent_files", []), app.open_file,
                     "Files you open will appear here.")
        ai = tk.Frame(self.inner, bg=th["panel"], highlightthickness=1, highlightbackground=th["border"])
        ai.pack(fill="x", padx=26, pady=(30, 0))
        ic = tk.Canvas(ai, width=34, height=34, highlightthickness=0, bd=0, bg=th["panel"])
        draw_icon(ic, "ai", 16, 18, 9, th["accent"])
        ic.pack(side="left", padx=(12, 0), pady=10)
        self.ask_var = tk.StringVar()
        e = tk.Entry(ai, textvariable=self.ask_var, font=f)
        style_entry(e, "panel")
        e.configure(highlightthickness=0)
        e.pack(side="left", fill="x", expand=True, ipady=8, padx=8)
        Btn(ai, "Ask the assistant", self._ask, kind="primary", role="panel", height=30, padx=14).pack(side="right", padx=10, pady=8)
        e.bind("<Return>", lambda ev: (self._ask(), "break")[1])
        self.ask_entry = e
        TLabel(self.inner, text=K(tr("Built-in assistant · no account needed        Ctrl+Shift+P  commands        F5  run        Ctrl+L  assistant")),
                 bg=th["bg"], fg=th["dim"], font=f).pack(pady=(14, 16))

    def _ask(self):
        text = self.ask_var.get().strip()
        if not text:
            self.app.show_ai(True)
            self.app.ai_panel.focus_input()
            return
        self.ask_var.set("")
        self.app.ai_panel.ask(text, include_file=False)

    def _card(self, parent, icon, title, hint, fn):
        th, app = T(), self.app
        card = tk.Frame(parent, bg=th["panel"], highlightthickness=1, highlightbackground=th["border"], cursor="hand2")
        ic = tk.Canvas(card, width=40, height=40, highlightthickness=0, bd=0, bg=th["panel"], cursor="hand2")
        round_rect(ic, 2, 2, 38, 38, 10, fill=mix(th["panel"], th["accent"], .16), outline="")
        draw_icon(ic, icon, 20, 20, 8, th["accent"], 1.6)
        ic.pack(anchor="w", padx=14, pady=(14, 8))
        t1 = TLabel(card, text=title, bg=th["panel"], fg=th["fg"], font=app.ui_bold, anchor="w", cursor="hand2")
        t1.pack(fill="x", padx=14)
        t2 = TLabel(card, text=K(hint), bg=th["panel"], fg=th["muted"], font=app.ui_font, anchor="w", cursor="hand2")
        t2.pack(fill="x", padx=14, pady=(2, 14))
        parts = (card, ic, t1, t2)

        def on(v):
            for p in parts:
                try:
                    p.configure(bg=mix(th["panel"], th["accent"], .07) if v else th["panel"])
                except tk.TclError:
                    pass
            card.configure(highlightbackground=th["accent"] if v else th["border"])
        for p in parts:
            p.bind("<Enter>", lambda e: on(True))
            p.bind("<Leave>", lambda e: on(False))
            p.bind("<Button-1>", lambda e: fn())
            p.bind("<MouseWheel>", self._wheel)
        return card

    def _recent(self, parent, col, title, items, fn, empty):
        th, app = T(), self.app
        box = tk.Frame(parent, bg=th["bg"])
        box.grid(row=0, column=col, sticky="nsew", padx=6)
        TLabel(box, text=title, bg=th["bg"], fg=th["fg"], font=app.ui_bold, anchor="w").pack(fill="x", pady=(0, 6))
        items = [p for p in items if os.path.exists(p)][:5]
        if not items:
            TLabel(box, text=empty, bg=th["bg"], fg=th["dim"], font=app.ui_font, anchor="w", justify="left").pack(fill="x")
        for p in items:
            row = tk.Frame(box, bg=th["bg"], cursor="hand2")
            row.pack(fill="x", pady=1)
            a = TLabel(row, text=os.path.basename(p.rstrip("/\\")) or p, bg=th["bg"], fg=th["accent"], font=app.ui_font, anchor="w", cursor="hand2")
            a.pack(side="left")
            b = TLabel(row, text="   " + shorten_path(os.path.dirname(p.rstrip("/\\")), 30), bg=th["bg"], fg=th["dim"], font=app.ui_font, anchor="w", cursor="hand2")
            b.pack(side="left")
            for w in (row, a, b):
                w.bind("<Button-1>", lambda e, p=p: fn(p))
                w.bind("<Enter>", lambda e, a=a: a.configure(fg=th["fg"]))
                w.bind("<Leave>", lambda e, a=a: a.configure(fg=th["accent"]))


# ----------------------------------------------------------------------------
#  Main application
# ----------------------------------------------------------------------------
class App:
    MENUS = ("File", "Edit", "View", "Run", "AI", "Tools", "Help")

    def __init__(self, safe=False, watchdog=None):
        self._t0 = time.perf_counter()
        self.safe = safe
        self._watchdog = watchdog
        self._log_buf = []
        if IS_WIN:
            try:
                import ctypes
                ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("LegendCode.App")
            except Exception:
                pass
            try:
                import ctypes
                ctypes.windll.shcore.SetProcessDpiAwareness(1)
            except Exception:
                pass
        self.root = tk.Tk()
        self.root.withdraw()                        # stay hidden until the window is fully laid out (no half-drawn flash)
        self.root.title(APP)
        try:                                        # window + taskbar icon (embedded PNGs)
            self._icons = [tk.PhotoImage(data=b) for b in LOGO_ICON_B64]
            self.root.iconphoto(True, *self._icons)
        except Exception:
            pass
        self.cfg = load_config()
        if safe:
            if os.path.exists(SESSION_PATH):             # keep the last session safe: it can be restored from Settings > Advanced
                try:
                    shutil.copy(SESSION_PATH, SESSION_PATH + ".prev")
                except OSError:
                    pass
            self.cfg.update(panel_open=False, ai_open=False, animations=False)
        self.ai = AIClient(self.cfg)
        self.ai_q = queue.Queue()
        self.ai_jobs = {}
        self.ai_rid = 0
        self.theme_name = self.cfg["theme"]
        self.theme = make_theme(self.cfg)
        _CUR["theme"] = self.theme
        self.root.geometry(sane_geometry(self.cfg.get("geometry"), self.root.winfo_screenwidth(), self.root.winfo_screenheight()))
        self.root.minsize(980, 560)
        self._make_fonts()
        self.editors = []
        self.cur = None
        self.home_visible = False
        self.popup = None
        self.menu_name = None
        self.runner = Runner()
        self.untitled_count = 0
        self.tmp_map = {}
        self.run_errors = {}
        self.last_run = None
        self.phase = "run"
        self.run_started = False
        self.diags_run, self.diags_syntax, self._diag_keys = [], {}, set()
        self._prob_job = None
        self._poll_job = None
        self._last_save_tick = time.time()
        self._backup_hash = None
        self._run_n = 0
        self.settings_win = None
        os.makedirs(TMP, exist_ok=True)
        self.unbuf_h = os.path.join(TMP, "ide_unbuf.h")
        try:
            with open(self.unbuf_h, "w") as f:
                f.write("#include <stdio.h>\n#if defined(__GNUC__)\nstatic void __attribute__((constructor)) "
                        "ide_unbuffer_stdout(void){ setvbuf(stdout, NULL, _IONBF, 0); }\n#endif\n")
        except Exception:
            pass
        self.root.report_callback_exception = self._on_exc
        self.style = ttk.Style(self.root)
        try:
            self.style.theme_use("clam")
        except tk.TclError:
            pass
        self.anim = Anim(self.root, self.cfg, on_error=self._on_exc)
        ANIM[0] = self.anim
        self._want = {}
        self._instant = False
        self.anim.force_off = bool(safe)
        set_shape(self.cfg)
        set_lang(self.cfg)
        self.toasts = Toasts(self)
        self.themed = []          # widgets with a retheme() method
        self.roles = []           # (widget, bg-role, fg-role-or-None) simple colour roles
        self._build()
        self.apply_theme()
        self.root.protocol("WM_DELETE_WINDOW", self.on_quit)
        if IS_MAC:                                              # Cmd+Q and Cmd+, in the standard Mac places
            try:
                self.root.createcommand("::tk::mac::Quit", self.on_quit)
                self.root.createcommand("::tk::mac::ShowPreferences", lambda: self.open_settings())
            except tk.TclError:
                pass
        self.root.bind_all("<Button-1>", self._global_click, add="+")
        self._fullscreen = False
        self.root.update_idletasks()
        self._show_main()
        if self.cfg.get("fullscreen_start") and not safe:
            self.root.after(120, lambda: self.toggle_fullscreen(True))
        self.root.after(1, self._boot_stage2)                   # the heavy parts run AFTER the window is on screen

    # ---- start-up stages -------------------------------------------------------
    def _show_main(self):
        try:
            self.root.deiconify()
            if self.anim.on and not self.safe:
                self.root.attributes("-alpha", 0.0)
                target = self.window_alpha()
                tween(("main-fade",), 240, lambda p: self.root.attributes("-alpha", target * p), ease=ease_out)
            else:
                self.root.attributes("-alpha", self.window_alpha())
        except tk.TclError:
            pass

    def window_alpha(self):
        return max(0.6, min(1.0, int(self.cfg.get("opacity", 100)) / 100.0)) if (self.cfg.get("glass") and not self.cfg.get("lite")) else 1.0

    def _boot_stage2(self):
        try:
            self._restore_session()
        except Exception:
            self._on_exc(*sys.exc_info())          # never fail to open just because the last session is odd
            try:
                if not self.editors:
                    self.show_home()
            except Exception:
                pass
        self.ai.refresh_probe(force=True)
        self._kick_poll()
        self.root.after(6000, self._maint_tick)
        self.root.after(1500, self._slow_tick)
        self.root.after(300, self._boot_stage3)

    def _boot_stage3(self):
        boot_end()
        if self._watchdog is not None:
            self._watchdog.set()
        ms = (time.perf_counter() - self._t0) * 1000
        self._startup_ms = ms
        self.log("Started in %.0f ms%s" % (ms, " (safe mode)" if self.safe else ""))
        if self.safe:
            self.toast(tr("Started in safe mode: the last start did not finish. Your files are untouched."), "warn", 6000)
        elif not (self.cfg.get("user_name") or "").strip() and not self.cfg.get("name_asked"):
            self._ask_name()
        else:
            self._greet()
        self.root.after(1200, self._offer_shortcut)
        self.root.after(8000, self._update_check)
        demo = os.environ.get("LEGEND_SHOTS")                 # screenshot automation for the download page (off unless set)
        if demo and os.path.isfile(demo):
            self.root.after(2500, lambda: exec(open(demo, encoding="utf-8").read(), {"app": self, "ns": globals()}))

    def _ask_name(self):
        """First launch: 'What's your name?' on a calm card over the window. Saved once; changeable in Settings > General."""
        th, ar = self.theme, self.cfg.get("ui_lang") == "ar"
        try:
            ov = tk.Frame(self.host, bg=th["bg"])
            ov.place(relx=0, rely=0, relwidth=1, relheight=1)
            tk.Misc.tkraise(ov)
        except tk.TclError:
            return
        card = tk.Frame(ov, bg=th.get("panel", th["bg"]), highlightthickness=1, highlightbackground=th.get("border", th["fg"]), padx=36, pady=28)
        card.place(relx=.5, rely=.46, anchor="center")
        fam = self.ui_font.cget("family")
        tk.Label(card, text=visual(tr("Welcome to Legend Code")), font=(fam, fs(20), "bold"), bg=card["bg"], fg=th["fg"]).pack()
        tk.Label(card, text=visual(tr("What's your name?")), font=(fam, fs(12)), bg=card["bg"], fg=th.get("muted", th["fg"])).pack(pady=(6, 14))
        var = tk.StringVar()
        ent = tk.Entry(card, textvariable=var, font=(fam, fs(13)), width=24, justify="center", relief="flat",
                       bg=th.get("input", th["bg"]), fg=th["fg"], insertbackground=th["fg"], highlightthickness=1,
                       highlightcolor=th["accent"], highlightbackground=th.get("border", th["fg"]))
        ent.pack(ipady=6)
        msg = tk.Label(card, text="", font=(fam, fs(10)), bg=card["bg"], fg=ACCENTS["rose"])
        msg.pack(pady=(6, 0))

        def go(e=None):
            name = " ".join(var.get().split())[:40]
            if not name:
                msg.configure(text=visual(tr("Please type your name")))
                return "break"
            self.cfg["user_name"], self.cfg["name_asked"] = name, True
            save_config(self.cfg)
            ov.destroy()
            self._greet()
            return "break"

        def later():
            self.cfg["name_asked"] = True
            ov.destroy()
            self._greet()
        row = tk.Frame(card, bg=card["bg"])
        row.pack(pady=(14, 0))
        tk.Button(row, text=tr("Continue"), command=go, relief="flat", bg=th["accent"], fg="#ffffff", activebackground=th["accent"],
                  font=(fam, fs(11), "bold"), padx=18, pady=4, cursor="hand2").pack(side="right" if ar else "left")
        tk.Button(row, text=tr("Later"), command=later, relief="flat", bg=card["bg"], fg=th.get("muted", th["fg"]), activebackground=card["bg"],
                  font=(fam, fs(11)), padx=12, pady=4, cursor="hand2").pack(side="left" if ar else "right", padx=8)
        ent.bind("<Return>", go)
        ent.focus_set()

    def _greet(self):
        """Apple-style hello: the word writes itself in the middle of the window, holds, then dissolves. Never blocks."""
        if not self.cfg.get("greeting", True):
            return
        name = " ".join((self.cfg.get("user_name") or "").split())[:40]
        if self.cfg.get("ui_lang") == "ar":
            word = "مرحبًا، %s" % name if name else "مرحبًا"
        else:
            word = "hello, %s" % name if name else "hello"
        per = word.isascii()
        th = self.theme
        try:
            host = self.host
            c = tk.Canvas(host, highlightthickness=0, bd=0, bg=th["bg"])
            c.place(relx=0, rely=0, relwidth=1, relheight=1)
            tk.Misc.tkraise(c)                      # Canvas.lift() means 'raise a canvas item', not the widget
        except tk.TclError:
            return
        fam = self.ui_font.cget("family")
        f = tkfont.Font(family=fam, size=fs(64 if len(word) < 9 else 52), weight="normal", slant="italic" if per else "roman")
        cols = [ACCENTS["orange"], ACCENTS["rose"], ACCENTS["violet"], ACCENTS["blue"], ACCENTS["cyan"], ACCENTS["green"]]
        letters = list(word) if per else [word]
        def frame(p):
            if not c.winfo_exists():
                return
            c.delete("all")
            w, h = max(c.winfo_width(), 200), max(c.winfo_height(), 200)
            txt = visual(word)
            total = f.measure(txt)
            x = (w - total) / 2
            n = len(letters)
            for i, ch in enumerate(letters if per else [txt]):
                start, span_ = i / (n + 1.5), 2.5 / (n + 1.5)
                q = max(0.0, min(1.0, (p - start) / span_))
                q = ease_out_expo(q)
                col = mix(th["bg"], cols[i % len(cols)] if per else th["accent"], q)
                c.create_text(x, h / 2 + 18 * (1 - q), text=ch, anchor="w", fill=col, font=f)
                x += f.measure(ch)
        def fade_out():
            def step(p):
                if not c.winfo_exists():
                    return
                for it in c.find_all():
                    pass
                c.configure(bg=th["bg"])
                if p >= 1:
                    c.destroy()
                else:
                    c.move("all", 0, -0.6)
                    for it in c.find_all():
                        try:
                            c.itemconfigure(it, fill=mix(c.itemcget(it, "fill"), th["bg"], .18))
                        except tk.TclError:
                            pass
            tween(("hello-out",), 520, step, lambda: c.winfo_exists() and c.destroy(), ease=ease_in_out)
        tween(("hello",), 1500, frame, lambda: self.root.after(450, fade_out), ease=lambda p: p)
        c.bind("<Button-1>", lambda e: c.destroy())

    # ---- lazily built panels (the window opens first; heavy panels are created when first needed) -------
    def _lz(self, name, factory):
        k = "_L_" + name
        o = self.__dict__.get(k)
        if o is None:
            o = factory()
            self.__dict__[k] = o
            try:
                o.retheme()
            except Exception:
                self._on_exc(*sys.exc_info())
        return o

    def _built(self, name):
        return ("_L_" + name) in self.__dict__

    @property
    def bottom(self):
        return self._lz("bottom", self._make_bottom)

    @property
    def ai_panel(self):
        return self._lz("ai_panel", lambda: AIPanel(self.main, self))

    @property
    def search(self):
        return self._lz("search", self._make_search)

    @property
    def runview(self):
        return self._lz("runview", lambda: RunView(self.sidebar, self))

    @property
    def stdin(self):
        return self.bottom.stdin

    @property
    def stdin_var(self):
        return self.bottom.stdin_var

    def _make_bottom(self):
        b = BottomPanel(self.center, self)
        self.bind_shortcuts(b.stdin)
        for t, tag in self._log_buf:
            b.debug.append(t, tag)
        self._log_buf = []
        tab = self.cfg.get("panel_tab", "Terminal")
        if tab in BottomPanel.TABS:
            b.show_tab(tab)
        self.root.after_idle(self.refresh_problems)
        return b

    def _make_search(self):
        sv = SearchView(self.sidebar, self)
        self.bind_shortcuts(sv.entry)
        return sv

    # ---- fonts ------------------------------------------------------------
    def _make_fonts(self):
        fams = set(tkfont.families())
        ui_fam = next((f for f in ("Segoe UI", "SF Pro Text", "Helvetica Neue", "Ubuntu", "Noto Sans", "DejaVu Sans") if f in fams), "TkDefaultFont")
        for name in ("TkDefaultFont", "TkTextFont", "TkMenuFont"):
            try:
                tkfont.nametofont(name).configure(family=ui_fam, size=fs(10))
            except tk.TclError:
                pass
        self.mono_choices = [f for f in ("Cascadia Code", "Cascadia Mono", "JetBrains Mono", "Fira Code", "Consolas", "SF Mono", "Menlo",
                                         "Source Code Pro", "DejaVu Sans Mono", "Liberation Mono", "Courier New") if f in fams]
        fam = self.cfg.get("font_family") if self.cfg.get("font_family") in fams else (self.mono_choices[0] if self.mono_choices else "TkFixedFont")
        size = int(self.cfg.get("font_size", 13))
        self.font = tkfont.Font(family=fam, size=size)
        self.font_i = tkfont.Font(family=fam, size=size, slant="italic")
        self.ui_font = tkfont.Font(family=ui_fam, size=fs(10))
        self.ui_bold = tkfont.Font(family=ui_fam, size=fs(10), weight="bold")

    def set_font(self, family=None, size=None):
        if family is not None:
            self.cfg["font_family"] = family
            fam = family if family else (self.mono_choices[0] if self.mono_choices else "TkFixedFont")
            self.font.configure(family=fam)
            self.font_i.configure(family=fam)
        if size is not None:
            self.cfg["font_size"] = size
            self.font.configure(size=size)
            self.font_i.configure(size=size)
        for ed in self.editors:
            ed.apply_settings()
        self.ai_panel.retheme()

    # ---- error handling -------------------------------------------------------
    def _on_exc(self, exc, val, tb):
        msg = "".join(traceback.format_exception(exc, val, tb))
        try:
            with open(CRASH_LOG, "a", encoding="utf-8") as f:
                f.write("\n--- %s ---\n%s" % (time.ctime(), msg))
        except Exception:
            pass
        try:
            self.log("Internal error (details in %s)" % CRASH_LOG, "err")
            self.set_status("⚠ Internal error - details saved to " + CRASH_LOG)
        except Exception:
            pass

    # ---- small helpers used everywhere -----------------------------------------
    def toast(self, text, kind="info", ms=2600, action=None):
        try:
            self.toasts.show(text, kind, ms, action)
        except Exception:
            pass

    def log(self, text, tag="out"):
        """Write a line to the Debug Console (buffered until the console exists)."""
        line = "[%s] %s\n" % (time.strftime("%H:%M:%S"), text)
        if self._built("bottom"):
            try:
                self.bottom.debug.append(line, tag)
            except Exception:
                pass
        else:
            self._log_buf = (self._log_buf + [(line, tag)])[-200:]

    def copy_text(self, text, msg="Copied"):
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(text)
            self.toast(msg, "success", 1400)
        except Exception:
            pass

    def reveal_in_os(self, path):
        try:
            if IS_WIN:
                subprocess.Popen(["explorer", "/select,", os.path.normpath(path)] if os.path.isfile(path) else ["explorer", os.path.normpath(path)])
            elif IS_MAC:
                subprocess.Popen(["open", "-R", path] if os.path.isfile(path) else ["open", path])
            else:
                subprocess.Popen(["xdg-open", path if os.path.isdir(path) else os.path.dirname(path)])
        except Exception as e:
            self.toast("Could not open the file manager: %s" % e, "error")

    def close_popup(self):
        if self.popup:
            self.popup.close()
        self.popup = None
        self.menu_name = None

    def _global_click(self, e):
        p = self.popup
        if not p:
            return
        try:
            if e.widget.winfo_toplevel() is p.w or getattr(e.widget, "_menu_trigger", False):
                return
        except Exception:
            pass
        self.close_popup()

    # ---- UI construction ---------------------------------------------------------
    def _reg(self, w, bg, fg=None):
        self.roles.append((w, bg, fg))
        return w

    def _build(self):
        r = self.root
        f, fb = self.ui_font, self.ui_bold
        # --- top bar -----------------------------------------------------------------
        self.topbar = self._reg(tk.Frame(r), "bar")
        self.topbar.pack(side="top", fill="x")
        self.status = self._reg(tk.Frame(r), "bar")
        self.status.pack(side="bottom", fill="x")
        self.body = self._reg(tk.Frame(r), "act")
        self.body.pack(fill="both", expand=True)

        self.logo = tk.Canvas(self.topbar, width=34, height=34, highlightthickness=0, bd=0, cursor="hand2")
        self.logo.pack(side="left", padx=(12, 4), pady=8)
        self.logo.bind("<Button-1>", lambda e: self.show_home())
        Tooltip(self.logo, "Home")
        self.brand = TLabel(self.topbar, text="Legend", font=(self.ui_font.cget("family"), fs(12), "bold"), padx=0, cursor="hand2")
        self.brand.pack(side="left")
        self.brand2 = TLabel(self.topbar, text="Code", font=(self.ui_font.cget("family"), fs(12)), padx=4, cursor="hand2")
        self.brand2.pack(side="left", padx=(0, 10))
        for w in (self.brand, self.brand2):
            w.bind("<Button-1>", lambda e: self.show_home())
        self.menu_chips = {}
        for name in self.MENUS:
            c = Chip(self.topbar, name, None, role="bar", font=f, padx=10, pady=5, fg="fg")
            c.cmd = lambda n=name, c=c: self.open_menu(n, c)
            c.configure(cursor="hand2")
            c._menu_trigger = True
            c.bind("<Enter>", lambda e, n=name, c=c: self._menu_hover(n, c), add="+")
            c.pack(side="left")
            self.menu_chips[name] = c
        self.sep1 = self._reg(tk.Frame(self.topbar, width=1, height=22), "border")
        self.sep1.pack(side="left", padx=10, pady=14)
        self.tb_btns = []
        for icon, tip, cmd in (("newfile", "New file (Ctrl+N)", self.new_file), ("open", "Open file (Ctrl+O)", self.open_file),
                               ("save", "Save (Ctrl+S)", self.save)):
            b = IconButton(self.topbar, icon, cmd, tip, size=32, role="bar", isize=8)
            b.pack(side="left", padx=1, pady=9)
            self.tb_btns.append(b)
        self.sep2 = self._reg(tk.Frame(self.topbar, width=1, height=22), "border")
        self.sep2.pack(side="left", padx=10, pady=14)
        self.run_btn = Btn(self.topbar, "Run", self.run_current, icon="run", kind="success", role="bar", height=32, padx=14, tip="Run (F5 or Ctrl+R)")
        self.run_btn.pack(side="left", pady=9)
        self.stop_btn = Btn(self.topbar, "Stop", self.stop_run, icon="stop", kind="danger", role="bar", height=32, padx=12, tip="Stop (Shift+F5 or Ctrl+.)")
        self.stop_btn.pack(side="left", padx=(6, 0), pady=9)
        self.stop_btn.set_enabled(False)
        self.build_btn = Btn(self.topbar, "Build", lambda: self.run_current(build_only=True), icon="build", kind="outline", role="bar",
                             height=32, padx=12, tip="Build / check only (F7)")
        self.build_btn.pack(side="left", padx=(6, 0), pady=9)
        # right side first, so it keeps its room when the window is narrow
        self.ai_btn = Btn(self.topbar, "Ask AI", self.toggle_ai, icon="ai", kind="ai", role="bar", height=32, padx=12, tip="Assistant (Ctrl+L)")
        self.ai_btn.pack(side="right", padx=(6, 12), pady=9)
        self.gear_btn = IconButton(self.topbar, "gear", lambda: self.open_settings(), "Settings (Ctrl+,)", size=32, role="bar", isize=8)
        self.gear_btn.pack(side="right", pady=9)
        self.pill = TLabel(self.topbar, text=K("Search commands…        Ctrl+Shift+P"), font=f, cursor="hand2", pady=6, bd=0,
                             highlightthickness=1)
        self.pill.pack(side="left", fill="x", expand=True, padx=16, pady=9)
        self.pill.bind("<Button-1>", lambda e: self.palette())
        self.themed += [self.run_btn, self.stop_btn, self.build_btn, self.ai_btn, self.gear_btn] + self.tb_btns + list(self.menu_chips.values())

        # --- activity bar ----------------------------------------------------------------
        self.act = self._reg(tk.Frame(self.body, width=48), "act")
        self.act.pack(side="left", fill="y")
        self.act.pack_propagate(False)
        self.act_btns = {}
        for key, icon, tip, cmd in (("explorer", "files", "Explorer (Ctrl+Shift+E)", lambda: self.activity("explorer")),
                                    ("search", "search", "Search (Ctrl+Shift+F)", lambda: self.activity("search")),
                                    ("run", "run", "Run & Build", lambda: self.activity("run"))):
            b = IconButton(self.act, icon, cmd, tip, size=48, role="act", isize=10, side="right", mark=True, hue=HUES.get({"files": "files", "search": "search", "run": "run"}[icon]))
            b.pack(side="top")
            self.act_btns[key] = b
        self.act_ai = IconButton(self.act, "ai", self.toggle_ai, "Assistant (Ctrl+L)", size=48, role="act", isize=10, side="right", mark=True, hue=HUES["ai"])
        self.act_ai.pack(side="top")
        self.act_set = IconButton(self.act, "gear", lambda: self.open_settings(), "Settings", size=48, role="act", isize=10, side="right", hue=HUES["gear"])
        self.act_set.pack(side="bottom")
        self.act_home = IconButton(self.act, "home", self.show_home, "Home", size=48, role="act", isize=10, side="right", hue=HUES["home"])
        self.act_home.pack(side="bottom")
        self.themed += list(self.act_btns.values()) + [self.act_ai, self.act_set, self.act_home]

        # --- main layout ---------------------------------------------------------------------
        self.main = tk.PanedWindow(self.body, orient="horizontal", sashwidth=4, bd=0, sashrelief="flat", opaqueresize=True)
        self.main.pack(side="left", fill="both", expand=True)
        self.sidebar = tk.Frame(self.main)
        self.explorer = Explorer(self.sidebar, self)
        self.view = None
        self._cv = None
        self.center = tk.PanedWindow(self.main, orient="vertical", sashwidth=4, bd=0, sashrelief="flat", opaqueresize=True)
        self.main.add(self.center, stretch="always", minsize=420)
        self.top = tk.Frame(self.center)
        self.tabbar = TabStrip(self.top, self)
        self.tabbar.pack(side="top", fill="x")
        self.findbar = FindBar(self.top, self)
        self.host = tk.Frame(self.top)
        self.host.pack(fill="both", expand=True)
        self.welcome = WelcomePage(self.host, self)
        self.center.add(self.top, stretch="always", minsize=170)

        # --- status bar --------------------------------------------------------------------------
        self.st_state = Chip(self.status, "●  Ready", None, role="bar", font=fb, padx=12, pady=4, fg="green")
        self.st_state.pack(side="left")
        self.st_prob = Chip(self.status, "✖ 0   ▲ 0", lambda: self.show_panel(True, "Problems"), role="bar", font=f, padx=10, pady=4, tip="Problems")
        self.st_prob.pack(side="left")
        self.st_msg = TLabel(self.status, text="", anchor="w", font=f, padx=10)
        self.st_msg.pack(side="left", fill="x", expand=True)
        self.st_ai = Chip(self.status, "", lambda: self.open_settings("AI"), role="bar", font=f, padx=10, pady=4, tip="AI provider")
        self.st_ai.pack(side="right")
        self.st_tool = Chip(self.status, "", lambda: self.open_settings("C/C++"), role="bar", font=f, padx=10, pady=4, tip="Compilers found on this PC")
        self.st_tool.pack(side="right")
        self.st_lang = Chip(self.status, "Python", None, role="bar", font=f, padx=10, pady=4, tip="Language mode")
        self.st_lang.cmd = self._lang_menu
        self.st_lang._menu_trigger = True
        self.st_lang.configure(cursor="hand2")
        self.st_lang.pack(side="right")
        self.st_enc = Chip(self.status, "UTF-8", None, role="bar", font=f, padx=8, pady=4)
        self.st_enc.pack(side="right")
        self.st_spaces = Chip(self.status, "Spaces: 4", lambda: self.open_settings("Editor"), role="bar", font=f, padx=8, pady=4, tip="Indentation")
        self.st_spaces.pack(side="right")
        self.st_pos = Chip(self.status, "", None, role="bar", font=f, padx=10, pady=4)
        self.st_pos.pack(side="right")
        self.st_syn = Chip(self.status, "", None, role="bar", font=f, padx=8, pady=4)
        self.st_syn.pack(side="right")
        self.themed += [self.st_state, self.st_prob, self.st_ai, self.st_tool, self.st_lang, self.st_enc, self.st_spaces, self.st_pos, self.st_syn]

        self.bind_shortcuts(self.root)

    # ---- theme -------------------------------------------------------------------------------
    def apply_theme(self, light=False):
        th = self.theme
        _CUR["theme"] = th
        self.root.configure(bg=th["act"])
        st = self.style
        for orient, side in (("Vertical", "ns"), ("Horizontal", "ew")):
            name = "Legend.%s.TScrollbar" % orient
            st.configure(name, background=mix(th["panel2"], th["fg"], .12), troughcolor=th["bg"], bordercolor=th["bg"],
                         lightcolor=mix(th["panel2"], th["fg"], .12), darkcolor=mix(th["panel2"], th["fg"], .12),
                         arrowcolor=th["bg"], gripcount=0, relief="flat", borderwidth=0, width=11)
            st.map(name, background=[("pressed", th["accent"]), ("active", mix(th["panel2"], th["fg"], .28))])
            try:
                st.layout(name, [("%s.Scrollbar.trough" % orient, {"sticky": side, "children": [
                    ("%s.Scrollbar.thumb" % orient, {"expand": "1", "sticky": "nswe"})]})])
            except tk.TclError:
                pass
        for name, bg in (("Legend.Treeview", th["side"]), ("Legend.Panel.Treeview", th["panel"])):
            st.configure(name, background=bg, fieldbackground=bg, foreground=th["fg"], borderwidth=0, rowheight=26, relief="flat",
                         font=self.ui_font)
            st.map(name, background=[("selected", mix(bg, th["accent"], .22))], foreground=[("selected", th["fg"])])
            try:
                st.layout(name, [("Treeview.treearea", {"sticky": "nswe"})])
                st.layout(name + ".Item", [("Treeitem.padding", {"sticky": "nswe", "children": [
                    ("Treeitem.image", {"side": "left", "sticky": ""}), ("Treeitem.text", {"side": "left", "sticky": ""})]})])
            except tk.TclError:
                pass
        for w, bg, fg in self.roles:
            try:
                w.configure(bg=th[bg])
                if fg:
                    w.configure(fg=th[fg])
            except tk.TclError:
                pass
        self.main.configure(bg=th["act"])
        self.center.configure(bg=th["act"])
        self.sidebar.configure(bg=th["side"])
        self.top.configure(bg=th["bg"])
        self.host.configure(bg=th["bg"])
        self.logo.configure(bg=th["bar"])
        self.logo.delete("all")
        draw_logo(self.logo, 17, 17, 13)
        self.brand.configure(bg=th["bar"], fg=th["fg"])
        self.brand2.configure(bg=th["bar"], fg=th["accent"])
        self.pill.configure(bg=th["panel2"], fg=th["muted"], highlightbackground=th["border"], highlightcolor=th["border"])
        self.st_msg.configure(bg=th["bar"], fg=th["muted"])
        lazy = [self.__dict__[k] for k in ("_L_search", "_L_runview", "_L_ai_panel", "_L_bottom") if k in self.__dict__]
        for w in list(self.themed) + list(self.editors) + [self.explorer, self.findbar, self.tabbar, self.welcome] + lazy:
            if light and w in (self.explorer, self.welcome):
                continue                      # heavy to rebuild: only on the final frame of a cross-fade
            try:
                w.retheme() if hasattr(w, "retheme") else w.apply_theme()
            except Exception:
                self._on_exc(*sys.exc_info())
        self._paint_activity()
        self.update_status()

    def restyle(self, animate=True):
        """Apply a changed theme / accent / colourful / glass / shape setting. The window dips its opacity, swaps the
        colours once and comes back - one cheap, smooth cross-fade instead of re-colouring every widget on every frame."""
        set_shape(self.cfg)
        new = make_theme(self.cfg)
        self.theme_name = self.cfg["theme"]
        target = self.window_alpha()

        def swap():
            self.theme = new
            _CUR["theme"] = new
            self.apply_theme()

        def alpha(v):
            try:
                self.root.attributes("-alpha", max(0.0, min(1.0, v)))
            except tk.TclError:
                pass
        if not (animate and self.anim.on):
            swap()
            alpha(target)
            return
        low = target * 0.55
        tween(("restyle",), 150, lambda p: alpha(target + (low - target) * p), lambda: (swap(), tween(("restyle",), 260, lambda p: alpha(low + (target - low) * p), ease=ease_out)), ease=ease_in)

    def set_theme(self, name):
        name = THEME_ALIAS.get(name, name)
        if name not in THEMES:
            return
        self.cfg["theme"] = name
        self.restyle()
        save_config(self.cfg)
        self.toast(tr("Theme") + ": " + name, "info", 1500)

    def next_theme(self):
        i = THEME_ORDER.index(self.theme_name) if self.theme_name in THEME_ORDER else 0
        self.set_theme(THEME_ORDER[(i + 1) % len(THEME_ORDER)])

    def zoom(self, d):
        size = int(self.font.cget("size"))
        size = int(DEFAULTS["font_size"]) if d == 0 else max(7, min(40, size + d))
        self.set_font(size=size)

    # ---- menus ---------------------------------------------------------------------------------
    def _menu_hover(self, name, chip):
        if self.popup and self.menu_name and self.menu_name != name:
            self.open_menu(name, chip)

    def open_menu(self, name, chip):
        if self.popup and self.menu_name == name:
            self.close_popup()
            return
        items = self.menu_items(name)

        def unpin(chip=chip):
            try:
                chip.pinned = False
                chip.retheme()
            except tk.TclError:
                pass
        chip.pinned = True
        chip.retheme()
        PopupMenu(self, items, chip.winfo_rootx(), chip.winfo_rooty() + chip.winfo_height() + 4, on_close=unpin)
        self.menu_name = name

    def _ed(self, fn):
        if self.cur and not self.home_visible:
            return fn(self.cur)

    def _xform(self, fn):
        """Apply a text tool to the selection (or the whole file) as ONE undo step."""
        ed = self.cur
        if not ed or self.home_visible:
            self.toast("Open a file first", "warn")
            return
        t = ed.text
        a, b = ("sel.first", "sel.last") if t.tag_ranges("sel") else ("1.0", "end-1c")
        a, b = t.index(a), t.index(b)
        old = t.get(a, b)
        try:
            new = fn(old)
        except Exception as e:
            self.toast(tr("Could not do that") + ": " + str(e)[:80], "error", 3500)
            return
        if new == old:
            self.toast(tr("Nothing to change"), "info", 1800)
            return
        t.edit_separator()
        t.delete(a, b)
        t.insert(a, new)
        t.edit_separator()
        try:
            ed.on_modified() if hasattr(ed, "on_modified") else None
        except Exception:
            pass

    def _stats(self):
        ed = self.cur
        if not ed or self.home_visible:
            return
        txt = ed.get_text()
        self.toast("%s: %d   %s: %d   %s: %d" % (tr("Lines"), txt.count("\n") + 1, tr("Words"), len(txt.split()), tr("Characters"), len(txt)), "info", 5000)

    def _reveal_file(self):
        p = self.cur.path if self.cur else None
        if not p:
            self.toast(tr("Save the file first"), "warn")
            return
        try:
            if sys.platform == "win32":
                subprocess.Popen(["explorer", "/select,", os.path.normpath(p)])
            elif IS_MAC:
                subprocess.Popen(["open", "-R", p])
            else:
                subprocess.Popen(["xdg-open", os.path.dirname(p)])
        except Exception as e:
            self.toast(str(e)[:80], "error")

    def _tmpl_menu(self):
        x, y = self.root.winfo_pointerx(), self.root.winfo_pointery()
        PopupMenu(self, [(n, "", lambda n=n: self.new_from_template(n)) for n in TEMPLATES], x, y)

    def _recent_menu(self):
        x, y = self.root.winfo_pointerx(), self.root.winfo_pointery()
        items = [(shorten_path(p, 50), "", lambda p=p: self.open_file(p)) for p in self.cfg.get("recent_files", []) if os.path.exists(p)]
        items += [None] if items else []
        items += [(shorten_path(p, 50) + "   (folder)", "", lambda p=p: self.open_recent_folder(p)) for p in self.cfg.get("recent_folders", []) if os.path.isdir(p)]
        PopupMenu(self, items or [("Nothing opened yet", "", None)], x, y)

    def _theme_menu(self):
        x, y = self.root.winfo_pointerx(), self.root.winfo_pointery()
        PopupMenu(self, [(("✓  " if n == self.theme_name else "     ") + n, "", lambda n=n: self.set_theme(n)) for n in THEME_ORDER], x, y)

    MENU_ICON = {"New Python File": "newfile", "New C++ File": "newfile", "New C File": "newfile", "Open File…": "open", "Open Folder…": "openfolder",
                 "Open Recent…": "folder", "Save": "save", "Save As…": "save", "Save All": "save", "Close Tab": "close", "Exit": "close",
                 "Find…": "search", "Replace…": "search", "Go to Line…": "terminal", "Format Document": "files", "Run": "run",
                 "Run without debugging": "run", "Build only": "build", "Stop": "stop", "Show Terminal": "terminal", "Show Problems": "warn",
                 "Compiler & Python settings…": "gear", "Open Assistant": "ai", "Explain last error": "ai", "Ask AI to write code here…": "ai", "Explain this code": "ai",
                 "Fix errors": "ai", "Improve this code": "ai", "Refactor": "ai", "Generate code…": "ai", "Add comments": "ai",
                 "Write tests": "ai", "Stop AI": "stop", "AI settings…": "gear", "Toggle Sidebar": "sidebar", "Toggle Bottom Panel": "panel",
                 "Toggle Assistant": "ai", "Full Screen": "panel", "Home Page": "home", "Explorer": "files", "Search in Files": "search", "Theme…": "gear",
                 "Command Palette": "terminal", "Keyboard Shortcuts": "terminal", "About Legend Code": "home", "Open crash log": "warn"}
    ICON_HUE = {"newfile": "files", "open": "files", "openfolder": "files", "folder": "files", "save": "files", "files": "files",
                "search": "search", "run": "run", "build": "run", "stop": "gear", "ai": "ai", "gear": "gear", "home": "home", "close": "gear"}

    def menu_items(self, name):
        """Menu rows with a small icon each (coloured per category when 'colourful' is on)."""
        out = []
        for it in self._menu_items_raw(name):
            if it is None or len(it) > 3:
                out.append(it)
                continue
            ic = self.MENU_ICON.get(it[0])
            out.append((it[0], it[1], it[2], ic, HUES.get(self.ICON_HUE.get(ic))) if ic else it)
        return out

    def _menu_items_raw(self, name):
        ed = self._ed
        if name == "File":
            return [("New Python File", "Ctrl+N", lambda: self.new_file("python")),
                    ("New C++ File", "", lambda: self.new_file("cpp", starter=True)),
                    ("New C File", "", lambda: self.new_file("c", starter=True)),
                    ("New from template…", "", self._tmpl_menu), None,
                    ("Open File…", "Ctrl+O", self.open_file), ("Open Folder…", "Ctrl+Shift+O", self.open_folder),
                    ("Open Recent…", "", self._recent_menu), None,
                    ("Save", "Ctrl+S", self.save), ("Save As…", "Ctrl+Shift+S", self.save_as), ("Save All", "", self.save_all), None,
                    ("Close Tab", "Ctrl+W", self.close_current), ("Exit", "", self.on_quit)]
        if name == "Edit":
            return [("Undo", "Ctrl+Z", lambda: ed(lambda e: e.text.event_generate("<<Undo>>"))),
                    ("Redo", "Ctrl+Y", lambda: ed(lambda e: e.redo())), None,
                    ("Cut", "Ctrl+X", lambda: ed(lambda e: e.text.event_generate("<<Cut>>"))),
                    ("Copy", "Ctrl+C", lambda: ed(lambda e: e.text.event_generate("<<Copy>>"))),
                    ("Paste", "Ctrl+V", lambda: ed(lambda e: e.text.event_generate("<<Paste>>"))),
                    ("Select All", "Ctrl+A", lambda: ed(lambda e: e.select_all())), None,
                    ("Find…", "Ctrl+F", lambda: self.findbar.show()), ("Replace…", "Ctrl+H", lambda: self.findbar.show(True)),
                    ("Go to Line…", "Ctrl+G", self.goto_line), None,
                    ("Toggle Comment", "Ctrl+/", lambda: ed(lambda e: e.toggle_comment())),
                    ("Duplicate Line", "Ctrl+D", lambda: ed(lambda e: e.duplicate_line())),
                    ("Format Document", "", self.format_document)]
        if name == "View":
            return [("Full Screen", "F11", self.toggle_fullscreen), None,
                    ("Toggle Sidebar", "Ctrl+B", self.toggle_sidebar), ("Toggle Bottom Panel", "Ctrl+J", self.toggle_panel),
                    ("Toggle Assistant", "Ctrl+L", self.toggle_ai), ("Home Page", "", self.show_home), None,
                    ("Explorer", "Ctrl+Shift+E", lambda: self.activity("explorer", True)),
                    ("Search in Files", "Ctrl+Shift+F", lambda: self.activity("search", True)), None,
                    ("Theme…", "Ctrl+Shift+T", self._theme_menu),
                    ("Word Wrap: " + ("On" if self.cfg.get("word_wrap") else "Off"), "", self.toggle_wrap), None,
                    ("Zoom In", "Ctrl+=", lambda: self.zoom(1)), ("Zoom Out", "Ctrl+-", lambda: self.zoom(-1)),
                    ("Reset Zoom", "Ctrl+0", lambda: self.zoom(0)), None,
                    ("Fold All", "", lambda: ed(lambda e: e.fold_all())), ("Unfold All", "", lambda: ed(lambda e: e.unfold_all()))]
        if name == "Run":
            return [("Run", "F5  ·  Ctrl+R", self.run_current), ("Run without debugging", "Ctrl+F5", self.run_current),
                    ("Build only", "F7", lambda: self.run_current(build_only=True)), ("Stop", "Shift+F5  ·  Ctrl+.", self.stop_run), None,
                    ("Show Terminal", "", lambda: self.show_panel(True, "Terminal")),
                    ("Show Problems", "", lambda: self.show_panel(True, "Problems")), None,
                    ("Compiler & Python settings…", "", lambda: self.open_settings("Python"))]
        if name == "AI":
            q = lambda k: self.ai_panel.quick(k)
            return [("Open Assistant", "Ctrl+L", self.toggle_ai), ("Ask AI to write code here…", "Ctrl+K", self.ai_inline), None,
                    ("Explain this code", "", lambda: q("explain")), ("Fix errors", "", lambda: q("fix")), ("Explain last error", "", lambda: q("error_help")),
                    ("Improve this code", "", lambda: q("improve")), ("Refactor", "", lambda: q("refactor")),
                    ("Generate code…", "", lambda: q("generate")), ("Add comments", "", lambda: q("comment")),
                    ("Write tests", "", lambda: q("tests")), None,
                    ("Stop AI", "", lambda: (self.ai_cancel(), self.ai_panel.busy and self.ai_panel.stop())),
                    ("AI settings…", "", lambda: self.open_settings("AI"))]
        if name == "Tools":
            X = self._xform
            return [("Sort lines", "", lambda: X(lambda t: "\n".join(sorted(t.split("\n"))))),
                    ("Remove duplicate lines", "", lambda: X(lambda t: "\n".join(dict.fromkeys(t.split("\n"))))),
                    ("Trim trailing spaces", "", lambda: X(lambda t: "\n".join(l.rstrip() for l in t.split("\n")))),
                    ("Tabs to spaces", "", lambda: X(lambda t: t.expandtabs(int(self.cfg.get("tab_size", 4))))), None,
                    ("UPPER CASE", "", lambda: X(str.upper)), ("lower case", "", lambda: X(str.lower)),
                    ("Format JSON", "", lambda: X(lambda t: json.dumps(json.loads(t), indent=2, ensure_ascii=False))), None,
                    ("Insert date and time", "", lambda: ed(lambda e: e.text.insert("insert", time.strftime("%Y-%m-%d %H:%M")))),
                    ("File statistics", "", self._stats),
                    ("Open file location", "", self._reveal_file)]
        return [("Keyboard Shortcuts", "", self.show_help), ("Command Palette", "Ctrl+Shift+P", self.palette),
                ("Home Page", "", self.show_home), None,
                ("Open crash log", "", self.open_crash_log), ("About Legend Code", "", self.about)]

    def editor_menu(self, ed, ev):
        t = ed.text
        if not t.tag_ranges("sel"):
            try:
                t.mark_set("insert", "@%d,%d" % (ev.x, ev.y))
            except tk.TclError:
                pass
        has = bool(t.tag_ranges("sel"))
        q = lambda k: self.ai_panel.quick(k)
        items = [("Cut", "Ctrl+X", (lambda: t.event_generate("<<Cut>>")) if has else None),
                 ("Copy", "Ctrl+C", (lambda: t.event_generate("<<Copy>>")) if has else None),
                 ("Paste", "Ctrl+V", lambda: t.event_generate("<<Paste>>")),
                 ("Select All", "Ctrl+A", ed.select_all), None,
                 ("Toggle Comment", "Ctrl+/", ed.toggle_comment), ("Indent", "Tab", lambda: ed.indent_selection(1)),
                 ("Outdent", "Shift+Tab", lambda: ed.indent_selection(-1)), ("Format Document", "", self.format_document), None,
                 ("Fold / Unfold block", "Ctrl+[", lambda: ed.toggle_fold(int(t.index("insert").split(".")[0]))), None,
                 ("Ask AI about " + ("selection" if has else "this file"), "", lambda: q("explain")),
                 ("Fix with AI", "", lambda: q("fix")), ("Improve with AI", "", lambda: q("improve")),
                 ("Ask AI to write here…", "Ctrl+K", self.ai_inline), None,
                 ("Go to Line…", "Ctrl+G", self.goto_line)]
        PopupMenu(self, items, ev.x_root, ev.y_root)

    def tab_menu(self, ed, ev):
        items = [("Close", "Ctrl+W", lambda: self.close_tab(ed)), ("Close Others", "", lambda: self.close_others(ed)),
                 ("Close All", "", self.close_all), None, ("Save", "Ctrl+S", lambda: self.save(ed))]
        if ed.path:
            items += [None, ("Copy path", "", lambda: self.copy_text(ed.path, "Path copied")),
                      ("Reveal in file manager", "", lambda: self.reveal_in_os(ed.path))]
        PopupMenu(self, items, ev.x_root, ev.y_root)

    def _lang_menu(self):
        c = self.st_lang
        PopupMenu(self, [(v, "", lambda k=k: self._ed(lambda e: (e.set_lang(k), self.update_status()))) for k, v in LANG_LABEL.items()],
                  c.winfo_rootx(), c.winfo_rooty() - 130)

    def open_crash_log(self):
        if os.path.exists(CRASH_LOG):
            try:
                self.open_file(CRASH_LOG)
            except Exception:
                pass
        else:
            self.toast("No crash log - everything has been running smoothly.", "success")

    def create_shortcut(self, silent=False):
        """Desktop + Start-menu shortcut with the Legend Code logo (Windows). Windows shows Python's icon for .pyw files,
        a shortcut is the way to get our own icon."""
        if not IS_WIN:
            if not silent:
                self.toast(tr("Shortcuts with a custom icon are for Windows."), "info")
            return False
        try:
            d = app_data_dir()
            os.makedirs(d, exist_ok=True)
            ico = os.path.join(d, "legend-code.ico")
            with open(ico, "wb") as f:
                f.write(ico_bytes())
            q = lambda t: t.replace("'", "''")
            ps = ("$w=New-Object -ComObject WScript.Shell; foreach($f in @('Desktop','Programs')){$p=[Environment]::GetFolderPath($f);"
                  "$s=$w.CreateShortcut($p+'\\Legend Code.lnk');$s.TargetPath='%s';$s.Arguments='\"%s\"';$s.WorkingDirectory='%s';"
                  "$s.IconLocation='%s';$s.Description='Legend Code';$s.Save()}" %
                  (q(gui_python()), q("" if FROZEN else SCRIPT_PATH), q(os.path.dirname(SCRIPT_PATH)), q(sys.executable if FROZEN else ico)))
            r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps], capture_output=True,
                               timeout=25, creationflags=subprocess.CREATE_NO_WINDOW)
            ok = r.returncode == 0
        except Exception:
            ok = False
        if not ok:                                   # fall back to Windows Script Host
            try:
                vbs = os.path.join(app_data_dir(), "shortcut.vbs")
                lines = ['Set w = CreateObject("WScript.Shell")', 'For Each f In Array("Desktop","Programs")',
                         '  Set s = w.CreateShortcut(w.SpecialFolders(f) & "\\Legend Code.lnk")',
                         '  s.TargetPath = "%s"' % gui_python(), '  s.Arguments = Chr(34) & "%s" & Chr(34)' % SCRIPT_PATH,
                         '  s.WorkingDirectory = "%s"' % os.path.dirname(SCRIPT_PATH), '  s.IconLocation = "%s"' % os.path.join(app_data_dir(), "legend-code.ico"),
                         '  s.Save', 'Next']
                with open(vbs, "w", encoding="utf-16") as f:
                    f.write("\r\n".join(lines))
                ok = subprocess.run(["cscript", "//nologo", vbs], capture_output=True, timeout=20, creationflags=subprocess.CREATE_NO_WINDOW).returncode == 0
            except Exception:
                ok = False
        if not silent:
            self.toast(tr("Shortcut created on your Desktop") if ok else tr("Could not create the shortcut"), "success" if ok else "error")
        return ok

    def _offer_shortcut(self):
        if not IS_WIN or self.cfg.get("shortcut_offered") or self.safe:
            return
        self.cfg["shortcut_offered"] = True
        self.toast(tr("Add the Legend Code icon to your Desktop?"), "info", 9000, action=(tr("Add"), self.create_shortcut))

    def reply_ar(self):
        r = self.cfg.get("ai_reply", "Arabic")
        return r == "Arabic" or (r == "Same as me" and self.cfg.get("ui_lang") == "ar")

    def last_error_text(self):
        """Text of the last build / run, for the assistant's error help."""
        if not self._built("bottom"):
            return ""
        out, term = self.bottom.output.get_all().strip(), self.bottom.term.get_all().strip()
        txt = out if (self.phase == "build" and not self.run_started and out) else (term or out)
        return txt[-4000:]

    def assistant_error_help(self):
        self.show_ai(True)
        self.ai_panel.quick("error_help")

    def toggle_fullscreen(self, force=None):
        try:
            want = (not bool(self.root.attributes("-fullscreen"))) if force is None else bool(force)
            self.root.attributes("-fullscreen", want)
        except tk.TclError:
            return
        self._fullscreen = want
        self.cfg["fullscreen"] = want
        if want:
            self.toast(tr("Full screen - press F11 or Esc to leave"), "info", 2200)

    def apply_chrome(self):
        """Show / hide the status bar and the activity bar."""
        try:
            if self.cfg.get("show_status", True):
                if not self.status.winfo_ismapped():
                    self.status.pack(side="bottom", fill="x", before=self.body)
            else:
                self.status.pack_forget()
            if self.cfg.get("show_activity", True):
                if not self.act.winfo_ismapped():
                    self.act.pack(side="left", fill="y", before=self.main)
            else:
                self.act.pack_forget()
        except tk.TclError:
            pass

    def restart(self):
        """Start a fresh copy of the app (used after a language change) and close this one."""
        try:
            save_config(self.cfg)
            argv = [sys.executable] if FROZEN else [gui_python(), SCRIPT_PATH]
            subprocess.Popen(argv, cwd=os.path.dirname(SCRIPT_PATH),
                             creationflags=(subprocess.CREATE_NO_WINDOW if IS_WIN else 0))
        except Exception as e:
            self.toast("Could not restart: %s" % e, "error")
            return
        self.on_quit()

    def reset_layout(self):
        self.cfg.update(sidebar_w=260, ai_w=410, panel_h=220)
        if self.panel_visible():
            self.show_panel(False)
        if self.ai_visible():
            self.show_ai(False)
        self.show_sidebar(True)
        self.toast(tr("Panels reset"), "success", 1800)

    def recover_unsaved(self):
        prev = SESSION_PATH + ".prev"
        n = self._recover_backup(prev if os.path.exists(prev) else None) if (os.path.exists(prev) or os.path.exists(SESSION_PATH)) else 0
        self.toast((tr("Recovered %d unsaved file(s)") % n) if n else tr("No unsaved work to recover"), "success" if n else "info")

    def about(self):
        messagebox.showinfo(APP, "%s v%s\nCode. Build. Create.\n\nA fast, friendly IDE for Python and C/C++.\nBuilt-in AI - no account needed." % (APP, VERSION))

    # ---- shortcuts -----------------------------------------------------------------------------------
    _VK_SYM = {186: "semicolon", 187: "equal", 188: "comma", 189: "minus", 190: "period", 191: "slash", 219: "bracketleft", 221: "bracketright", 192: "grave"}

    _CTRL_VIRT = {"v": "<<Paste>>", "c": "<<Copy>>", "x": "<<Cut>>", "z": "<<Undo>>", "y": "<<Redo>>", "a": "<<SelectAll>>"}

    def _ctrl_hook(self, w):
        """Widget-level hook (runs before the widget's own <KeyPress> handler, which would otherwise swallow the key)."""
        if sys.platform == "win32":
            try:
                w.bind("<Control-KeyPress>", self._ctrl_any_layout, add="+")
            except tk.TclError:
                pass

    def _ctrl_any_layout(self, e):
        """On Windows with a non-Latin layout (Arabic...) Tk reports Ctrl+V as 'Arabic_...' so no shortcut fires.
        The key code is the physical key: map it back to the Latin key and call that shortcut directly."""
        kc, ks = getattr(e, "keycode", 0), e.keysym or ""
        if e.state & 0x20000:                      # AltGr / Alt held: a character, not a shortcut
            return None
        shift = bool(e.state & 1)
        if 65 <= kc <= 90:
            want = chr(kc) if shift else chr(kc + 32)
        elif 48 <= kc <= 57:
            want = chr(kc)
        else:
            want = self._VK_SYM.get(kc)
        if not want or ks == want or ks.lower() == want.lower() or (len(ks) == 1 and ks.isascii() and ks.isalnum()):
            return None
        w = e.widget
        try:
            fn = getattr(w, "_ctrl_fns", {}).get(want)
            if fn is not None:
                fn(e)
                return "break"
            virt = self._CTRL_VIRT.get(want.lower()) if not shift or want.lower() == "z" else None
            if virt and isinstance(w, (tk.Text, tk.Entry)):
                w.event_generate("<<Redo>>" if (want == "Z") else virt)
                return "break"
            fn = getattr(self, "_app_ctrl", {}).get(want)
            if fn is not None:
                fn()
                return "break"
        except (tk.TclError, AttributeError):
            return None
        return "break"

    def bind_shortcuts(self, w):
        if sys.platform == "win32" and not getattr(self, "_ctrl_any_bound", False):
            self._ctrl_any_bound = True
            for cls in ("Text", "Entry", "TEntry"):
                try:
                    self.root.bind_class(cls, "<Control-KeyPress>", self._ctrl_any_layout, add="+")
                except tk.TclError:
                    pass
            try:
                self.root.bind_all("<Control-KeyPress>", self._ctrl_any_layout, add="+")
            except tk.TclError:
                pass
        mods = ["Control"] + (["Command"] if IS_MAC else [])
        table = [("o", self.open_file), ("s", self.save), ("n", self.new_file), ("w", self.close_current),
                 ("f", lambda: self.findbar.show()), ("h", lambda: self.findbar.show(True)), ("g", self.goto_line),
                 ("b", self.toggle_sidebar), ("j", self.toggle_panel), ("e", lambda: self.activity("explorer", True)),
                 ("E", lambda: self.activity("explorer", True)), ("F", lambda: self.activity("search", True)),
                 ("O", self.open_folder), ("S", self.save_as), ("P", self.palette), ("T", self._theme_menu_center),
                 ("equal", lambda: self.zoom(1)), ("plus", lambda: self.zoom(1)), ("minus", lambda: self.zoom(-1)),
                 ("0", lambda: self.zoom(0)), ("comma", lambda: self.open_settings()), ("r", self.run_current), ("period", self.stop_run), ("l", self.toggle_ai), ("k", self.ai_inline)]
        self._app_ctrl = {k: fn for k, fn in table}
        for mod in mods:
            for key, fn in table:
                seq = "<%s-%s>" % (mod, key if len(key) > 1 or key.islower() or key.isdigit() else "Shift-" + key)
                try:
                    w.bind(seq, lambda e, fn=fn: (fn(), "break")[1])
                except tk.TclError:
                    pass
        for seq, fn in (("<F5>", self.run_current), ("<Control-F5>", self.run_current), ("<F7>", lambda: self.run_current(build_only=True)),
                        ("<Shift-F5>", self.stop_run), ("<Control-Tab>", lambda: self.cycle_tab(1)),
                        ("<Control-Shift-Tab>", lambda: self.cycle_tab(-1))):
            try:
                w.bind(seq, lambda e, fn=fn: (fn(), "break")[1])
            except tk.TclError:
                pass
        w.bind("<Escape>", lambda e: "break" if self._esc() else None, add="+")
        try:
            w.bind("<F11>", lambda e: (self.toggle_fullscreen(), "break")[1])
        except tk.TclError:
            pass

    def _esc(self):
        if self.popup:
            self.close_popup()
            return True
        if getattr(self, "_fullscreen", False):
            self.toggle_fullscreen(False)
            return True
        return False

    def _theme_menu_center(self):
        self._theme_menu()

    # ---- layout toggles ---------------------------------------------------------------------------------
    def _paint_activity(self):
        for k, b in self.act_btns.items():
            b.set_active(self.sidebar_visible() and self.view == k)
        self.act_ai.set_active(self.ai_visible())
        self.act_home.set_active(self.home_visible)

    def sidebar_visible(self):
        return self._want.get("sidebar", str(self.sidebar) in self.main.panes())

    def ai_visible(self):
        return self._want.get("ai", False)

    def panel_visible(self):
        return self._want.get("bottom", False)

    def set_pane(self, name, paned, w, visible, size, minsize, opt, before=None):
        """Open / close a docked panel with a short slide (instant while restoring the session or with animations off)."""
        key = ("pane", name)
        self._want[name] = visible
        shown = str(w) in paned.panes()
        cur = (w.winfo_width() if opt == "width" else w.winfo_height()) if shown else 1
        if visible:
            if not shown:
                kw = {opt: 1, "minsize": 0, "stretch": "never"}
                if before is not None:
                    kw["before"] = before
                paned.add(w, **kw)
                cur = 1
            else:
                paned.paneconfigure(w, minsize=0)

            def step(p):
                paned.paneconfigure(w, **{opt: max(1, int(cur + (size - cur) * p))})

            def done():
                paned.paneconfigure(w, minsize=minsize, **{opt: size})
            tween(key, 0 if self._instant else 300, step, done, ease_out_expo)
        elif shown:
            paned.paneconfigure(w, minsize=0)

            def step(p):
                paned.paneconfigure(w, **{opt: max(1, int(cur + (1 - cur) * p))})

            def done():
                try:
                    paned.forget(w)
                except tk.TclError:
                    pass
            tween(key, 0 if self._instant else 220, step, done, ease_in_out)

    def activity(self, key, force_open=False):
        if self.sidebar_visible() and self.view == key and not force_open:
            self.show_sidebar(False)
            return
        self.show_view(key)
        self.show_sidebar(True)
        if key == "search":
            self.search.focus_entry()
        elif key == "run":
            self.runview.refresh()

    def show_view(self, key):
        if self._cv is not None:
            self._cv.pack_forget()
        w = {"explorer": lambda: self.explorer, "search": lambda: self.search, "run": lambda: self.runview}.get(key, lambda: self.explorer)()
        w.pack(fill="both", expand=True)
        self._cv = w
        self.view = key
        self.cfg["sidebar_view"] = key
        self._paint_activity()

    def show_sidebar(self, show):
        if show != self.sidebar_visible():
            if not show:
                self._save_layout()
            self.set_pane("sidebar", self.main, self.sidebar, show, int(self.cfg.get("sidebar_w", 260)), 190, "width", before=self.center)
        self.cfg["sidebar_open"] = show
        self._paint_activity()

    def toggle_sidebar(self):
        self.show_sidebar(not self.sidebar_visible())

    def show_panel(self, show, tab=None):
        if show != self.panel_visible():
            if not show:
                self._save_layout()
            self.set_pane("bottom", self.center, self.bottom, show, int(self.cfg.get("panel_h", 220)), 90, "height")
        if show and tab:
            self.bottom.show_tab(tab)
        self.cfg["panel_open"] = show

    def hide_panel(self):
        self.show_panel(False)

    def toggle_panel(self):
        self.show_panel(not self.panel_visible())

    def show_ai(self, show):
        if show != self.ai_visible():
            if not show:
                self._save_layout()
            self.set_pane("ai", self.main, self.ai_panel, show, int(self.cfg.get("ai_w", 410)), 320, "width")
            if show:
                self.ai.refresh_probe(force=True)
        if show:
            self.ai_panel.refresh_ready()
        self.cfg["ai_open"] = show
        self._paint_activity()

    def hide_ai(self):
        self.show_ai(False)

    def toggle_ai(self):
        shown = self.ai_visible()
        self.show_ai(not shown)
        if not shown:
            self.ai_panel.focus_input()

    def toggle_wrap(self):
        self.cfg["word_wrap"] = not self.cfg.get("word_wrap")
        self.apply_editor_settings()
        self.toast("Word wrap " + ("on" if self.cfg["word_wrap"] else "off"), "info", 1400)

    def apply_editor_settings(self):
        for ed in self.editors:
            ed.apply_settings()
        self.update_status()

    def _save_layout(self):
        try:
            busy = lambda n: ("pane", n) in self.anim.jobs
            if self.sidebar_visible() and not busy("sidebar") and self.sidebar.winfo_width() > 60:
                self.cfg["sidebar_w"] = self.sidebar.winfo_width()
            if self.ai_visible() and self._built("ai_panel") and not busy("ai") and self.ai_panel.winfo_width() > 60:
                self.cfg["ai_w"] = self.ai_panel.winfo_width()
            if self.panel_visible() and self._built("bottom") and not busy("bottom") and self.bottom.winfo_height() > 40:
                self.cfg["panel_h"] = self.bottom.winfo_height()
        except tk.TclError:
            pass

    # ---- status ------------------------------------------------------------------------------------------------
    def set_status(self, msg):
        self.st_msg.configure(text=msg)

    def set_state(self, text, color_key):
        self.st_state.configure(text="●  " + tr(text))
        target = self.theme[color_key]
        start = self.st_state.fg_override or target

        def step(p):
            self.st_state.fg_override = mix(start, target, p)
            self.st_state.retheme()
        tween(("state",), 280, step)

    def update_title(self):
        if self.cur and not self.home_visible:
            self.root.title("%s%s — %s" % (self.cur.title(), " *" if self.cur.dirty else "", APP))
        else:
            self.root.title(APP)

    def update_status(self):
        ed = self.cur if not self.home_visible else None
        if not ed:
            self.st_pos.configure(text="")
            self.st_syn.configure(text="")
            self.st_lang.configure(text="")
        else:
            try:
                ln, col = ed.text.index("insert").split(".")
            except Exception:
                return
            self.st_pos.configure(text="Ln %s, Col %d" % (ln, int(col) + 1))
            self.st_lang.configure(text=LANG_LABEL[ed.lang])
            self.st_spaces.configure(text="Spaces: %d" % len(ed.tab))
            if ed.syn_msg:
                self.st_syn.fg_override = self.theme["red"]
                self.st_syn.configure(text="⛔ " + ed.syn_msg[:60])
            else:
                self.st_syn.fg_override = self.theme["green"] if ed.lang == "python" else None
                self.st_syn.configure(text="✔ No syntax errors" if ed.lang == "python" else "")
            self.st_syn.retheme()
        if self.ai_visible():
            self.ai_panel.refresh_context()

    def toolchain(self, force=False):
        """(python, g++, gcc) - cached for 30 s because PATH lookups are slow on some Windows machines."""
        key = (self.cfg.get("python"), self.cfg.get("cxx"))
        c = getattr(self, "_tc", None)
        if force or not c or c[0] != key or time.time() - c[1] > 30:
            c = (key, time.time(), (find_python(self.cfg), find_cxx(self.cfg), find_cc(self.cfg)))
            self._tc = c
        return c[2]

    def _slow_tick(self):
        """Cheap housekeeping every few seconds (AI chip, compiler chip). Nothing here touches the disk or network."""
        try:
            self.ai.refresh_probe()
            self.st_ai.configure(text="✦ " + self.ai.describe())
            if self.ai_visible():
                self.ai_panel.refresh_ready()
            _, cxx, cc = self.toolchain()
            tools = ["C++ ✔" if cxx else "C++ ✖"]
            if cc:
                tools.append("C ✔")
            self.st_tool.configure(text="Python ✔   " + "  ".join(tools))
            if self._built("runview"):
                self.runview.stop_b.set_enabled(self.runner.running)
            if not self.runner.q.empty() or not self.ai_q.empty():
                self._kick_poll()
        except Exception:
            pass
        self.root.after(4000, self._slow_tick)

    # ---- tabs & files --------------------------------------------------------------------------------------------
    def add_editor(self, path=None, content="", lang=None):
        ed = Editor(self.host, self, path, content, lang)
        if not path:
            self.untitled_count += 1
            ed.untitled_n = self.untitled_count
        self.editors.append(ed)
        self.switch_to(ed)
        return ed

    def show_home(self):
        if self.home_visible:
            return
        self.home_visible = True
        if self.cur:
            self.cur.popup.hide()
            self.cur.pack_forget()
        self.welcome.retheme()
        self.welcome.pack(fill="both", expand=True)
        self.welcome.play_intro()
        self.tabbar.refresh()
        self.update_title()
        self.update_status()
        self._paint_activity()

    def switch_to(self, ed):
        was_home = self.home_visible
        if was_home:
            self.welcome.pack_forget()
            self.home_visible = False
        if self.cur is ed and not was_home:
            self.tabbar.refresh()
            return
        if self.cur and self.cur is not ed:
            self.cur.popup.hide()
            self.cur.pack_forget()
        self.cur = ed
        ed.pack(fill="both", expand=True)
        ed.text.focus_set()
        if self.cfg.get("anim_level") == "expressive" and self.anim.on and not self._instant:
            try:                                               # a soft curtain slides away to reveal the tab
                cov = tk.Frame(ed, bg=mix(self.theme["bg"], self.theme["accent"], .10))
                cov.place(relx=0, rely=0, relwidth=1, relheight=1)
                tween(("tab-wipe",), 260, lambda p: cov.winfo_exists() and cov.place_configure(relx=p),
                      lambda: cov.winfo_exists() and cov.destroy(), ease_out_expo)
            except tk.TclError:
                pass
        self.tabbar.refresh()
        ed.on_cursor()
        self.update_title()
        self.explorer.reveal(ed.path)
        self._paint_activity()
        if self.findbar.shown:
            self.findbar.refresh_matches()

    def cycle_tab(self, d):
        if len(self.editors) > 1 and self.cur:
            i = (self.editors.index(self.cur) + d) % len(self.editors)
            self.switch_to(self.editors[i])

    def new_file(self, lang=None, starter=False):
        if not isinstance(lang, str):          # called from a button/menu without arguments
            lang = self.cfg.get("new_lang", "python")
        content = ""
        if starter:
            key = {"cpp": "C++ — Hello", "c": "C — Hello", "python": "Python — Hello"}[lang]
            content = TEMPLATES[key][1]
        ed = self.add_editor(None, content, lang)
        if content:
            ed.dirty = False
            self.tabbar.refresh()
        return ed

    def new_from_template(self, name):
        lang, code = TEMPLATES[name]
        self.add_editor(None, code, lang)

    def open_file(self, path=None):
        if not isinstance(path, str):
            path = filedialog.askopenfilename(title="Open file", filetypes=[
                ("Code", "*.py *.pyw *.cpp *.cc *.cxx *.c *.h *.hpp *.txt"), ("All files", "*.*")])
        if not path:
            return
        norm = os.path.normcase(os.path.abspath(path))
        for ed in self.editors:
            if ed.path and os.path.normcase(os.path.abspath(ed.path)) == norm:
                self.switch_to(ed)
                return ed
        try:
            if os.path.getsize(path) > 5_000_000:
                messagebox.showwarning(APP, "File is too large to open here (>5 MB).")
                return
            self.set_status("Opening %s…" % os.path.basename(path))
            with open(path, "rb") as f:
                raw = f.read()
            try:
                content = raw.decode("utf-8-sig")
            except UnicodeDecodeError:
                content = raw.decode("latin-1")
        except Exception as e:
            messagebox.showerror(APP, "Could not open file:\n%s" % e)
            return
        content = content.replace("\r\n", "\n").replace("\r", "\n")
        if len(self.editors) == 1 and not self.editors[0].path and not self.editors[0].dirty \
                and not self.editors[0].get_text().strip():
            self._destroy_editor(self.editors[0])
        push_recent(self.cfg, "recent_files", os.path.abspath(path))
        ed = self.add_editor(path, content)
        self.set_status("")
        return ed

    def _destroy_editor(self, ed):
        if ed in self.editors:
            self.editors.remove(ed)
        if self.cur is ed:
            self.cur = None
        self.diags_syntax.pop(ed, None)
        self._sched_problems()
        ed.popup.hide()
        ed.destroy()

    def save(self, ed=None):
        ed = ed if isinstance(ed, Editor) else self.cur
        if not ed or (ed is self.cur and self.home_visible):
            return False
        if not ed.path:
            return self.save_as(ed)
        return self._write(ed, ed.path)

    def save_as(self, ed=None):
        ed = ed if isinstance(ed, Editor) else self.cur
        if not ed:
            return False
        ext = LANG_EXT.get(ed.lang, ".txt")
        path = filedialog.asksaveasfilename(title="Save as", defaultextension=ext, initialfile=ed.title(),
                                            filetypes=[("Code", "*" + ext), ("All files", "*.*")])
        if not path:
            return False
        ok = self._write(ed, path)
        if ok:
            ed.path = path
            ed.lang = detect_lang(path) if detect_lang(path) != "text" else ed.lang
            ed.highlight()
            ed.check_python()
            ed.refresh_folds()
            push_recent(self.cfg, "recent_files", os.path.abspath(path))
            self.tabbar.refresh()
            self.update_title()
            if self.explorer.root_path:
                self.explorer.refresh_dir(os.path.dirname(path))
        return ok

    def _write(self, ed, path, quiet=False):
        try:
            data = ed.get_text()
            if self.cfg.get("trim_ws"):
                data = "\n".join(l.rstrip() for l in data.split("\n"))
            if self.cfg.get("final_newline") and not data.endswith("\n"):
                data += "\n"
            with open(path, "w", encoding="utf-8", newline="\n") as f:
                f.write(data)
        except Exception as e:
            messagebox.showerror(APP, "Could not save:\n%s" % e)
            return False
        ed.dirty = False
        self.tabbar.refresh()
        self.update_title()
        if not quiet:
            self.toast("Saved " + os.path.basename(path), "success", 1500)
            self.set_status("Saved " + path)
        return True

    def save_all(self):
        n = 0
        for ed in list(self.editors):
            if ed.dirty:
                if not self.save(ed):
                    return
                n += 1
        self.toast("Saved %d file%s" % (n, "" if n == 1 else "s") if n else "Nothing to save", "success" if n else "info", 1500)

    def close_current(self):
        if self.cur and not self.home_visible:
            self.close_tab(self.cur)
        elif self.home_visible and self.editors:
            self.switch_to(self.cur or self.editors[0])

    def close_tab(self, ed):
        if ed.dirty and (ed.path or ed.get_text().strip()):
            self.switch_to(ed)
            ans = messagebox.askyesnocancel(APP, "Save changes to %s?" % ed.title())
            if ans is None:
                return False
            if ans and not self.save(ed):
                return False
        i = self.editors.index(ed)
        was_cur = self.cur is ed
        self._destroy_editor(ed)
        if was_cur and not self.home_visible:
            if self.editors:
                self.switch_to(self.editors[min(i, len(self.editors) - 1)])
            else:
                self.cur = None
                self.show_home()
        if not self.editors and not self.home_visible:
            self.show_home()
        self.tabbar.refresh()
        self.update_title()
        self.update_status()
        return True

    def close_others(self, keep):
        for ed in list(self.editors):
            if ed is not keep and not self.close_tab(ed):
                return

    def close_all(self):
        for ed in list(self.editors):
            if not self.close_tab(ed):
                return

    def on_path_renamed(self, old, new):
        o = os.path.normcase(os.path.abspath(old))
        for ed in self.editors:
            if not ed.path:
                continue
            p = os.path.normcase(os.path.abspath(ed.path))
            if p == o or p.startswith(o + os.sep):
                ed.path = os.path.join(new, os.path.relpath(ed.path, old)) if p != o else new
                ed.lang = detect_lang(ed.path) if detect_lang(ed.path) != "text" else ed.lang
                ed.highlight()
        self.tabbar.refresh()
        self.update_title()

    def on_path_deleted(self, path):
        o = os.path.normcase(os.path.abspath(path))
        for ed in self.editors:
            if ed.path:
                p = os.path.normcase(os.path.abspath(ed.path))
                if p == o or p.startswith(o + os.sep):
                    ed.path = None            # keep the text open as an untitled, unsaved buffer
                    ed.dirty = True
                    self.untitled_count += 1
                    ed.untitled_n = self.untitled_count
        self.tabbar.refresh()
        self.update_title()

    def open_folder(self):
        d = filedialog.askdirectory(title="Open folder")
        if d:
            self.open_recent_folder(d)

    def open_recent_folder(self, d):
        if not os.path.isdir(d):
            self.toast("That folder no longer exists", "warn")
            return
        d = os.path.abspath(d)
        self.cfg["folder"] = d
        push_recent(self.cfg, "recent_folders", d)
        self.explorer.set_root(d)
        self.activity("explorer", True)
        self.toast("Opened folder " + os.path.basename(d), "success", 1500)

    def goto_line(self):
        if not self.cur or self.home_visible:
            return
        ed = self.cur
        total = int(ed.text.index("end-1c").split(".")[0])

        def check(v):
            return None if v.isdigit() and 1 <= int(v) <= total else "Enter a line number from 1 to %d." % total
        v = quick_input(self, "Go to line", "Line number (1 - %d)" % total, "", check, "Go")
        if v:
            ed.goto(int(v))

    def format_document(self):
        if self.cur and not self.home_visible:
            n = self.cur.format_document()
            self.toast("Formatted %d line%s" % (n, "" if n == 1 else "s") if n else "Already tidy", "success" if n else "info", 1600)

    # ---- running ---------------------------------------------------------------------------------------------------
    def _prepare_source(self, ed):
        if ed.path:
            if ed.dirty and self.cfg.get("autosave_on_run", True):
                if not self.save(ed):
                    return None
            return ed.path
        ext = LANG_EXT.get(ed.lang, ".txt")
        p = os.path.join(TMP, "untitled_%d%s" % (ed.untitled_n or 1, ext))
        with open(p, "w", encoding="utf-8", newline="\n") as f:
            f.write(ed.get_text())
        self.tmp_map[os.path.normcase(os.path.abspath(p))] = ed
        return p

    def run_current(self, build_only=False):
        if not isinstance(build_only, bool):
            build_only = False
        ed = self.cur
        if not ed or self.home_visible:
            self.toast("Open a file first", "warn")
            return
        if ed.lang not in ("python", "cpp", "c"):
            self.toast("Pick a language (Python / C++ / C) from the status bar first.", "warn", 3500)
            return
        src = self._prepare_source(ed)
        if not src:
            return
        for e in self.editors:
            e.clear_run_errors()
        self.run_errors = {}
        self.diags_run, self._diag_keys = [], set()
        self._sched_problems()
        if self.cfg.get("clear_on_run", True):
            self.bottom.term.clear()
            self.bottom.output.clear()
        cwd = os.path.dirname(os.path.abspath(src))
        stem = os.path.splitext(os.path.basename(src))[0]
        args = []
        try:
            args = shlex.split(self.cfg.get("run_args", "") or "", posix=not IS_WIN)
        except ValueError:
            pass
        steps = []
        if ed.lang == "python":
            if build_only:
                ed.check_python()
                self.toast(("Syntax error: " + ed.syn_msg) if ed.syn_msg else "No syntax errors", "error" if ed.syn_msg else "success")
                return
            py = find_python(self.cfg)
            if FROZEN and not (os.path.isabs(py) and os.path.exists(py)) and not shutil.which(py):
                self.show_panel(True, "Output")
                self.bottom.output.append(tr("Python is needed to run Python files. Install it from python.org, then press Run again.") + "\n", "warn")
                self.toast(tr("Python is not installed"), "error", 6000, action=(tr("Download"), lambda: webbrowser.open("https://www.python.org/downloads/")))
                return
            steps.append(("run", [py, "-u", src] + args, cwd))
        else:
            is_cpp = ed.lang == "cpp"
            comp = find_cxx(self.cfg) if is_cpp else find_cc(self.cfg)
            if not comp:
                self.show_panel(True, "Output")
                self.bottom.output.append(self._no_compiler_help(is_cpp), "warn")
                self.toast("No %s compiler found" % ("C++" if is_cpp else "C"), "error")
                return
            self._run_n = (self._run_n + 1) % 6          # rotate names: a still-exiting old build never blocks the new one
            exe = os.path.join(TMP, "%s_%d%s" % (stem, self._run_n, ".exe" if IS_WIN else ""))
            try:
                os.remove(exe)
            except OSError:
                pass
            flags = shlex.split(self.cfg.get("cxxflags" if is_cpp else "cflags", ""), posix=not IS_WIN)
            cmd = [comp] + flags
            if self.cfg.get("unbuffered", True) and os.path.exists(self.unbuf_h):
                cmd += ["-include", self.unbuf_h]
            cmd += [src, "-o", exe]
            if not is_cpp and not IS_WIN:
                cmd.append("-lm")
            steps.append(("compile", cmd, cwd))
            if not build_only:
                steps.append(("run", [exe] + args, cwd))
        self.last_run = ed
        self.build_only = build_only
        self.run_started = False
        self.phase = "build" if steps[0][0] == "compile" else "run"
        if self.phase == "build":
            self.show_panel(True, "Output")
            self.bottom.output.append("▶ Building %s  [%s]\n" % (ed.title(), LANG_LABEL[ed.lang]), "info")
        else:
            self.show_panel(True, "Terminal")
            self.bottom.term.append("▶ %s  [%s]\n" % (ed.title(), LANG_LABEL[ed.lang]), "info")
        self.set_state("Building…" if self.phase == "build" else "Running…", "yellow")
        self.run_btn.set_enabled(False)
        self.stop_btn.set_enabled(True)
        self.log("%s %s" % ("Build" if build_only else "Run", src))
        self._kick_poll()
        self.runner.start(steps)
        if re.search(r"\binput\s*\(|\bcin\b|\bscanf\b|\bgetline\b|\bgets\b|\bgetchar\b|\bfgets\b", ed.get_text()):
            self.stdin.focus_set()

    def _no_compiler_help(self, is_cpp):
        name = "g++" if is_cpp else "gcc"
        if IS_WIN:
            how = ("Windows: install MinGW-w64 (e.g. from https://winlibs.com) or MSYS2, then add its 'bin' folder "
                   "to PATH, or set the compiler path in Settings > C/C++.")
        elif IS_MAC:
            how = "macOS: run  xcode-select --install  in Terminal."
        else:
            how = "Linux: run  sudo apt install build-essential  (or your distro's equivalent)."
        return "⚠ No %s compiler found.\n%s\n" % (name, how)

    def stop_run(self):
        if self.runner.running:
            self.runner.stop()
            self._kick_poll()
            (self.bottom.term if self.run_started or self.phase == "run" else self.bottom.output).append("\n■ Stopped\n", "warn")
            self._run_finished()
            self.set_state("Stopped", "yellow")

    def _run_finished(self):
        self.run_btn.set_enabled(True)
        self.stop_btn.set_enabled(False)
        self.runview.stop_b.set_enabled(False)

    def send_stdin(self):
        line = self.stdin_var.get()
        if not self.runner.running:
            return
        if self.runner.send(line + "\n"):
            self.bottom.term.append(line + "\n", "in")
        self.stdin_var.set("")

    def close_stdin(self):
        self.runner.close_stdin()
        if self.runner.running:
            self.toast("Input closed (EOF sent)", "info", 1400)

    def clear_view(self, name):
        if name == "Terminal":
            self.bottom.term.clear()
        elif name == "Output":
            self.bottom.output.clear()
        elif name == "Problems":
            self.diags_run, self._diag_keys = [], set()
            self.run_errors = {}
            for e in self.editors:
                e.clear_run_errors()
            self._sched_problems()
        else:
            self.bottom.debug.clear()

    def last_run_dir(self):
        ed = self.last_run
        if ed and ed.path:
            return os.path.dirname(os.path.abspath(ed.path))
        return TMP

    def _find_editor(self, path):
        norm = os.path.normcase(os.path.abspath(path))
        for ed in self.editors:
            if ed.path and os.path.normcase(os.path.abspath(ed.path)) == norm:
                return ed
        return self.tmp_map.get(norm)

    def _mark_run_errors(self):
        for path, lines in self.run_errors.items():
            ed = self._find_editor(path)
            if ed and ed in self.editors:
                ed.set_run_errors(lines)

    def goto_file(self, path, line, col=1):
        ed = self._find_editor(path)
        if ed and ed not in self.editors:
            ed = None
        if not ed and os.path.exists(path):
            ed = self.open_file(path)
        if ed:
            self.switch_to(ed)
            ed.goto(line, col)

    def goto_diag(self, d):
        ed = d.get("ed")
        if ed is not None and ed in self.editors:
            self.switch_to(ed)
            ed.goto(d["line"], d["col"])
        else:
            self.goto_file(d["path"], d["line"], d["col"])

    # ---- problems -----------------------------------------------------------------------------------------------------
    def add_diag(self, kind, path, line, col, msg):
        key = (os.path.normcase(os.path.abspath(path)), line, kind, msg)
        if key in self._diag_keys:
            return
        self._diag_keys.add(key)
        self.diags_run.append(dict(kind=kind, path=path, line=line, col=col, msg=msg))
        if kind == "error":
            self.run_errors.setdefault(os.path.normcase(os.path.abspath(path)), set()).add(line)
            self._mark_run_errors()
        self._sched_problems()

    def update_problems_syntax(self, ed):
        if ed not in self.editors:
            return
        if ed.syn_line:
            self.diags_syntax[ed] = dict(kind="error", path=ed.path or ed.title(), line=ed.syn_line, col=1, ed=ed,
                                         msg=re.sub(r"\s*\(line \d+\)$", "", ed.syn_msg))
        else:
            self.diags_syntax.pop(ed, None)
        self._sched_problems()

    def _sched_problems(self):
        if self._prob_job is None:
            self._prob_job = self.root.after(120, self.refresh_problems)

    def refresh_problems(self):
        self._prob_job = None
        diags = list(self.diags_run) + list(self.diags_syntax.values())
        errs = sum(1 for d in diags if d["kind"] == "error")
        warns = len(diags) - errs
        if self._built("bottom"):
            self.bottom.problems.refresh(diags)
            self.bottom.set_problem_count(errs, warns)
        self.st_prob.configure(text="✖ %d   ▲ %d" % (errs, warns))
        self.st_prob.fg_override = self.theme["red"] if errs else (self.theme["yellow"] if warns else None)
        self.st_prob.retheme()

    def _poll(self):
        self._poll_ai()
        try:
            for _ in range(400):
                gen, kind, *rest = self.runner.q.get_nowait()
                if gen != self.runner.gen and kind != "done":
                    continue
                view = self.bottom.term if (self.run_started or self.phase == "run") else self.bottom.output
                if kind == "out":
                    view.append(rest[0], rest[1])
                elif kind == "info":
                    view.append(rest[0], "info")
                elif kind == "started":
                    self.run_started = True
                    self.phase = "run"
                    self.stdin.configure(state="normal")
                    self.show_panel(True, "Terminal")
                    self.bottom.term.append("▶ Running\n", "info")
                    self.set_state("Running…", "yellow")
                elif kind == "missing":
                    view.append("⚠ Could not start the program: %s\n" % rest[0], "err")
                    if "No such file" in rest[0] or "cannot find" in rest[0].lower():
                        view.append("Check the interpreter/compiler path in Settings.\n", "warn")
                elif kind == "done":
                    if gen != self.runner.gen:
                        continue
                    rc, secs = rest
                    ok = rc == 0
                    if self.run_started or self.phase == "run":
                        self.bottom.term.append("\n%s Process finished with exit code %s in %.2fs\n" % ("✔" if ok else "✖", rc, secs),
                                                "info" if ok else "err")
                        self.set_state("Finished" if ok else "Exited with code %s" % rc, "green" if ok else "red")
                        if not ok:
                            self.toast("Program exited with code %s" % rc, "error", 5000, action=(tr("Explain"), self.assistant_error_help))
                    else:
                        if ok:
                            self.set_state("Build OK", "green")
                            self.toast("Build successful", "success")
                        else:
                            self.set_state("Build failed", "red")
                            self.toast("Build failed - click an error to jump to it", "error", 6000, action=(tr("Explain"), self.assistant_error_help))
                            self.show_panel(True, "Output")
                    self._run_finished()
        except queue.Empty:
            pass
        if self.runner.running or self.ai_jobs or not self.runner.q.empty() or not self.ai_q.empty():
            self._poll_job = self.root.after(20, self._poll)
        else:
            self._poll_job = None            # nothing running: no timer at all (an idle IDE wakes up almost never)

    def _kick_poll(self):
        if self._poll_job is None:
            self._poll_job = self.root.after(5, self._poll)

    # ---- AI glue -----------------------------------------------------------------------------------------------------
    def ai_request(self, system, messages, on_delta=None, on_done=None, on_error=None, max_tokens=1800, chat=False):
        if not self.ai.ready():
            self.open_settings("AI")
            return None
        self.ai_rid += 1
        rid = self.ai_rid
        cancel = threading.Event()
        self.ai_jobs[rid] = dict(delta=on_delta, done=on_done, error=on_error, cancel=cancel)
        self.ai.start(system, messages, self.ai_q, rid, cancel, max_tokens, chat)
        self._kick_poll()
        self.set_status("✦ " + tr("Assistant") + "…")
        self.log("AI request via %s" % self.ai.describe())
        return rid

    def ai_cancel(self, rid=None):
        if rid is None:
            for j in self.ai_jobs.values():
                j["cancel"].set()
            self.ai_jobs.clear()
        else:
            j = self.ai_jobs.pop(rid, None)
            if j:
                j["cancel"].set()

    def _poll_ai(self):
        try:
            for _ in range(300):
                rid, kind, data = self.ai_q.get_nowait()
                job = self.ai_jobs.get(rid)
                if not job:
                    continue
                if kind == "delta":
                    if job["delta"]:
                        job["delta"](data)
                else:
                    self.ai_jobs.pop(rid, None)
                    if kind == "done" and job["done"]:
                        job["done"]()
                    elif kind == "error" and job["error"]:
                        job["error"](data)
        except queue.Empty:
            pass

    def ai_review(self, code, ctx=None):
        """Show exactly what the AI would change (red = removed, green = added) and apply only on 'Apply'."""
        import difflib
        ctx = ctx or {}
        ed = ctx.get("ed") if ctx.get("ed") in self.editors else self.cur
        if not ed:
            return
        t, old = ed.text, None
        marks = ctx.get("sel")
        if marks and ed is ctx.get("ed"):
            try:
                old = t.get(marks[0], marks[1])
            except tk.TclError:
                old = None
        if old is None:
            old = t.get("sel.first", "sel.last") if t.tag_ranges("sel") else ed.get_text()
        diff = list(difflib.unified_diff(old.splitlines(), code.splitlines(), "before", "after", n=2, lineterm=""))[2:]
        if not diff:
            self.toast(tr("No changes: the code is already the same"), "info", 2400)
            return
        th = self.theme
        w = tk.Toplevel(self.root)
        w.title(tr("Review AI changes"))
        w.configure(bg=th["bg"])
        w.transient(self.root)
        self.root.update_idletasks()
        ww, wh = min(900, max(560, int(self.root.winfo_width() * .6))), min(620, max(380, int(self.root.winfo_height() * .62)))
        w.geometry("%dx%d+%d+%d" % (ww, wh, self.root.winfo_rootx() + (self.root.winfo_width() - ww) // 2,
                                    self.root.winfo_rooty() + (self.root.winfo_height() - wh) // 2))
        add = sum(1 for l in diff if l.startswith("+"))
        rem = sum(1 for l in diff if l.startswith("-"))
        tk.Label(w, text="+%d   −%d" % (add, rem), bg=th["bg"], fg=th["fg"], font=self.ui_font, anchor="w").pack(fill="x", padx=12, pady=(10, 4))
        bar = tk.Frame(w, bg=th["bg"])
        bar.pack(side="bottom", fill="x", padx=12, pady=10)
        box = tk.Text(w, bg=th.get("editor", th["bg"]), fg=th["fg"], font=self.font,
                      bd=0, highlightthickness=0, wrap="none", padx=10, pady=8)
        box.pack(fill="both", expand=True, padx=12)
        box.tag_configure("add", background=mix(th["bg"], ACCENTS["green"], .22))
        box.tag_configure("rem", background=mix(th["bg"], ACCENTS["rose"], .22))
        box.tag_configure("hunk", foreground=th.get("muted", th["fg"]))
        for l in diff:
            box.insert("end", l + "\n", "add" if l.startswith("+") else "rem" if l.startswith("-") else "hunk" if l.startswith("@@") else "")
        box.configure(state="disabled")

        def apply_():
            w.destroy()
            self.ai_apply(code, "replace", ctx)
        Btn(bar, "Apply", apply_, kind="primary", role="bg", height=28, padx=14).pack(side="right")
        Btn(bar, "Cancel", w.destroy, kind="outline", role="bg", height=28, padx=12).pack(side="right", padx=6)
        w.bind("<Escape>", lambda e: w.destroy())
        w.bind("<Return>", lambda e: apply_())
        w.focus_set()

    def ai_apply(self, code, mode, ctx=None):
        ctx = ctx or {}
        ed = ctx.get("ed")
        if ed not in self.editors:
            ed = self.cur
        if not ed:
            return
        t = ed.text
        t.edit_separator()
        if mode == "insert":
            t.insert("insert", code)
        else:
            marks = ctx.get("sel")
            done = False
            if marks and ed is ctx.get("ed"):
                try:
                    t.delete(marks[0], marks[1])
                    t.insert(marks[0], code)
                    done = True
                except tk.TclError:
                    done = False
            if not done:
                if t.tag_ranges("sel"):
                    a = t.index("sel.first")
                    t.delete("sel.first", "sel.last")
                    t.insert(a, code)
                else:
                    t.delete("1.0", "end-1c")
                    t.insert("1.0", code)
                    t.mark_set("insert", "1.0")
                    t.see("insert")
        t.edit_separator()
        self.switch_to(ed)
        self.toast("AI code applied - Ctrl+Z to undo", "success", 2400)

    def ai_fix_error(self):
        if self.cur and not self.home_visible:
            self.show_ai(True)
            self.ai_panel.quick("fix")
        else:
            self.toast("Open the file with the error first", "warn")

    def ai_inline(self):
        ed = self.cur
        if not ed or self.home_visible:
            return
        th = self.theme
        t = ed.text
        bb = t.bbox("insert")
        w = tk.Toplevel(self.root)
        borderless(w)
        w.geometry("+%d+%d" % (t.winfo_rootx() + (bb[0] if bb else 40), t.winfo_rooty() + (bb[1] + bb[3] + 6 if bb else 40)))
        w.configure(bg=th["accent"])
        inner = tk.Frame(w, bg=th["pop"])
        inner.pack(padx=1, pady=1)
        TLabel(inner, text="✦ Ask the assistant   ·   Enter = run   ·   Esc = cancel   ·   empty = continue the code",
                 bg=th["pop"], fg=th["muted"], font=self.ui_font, padx=10, pady=6, anchor="w").pack(fill="x")
        e = tk.Entry(inner, width=64, font=self.font)
        style_entry(e, "panel2")
        e.pack(padx=10, pady=(0, 10), ipady=5)

        def go(ev=None):
            prompt = e.get().strip()
            w.destroy()
            self._ai_inline_run(ed, prompt)
            return "break"

        def cancel(ev=None):
            w.destroy()
            ed.text.focus_set()
            return "break"
        e.bind("<Return>", go)
        e.bind("<Escape>", cancel)
        self.root.after(10, lambda: e.winfo_exists() and e.focus_force())

    def _ai_inline_run(self, ed, prompt):
        t = ed.text
        self.ai_panel.mark_n += 1
        na, nb = "ai_ia%d" % self.ai_panel.mark_n, "ai_ib%d" % self.ai_panel.mark_n
        has_sel = bool(t.tag_ranges("sel"))
        if has_sel:
            a, b = t.index("sel.first"), t.index("sel.last")
            sel = t.get(a, b)
        else:
            a = b = t.index("insert")
            sel = ""
        t.mark_set(na, a)
        t.mark_gravity(na, "left")
        t.mark_set(nb, b)
        t.mark_gravity(nb, "right")
        before = t.get("1.0", a)[-5000:]
        after = t.get(b, "end-1c")[:2500]
        if has_sel:
            user = ("Instruction: %s\n\nCode before the selection:\n```\n%s\n```\n\nSelected code to rewrite:\n```\n%s\n```"
                    "\n\nCode after the selection:\n```\n%s\n```" % (prompt or "Improve this code", before, sel, after))
        else:
            user = ("Instruction: %s\n\nCode before the cursor:\n```\n%s\n```\n\nCode after the cursor:\n```\n%s\n```"
                    % (prompt or "Continue the code naturally from the cursor.", before, after))
        buf = []

        def done():
            code = extract_code("".join(buf))
            if not code.strip():
                self.toast("The AI returned nothing", "warn")
                return
            try:
                t.edit_separator()
                t.delete(na, nb)
                t.insert(na, code)
                t.edit_separator()
            except tk.TclError:
                return
            self.toast("AI code inserted - Ctrl+Z to undo", "success", 2400)
            self.set_status("")

        def error(msg):
            self.set_status("⚠ " + msg)
            self.toast(msg, "error", 5000)
        self.ai_request(AI_INLINE_SYSTEM.format(lang=LANG_LABEL[ed.lang]), [{"role": "user", "content": user}],
                        on_delta=buf.append, on_done=done, on_error=error, max_tokens=2048)

    # ---- dialogs ---------------------------------------------------------------------------------------------------------
    def palette(self):
        CommandPalette(self)

    def open_settings(self, page="General"):
        if not isinstance(page, str):
            page = "General"
        if self.settings_win is not None:
            try:
                if self.settings_win.top.winfo_exists():
                    self.settings_win.show_page(page)
                    self.settings_win.top.lift()
                    self.settings_win.top.focus_force()
                    return
            except tk.TclError:
                pass
        self.settings_win = SettingsWindow(self, page)

    def show_help(self):
        th = self.theme
        w = tk.Toplevel(self.root)
        w.title("Keyboard shortcuts")
        w.geometry("560x600")
        w.configure(bg=th["pop"])
        w.transient(self.root)
        t = tk.Text(w, bg=th["pop"], fg=th["fg"], bd=0, padx=22, pady=16, font=self.font, wrap="word", highlightthickness=0, spacing1=1)
        t.pack(fill="both", expand=True)
        t.tag_configure("h", foreground=th["accent"], font=self.ui_bold, spacing1=10, spacing3=2)
        for head, body in (
                ("RUN", "  F5 / Ctrl+F5   Run            F7   Build only / check errors\n  Shift+F5        Stop"),
                ("FILES", "  Ctrl+N / O / S      New / Open / Save\n  Ctrl+Shift+S        Save as\n  Ctrl+Shift+O        Open folder\n  Ctrl+W              Close tab\n  Ctrl+Tab            Next tab"),
                ("EDITING", "  Tab / Shift+Tab     Indent / outdent (also snippets: main, for, cp ...)\n  Ctrl+/              Toggle comment\n  Ctrl+D              Duplicate line\n  Ctrl+Shift+K        Delete line\n  Alt+Up / Alt+Down   Move line\n  Ctrl+Space          Autocomplete\n  Ctrl+[              Fold / unfold block\n  Ctrl+F / H          Find / Replace\n  Ctrl+G              Go to line"),
                ("VIEW", "  Ctrl+B              Toggle sidebar\n  Ctrl+J              Toggle bottom panel\n  Ctrl+Shift+E / F    Explorer / Search\n  Ctrl+Shift+P        Command palette\n  Ctrl+Shift+T        Change theme\n  Ctrl+,              Settings\n  Ctrl + / - / 0      Zoom"),
                ("AI", "  Ctrl+L              Open the AI chat\n  Ctrl+K              Ask the AI to write code at the cursor\n  Fix with AI         Button in the bottom panel")):
            t.insert("end", head + "\n", "h")
            t.insert("end", K(body) + "\n")
        t.configure(state="disabled")
        w.bind("<Escape>", lambda e: w.destroy())

    # ---- session ---------------------------------------------------------------------------------------------------------------
    def _autosave_step(self):
        try:
            if self.cfg.get("autosave"):
                if time.time() - self._last_save_tick >= max(5, int(self.cfg.get("autosave_secs", 30))):
                    self._last_save_tick = time.time()
                    n = 0
                    for ed in self.editors:
                        if ed.dirty and ed.path and self._write(ed, ed.path, quiet=True):
                            n += 1
                    if n:
                        self.set_status("Auto-saved %d file%s" % (n, "" if n == 1 else "s"))
        except Exception:
            pass


    def _snapshot(self):
        tabs = []
        for e in self.editors:
            txt = e.get_text()
            keep = (e.dirty or not e.path) and len(txt) < 3_000_000
            try:
                cur, y = e.text.index("insert"), e.text.yview()[0]
            except tk.TclError:
                cur, y = "1.0", 0.0
            tabs.append(dict(path=e.path, lang=e.lang, text=txt if keep else None, dirty=bool(e.dirty), cursor=cur, y=y, n=e.untitled_n))
        return dict(v=2, tabs=tabs, active=self.editors.index(self.cur) if self.cur in self.editors else 0, home=self.home_visible)

    def save_session(self, force=False):
        """Write the open tabs (including unsaved text, cursor and scroll) so the next start continues exactly here."""
        if self.safe and not self.editors:
            return
        sig = (tuple((e.path, e.dirty, e.rev) for e in self.editors), self.editors.index(self.cur) if self.cur in self.editors else -1)
        if not force and sig == self._backup_hash:
            return
        self._backup_hash = sig
        try:
            tmp = SESSION_PATH + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self._snapshot(), f, ensure_ascii=False)
            os.replace(tmp, SESSION_PATH)
        except Exception:
            pass

    def _backup_step(self):
        self.save_session()

    def _update_check(self):
        """Background self-update: if the latest GitHub release has a newer build, download it, check its hash and that it
        compiles, then swap the file. It takes effect on the next start; a failed check never touches the working copy."""
        if not self.cfg.get("auto_update", True):
            return
        me = os.path.abspath(globals().get("__file__") or "")
        if os.path.basename(me) != "legend_code_main.py":
            return                                         # running from source / tests: nothing to update

        def work():
            import hashlib
            try:
                with urllib.request.urlopen(urllib.request.Request(UPDATE_BASE + "version.json", headers={"User-Agent": UA}), timeout=15) as r:
                    info = json.loads(r.read().decode("utf-8"))
                build = int(info.get("build", 0))
                if build <= APP_BUILD:
                    return
                with urllib.request.urlopen(urllib.request.Request(UPDATE_BASE + "legend_code_main.py", headers={"User-Agent": UA}), timeout=60) as r:
                    data = r.read()
                if hashlib.sha256(data).hexdigest() != info.get("sha256"):
                    raise RuntimeError("update hash mismatch")
                compile(data.decode("utf-8"), "legend_code_main.py", "exec")
                tmp = me + ".new"
                with open(tmp, "wb") as f:
                    f.write(data)
                os.replace(tmp, me)
                for p in glob.glob(os.path.join(os.path.dirname(me), "__pycache__", "legend_code_main*.pyc")):
                    try:
                        os.remove(p)
                    except OSError:
                        pass
                self._update_ready = info.get("notes") or str(build)
            except Exception as e:
                self._update_err = str(e)[:200]
        threading.Thread(target=work, daemon=True).start()

    def _maint_tick(self):
        if getattr(self, "_update_ready", None) and not getattr(self, "_update_told", False):
            self._update_told = True
            self.toast(tr("Legend Code was updated. Restart it to use the new version."), "info", 9000)
        self._autosave_step()
        self.save_session()
        try:                                                  # settings are written whenever they changed
            sig = json.dumps(self.cfg, sort_keys=True, default=str)
            if sig != getattr(self, "_cfg_sig", None):
                self._cfg_sig = sig
                save_config(self.cfg)
        except Exception:
            pass
        self.root.after(6000, self._maint_tick)

    def _recover_backup(self, path=None):
        """Re-open the tabs of the last session, with unsaved text, cursor and scroll position. Returns how many tabs came back."""
        try:
            with open(path or SESSION_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            return 0
        if isinstance(data, list):                          # format of older versions: just the unsaved buffers
            data = dict(tabs=[dict(path=i.get("path"), lang=i.get("lang"), text=i.get("text"), dirty=bool(i.get("dirty")), cursor="1.0", y=0.0)
                              for i in data if isinstance(i, dict)], active=0)
        opened = []
        for t in data.get("tabs", []):
            try:
                p, text = t.get("path"), t.get("text")
                ed = None
                if p and os.path.isfile(p):
                    ed = self.open_file(p)
                if ed is None and text is not None:
                    ed = self.add_editor(None, text, t.get("lang") or "python")
                    ed.dirty = bool(t.get("dirty", True))
                    if t.get("n"):
                        ed.untitled_n = t["n"]
                elif ed is not None and text is not None and ed.get_text() != text:
                    ed.text.delete("1.0", "end-1c")
                    ed.text.insert("1.0", text)
                    ed.dirty = True
                if ed is None:
                    continue
                try:
                    ed.text.mark_set("insert", t.get("cursor") or "1.0")
                    ed.text.yview_moveto(float(t.get("y") or 0.0))
                except (tk.TclError, ValueError):
                    pass
                opened.append(ed)
            except Exception:
                continue
        if opened:
            idx = max(0, min(int(data.get("active", 0) or 0), len(opened) - 1))
            self.switch_to(opened[idx])
            self.tabbar.refresh()
        return len(opened)

    def _restore_session(self):
        self._instant = True
        try:
            self._restore_session_inner()
        finally:
            self._instant = False

    def _restore_session_inner(self):
        mode = "welcome" if self.safe else self.cfg.get("startup", "restore")
        recovered = 0
        if mode == "restore":
            if self.cfg.get("hot_exit", True) and os.path.exists(SESSION_PATH):
                self._recover_backup()
                recovered = sum(1 for e in self.editors if e.dirty)
            if not self.editors:
                for p in self.cfg.get("files", []):
                    if os.path.isfile(p):
                        self.open_file(p)
        if self.cfg.get("folder") and os.path.isdir(self.cfg["folder"]) and not self.safe:
            self.explorer.set_root(self.cfg["folder"])
        for p in sys.argv[1:]:
            if isinstance(p, str) and os.path.isfile(p):
                try:
                    self.open_file(os.path.abspath(p))
                except Exception:
                    pass
        if mode == "new" and not self.editors:
            self.new_file()
        if self.editors:
            idx = int(self.cfg.get("active", 0)) if mode == "restore" else 0
            self.switch_to(self.editors[min(max(idx, 0), len(self.editors) - 1)])
        else:
            self.show_home()
        self.view = self.cfg.get("sidebar_view", "explorer")
        self.show_view(self.view)
        if self.cfg.get("sidebar_open", True):
            self.show_sidebar(True)
        if self.cfg.get("panel_open") and not self.safe:
            self.show_panel(True, self.cfg.get("panel_tab", "Terminal"))
        if self.cfg.get("ai_open") and not self.safe:
            self.show_ai(True)
        if self.cfg.get("maximized") and not self.safe:
            try:
                self.root.state("zoomed")
            except tk.TclError:
                pass
        self.refresh_problems()
        self.set_state(tr("Ready"), "green")
        self.set_status(tr("Press F5 to run"))
        self._slow_tick_once()
        if recovered:
            self.toast(tr("Continued where you left off (unsaved changes included)"), "success", 3200)
        self.apply_chrome()

    def _slow_tick_once(self):
        try:
            self.st_ai.configure(text="✦ " + self.ai.describe())
        except Exception:
            pass

    def on_quit(self):
        if self.cfg.get("confirm_exit") and not messagebox.askyesno(APP, "Close Legend Code?"):
            return
        if self.runner.running and not messagebox.askyesno(APP, "A program is still running. Stop it and quit?"):
            return
        hot = self.cfg.get("hot_exit", True)
        for ed in ([] if hot else list(self.editors)):
            if ed.dirty and (ed.path or ed.get_text().strip()):
                self.switch_to(ed)
                ans = messagebox.askyesnocancel(APP, "Save changes to %s?" % ed.title())
                if ans is None:
                    return
                if ans and not self.save(ed):
                    return
                if not ans:
                    ed.dirty = False           # the user chose to discard it
        self._save_layout()
        if not (self.safe and not self.editors):                # a safe start must not wipe the saved session
            self.cfg["files"] = [e.path for e in self.editors if e.path]
            self.cfg["active"] = self.editors.index(self.cur) if self.cur in self.editors else 0
        try:
            st = self.root.state()
            self.cfg["maximized"] = st == "zoomed"
            if st == "normal" and not getattr(self, "_fullscreen", False):                    # a minimised window reports (-32000,-32000): never store that
                self.cfg["geometry"] = self.root.geometry()
        except tk.TclError:
            pass
        save_config(self.cfg)
        if hot:
            self.save_session(force=True)
        else:
            try:
                if os.path.exists(SESSION_PATH):
                    os.remove(SESSION_PATH)
            except Exception:
                pass
        if self._built("ai_panel"):
            save_chat(self.ai_panel.msgs)
        self.ai_cancel()
        self.runner.stop(wait=True)
        self.root.destroy()

    def run(self):
        self.root.mainloop()


# ----------------------------------------------------------------------------
#  Command palette (Ctrl+Shift+P)
# ----------------------------------------------------------------------------
def build_commands(app):
    ed = app._ed
    q = lambda k: app.ai_panel.quick(k)
    C = [("New Python File", "Ctrl+N", lambda: app.new_file("python")),
         ("New C++ File", "", lambda: app.new_file("cpp", starter=True)),
         ("New C File", "", lambda: app.new_file("c", starter=True)),
         ("Open File", "Ctrl+O", app.open_file), ("Open Folder", "Ctrl+Shift+O", app.open_folder),
         ("Save", "Ctrl+S", app.save), ("Save As", "Ctrl+Shift+S", app.save_as), ("Save All", "", app.save_all),
         ("Close Tab", "Ctrl+W", app.close_current),
         ("Run", "F5", app.run_current), ("Run without debugging", "Ctrl+F5", app.run_current),
         ("Build", "F7", lambda: app.run_current(build_only=True)), ("Stop", "Shift+F5", app.stop_run),
         ("Full Screen", "F11", app.toggle_fullscreen), ("Toggle Sidebar", "Ctrl+B", app.toggle_sidebar), ("Toggle Terminal / Bottom Panel", "Ctrl+J", app.toggle_panel),
         ("Toggle AI", "Ctrl+L", app.toggle_ai),
         ("Show Explorer", "Ctrl+Shift+E", lambda: app.activity("explorer", True)),
         ("Search in Files", "Ctrl+Shift+F", lambda: app.activity("search", True)),
         ("Show Problems", "", lambda: app.show_panel(True, "Problems")),
         ("Show Output", "", lambda: app.show_panel(True, "Output")),
         ("Show Debug Console", "", lambda: app.show_panel(True, "Debug Console")),
         ("Settings", "Ctrl+,", app.open_settings), ("Change Theme", "Ctrl+Shift+T", app._theme_menu),
         ("Find", "Ctrl+F", lambda: app.findbar.show()), ("Replace", "Ctrl+H", lambda: app.findbar.show(True)),
         ("Go to Line", "Ctrl+G", app.goto_line), ("Format Document", "", app.format_document),
         ("Toggle Comment", "Ctrl+/", lambda: ed(lambda e: e.toggle_comment())),
         ("Fold All", "", lambda: ed(lambda e: e.fold_all())), ("Unfold All", "", lambda: ed(lambda e: e.unfold_all())),
         ("Toggle Word Wrap", "", app.toggle_wrap),
         ("Zoom In", "Ctrl+=", lambda: app.zoom(1)), ("Zoom Out", "Ctrl+-", lambda: app.zoom(-1)), ("Reset Zoom", "Ctrl+0", lambda: app.zoom(0)),
         ("Home Page", "", app.show_home), ("Keyboard Shortcuts", "", app.show_help),
         ("AI: Explain Code", "", lambda: q("explain")), ("AI: Fix Errors", "", lambda: q("fix")),
         ("AI: Improve Code", "", lambda: q("improve")), ("AI: Refactor", "", lambda: q("refactor")),
         ("AI: Generate Code", "", lambda: q("generate")), ("AI: Add Comments", "", lambda: q("comment")),
         ("AI: Write Tests", "", lambda: q("tests")), ("AI: Ask Inline at Cursor", "Ctrl+K", app.ai_inline),
         ("AI Settings", "", lambda: app.open_settings("AI"))]
    for n in THEME_ORDER:
        C.append(("Theme: " + n, "", lambda n=n: app.set_theme(n)))
    for n in TEMPLATES:
        C.append(("New from Template: " + n, "", lambda n=n: app.new_from_template(n)))
    return C


def fuzzy_score(q, s):
    """Lower is better; None = no match (every query letter must appear in order)."""
    q, s = q.lower(), s.lower()
    if q in s:
        return -10 + s.index(q) * .1
    i, score, last = 0, 0.0, -2
    for ch in q:
        j = s.find(ch, i)
        if j < 0:
            return None
        score += (0 if j == last + 1 else 1) + j * .01
        last, i = j, j + 1
    return score


class CommandPalette:
    MAXROWS = 9

    def __init__(self, app):
        app.close_popup()
        self.app = app
        th = T()
        self.cmds = build_commands(app)
        self.shown = []
        self.sel = 0
        w = tk.Toplevel(app.root)
        self.w = w
        w.withdraw()
        borderless(w)
        try:
            w.attributes("-topmost", True)
        except tk.TclError:
            pass
        w.configure(bg=th["border"])
        body = tk.Frame(w, bg=th["pop"])
        body.pack(padx=1, pady=1, fill="both", expand=True)
        self.var = tk.StringVar()
        self.entry = tk.Entry(body, textvariable=self.var, font=(app.ui_font.cget("family"), fs(12)))
        style_entry(self.entry, "pop")
        self.entry.configure(highlightthickness=0)
        self.entry.pack(fill="x", padx=16, pady=(14, 10), ipady=4)
        self.hint = TLabel(body, text="Type a command…", bg=th["pop"], fg=th["dim"], font=(app.ui_font.cget("family"), fs(12)))
        self.hint.place(x=20, y=17)
        self.hint.bind("<Button-1>", lambda e: self.entry.focus_set())
        self.var.trace_add("write", lambda *a: self.hint.place_forget() if self.var.get() else self.hint.place(x=20, y=17))
        tk.Frame(body, height=1, bg=th["border"]).pack(fill="x")
        self.list = tk.Frame(body, bg=th["pop"])
        self.list.pack(fill="x", padx=6, pady=6)
        self.foot = TLabel(body, text="↑ ↓ to choose · Enter to run · Esc to close", bg=th["pop"], fg=th["dim"], font=app.ui_font, anchor="w", padx=16, pady=6)
        self.foot.pack(fill="x")
        W = 600
        app.root.update_idletasks()
        x = app.root.winfo_rootx() + (app.root.winfo_width() - W) // 2
        y = app.root.winfo_rooty() + 70
        self.W = W
        show_window(w, x, y, dy=-14, ms=190)
        self.var.trace_add("write", lambda *a: self.refill())
        self.entry.bind("<Down>", lambda e: self.move(1))
        self.entry.bind("<Up>", lambda e: self.move(-1))
        self.entry.bind("<Return>", lambda e: self.run())
        self.entry.bind("<Escape>", lambda e: self.close())
        self.entry.bind("<FocusOut>", lambda e: app.root.after(150, self._maybe_close))
        self.refill()
        app.root.after(10, self._focus)
        app.popup = self

    def _focus(self):
        try:
            self.entry.focus_force()
        except Exception:
            pass

    def _maybe_close(self):
        if self.app.popup is not self:
            return
        try:
            f = self.app.root.focus_get()
            if f is None or f.winfo_toplevel() is not self.w:
                self.close()
        except Exception:
            self.close()

    def refill(self):
        th, app = T(), self.app
        for c in self.list.winfo_children():
            c.destroy()
        q = self.var.get().strip()
        if q:
            scored = [(fuzzy_score(q, c[0] + " " + tr(c[0])), c) for c in self.cmds]
            self.shown = [c for s, c in sorted((x for x in scored if x[0] is not None), key=lambda x: x[0])][:self.MAXROWS]
        else:
            self.shown = self.cmds[:self.MAXROWS]
        self.rows = []
        for i, (name, key, fn) in enumerate(self.shown):
            row = tk.Frame(self.list, bg=th["pop"], cursor="hand2")
            row.pack(fill="x", pady=1)
            a = TLabel(row, text=name, bg=th["pop"], fg=th["fg"], font=app.ui_font, anchor="w", padx=12, pady=6)
            a.pack(side="left", fill="x", expand=True)
            b = TLabel(row, text=K(key), bg=th["pop"], fg=th["muted"], font=app.ui_font, anchor="e", padx=12)
            b.pack(side="right")
            for wd in (row, a, b):
                wd.bind("<Enter>", lambda e, i=i: self.select(i))
                wd.bind("<ButtonRelease-1>", lambda e, i=i: (self.select(i), self.run()))
            self.rows.append((row, a, b))
        if not self.shown:
            TLabel(self.list, text="No matching commands", bg=th["pop"], fg=th["muted"], font=app.ui_font, pady=14).pack()
        try:                                                 # the window is exactly as tall as its content
            self.w.update_idletasks()
            self.w.geometry("%dx%d" % (self.W, self.w.winfo_reqheight()))
        except (tk.TclError, AttributeError):
            pass
        self.sel = 0
        self.select(0)

    def select(self, i):
        th = T()
        for k, (row, a, b) in enumerate(self.rows):
            col = mix(th["pop"], th["accent"], .20) if k == i else th["pop"]
            for wd in (row, a, b):
                wd.configure(bg=col)
        self.sel = i

    def move(self, d):
        if self.rows:
            self.select((self.sel + d) % len(self.rows))
        return "break"

    def run(self):
        if not self.shown:
            return "break"
        fn = self.shown[self.sel][2]
        self.close()
        self.app.root.after(30, fn)
        return "break"

    def close(self):
        try:
            self.w.destroy()
        except Exception:
            pass
        if self.app.popup is self:
            self.app.popup = None
        return "break"


# ----------------------------------------------------------------------------
#  Settings window
# ----------------------------------------------------------------------------
class ScrollFrame(tk.Frame):
    def __init__(self, master, bg):
        super().__init__(master, bg=bg)
        self.canvas = tk.Canvas(self, highlightthickness=0, bd=0, bg=bg)
        self.sb = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview, style="Legend.Vertical.TScrollbar")
        self.canvas.configure(yscrollcommand=self.sb.set)
        self.sb.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.inner = tk.Frame(self.canvas, bg=bg)
        self.win = self.canvas.create_window(0, 0, window=self.inner, anchor="nw")
        self.inner.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(self.win, width=e.width))
        self.sw = SmoothWheel(self.canvas, "canvas", bind=False)
        self.canvas.bind("<Enter>", lambda e: self.canvas.bind_all("<MouseWheel>", self._wheel))
        self.canvas.bind("<Leave>", lambda e: self.canvas.unbind_all("<MouseWheel>"))
        self.inner.bind("<Enter>", lambda e: self.canvas.bind_all("<MouseWheel>", self._wheel))

    def _wheel(self, e):
        return self.sw.on_wheel(e)


class ThemeGallery(tk.Canvas):
    """Every theme as a little preview card; click one to switch (colours cross-fade)."""
    CW, CH, GAP, COLS, LAB = 126, 76, 12, 4, 20

    def __init__(self, master, value, command, role="pop"):
        super().__init__(master, width=3 * (self.CW + self.GAP), height=self._height(3), highlightthickness=0, bd=0, cursor="hand2")
        self.cmd, self.role, self.hot = command, role, None
        self.COLS = 3
        self.bind("<Configure>", self._resize)
        self.sel = {k: 1.0 if k == value else 0.0 for k in THEME_ORDER}
        self.bind("<Motion>", self._move)
        self.bind("<Leave>", lambda e: self._set_hot(None))
        self.bind("<ButtonRelease-1>", self._click)
        self.paint()

    def _height(self, cols):
        rows = (len(THEME_ORDER) + cols - 1) // cols
        return rows * (self.CH + self.GAP + self.LAB)

    def _resize(self, e):
        cols = max(2, min(6, (e.width + self.GAP) // (self.CW + self.GAP)))
        if cols != self.COLS:
            self.COLS = cols
            self.configure(height=self._height(cols))
            self.paint()

    def _at(self, x, y):
        c, r = int(x // (self.CW + self.GAP)), int(y // (self.CH + self.GAP + self.LAB))
        i = r * self.COLS + c
        return THEME_ORDER[i] if 0 <= c < self.COLS and 0 <= i < len(THEME_ORDER) else None

    def _set_hot(self, name):
        if name != self.hot:
            self.hot = name
            self.paint()

    def _move(self, e):
        self._set_hot(self._at(e.x, e.y))

    def _click(self, e):
        n = self._at(e.x, e.y)
        if not n:
            return
        start = dict(self.sel)

        def step(p):
            for k in self.sel:
                self.sel[k] = start[k] + ((1.0 if k == n else 0.0) - start[k]) * p
            self.paint()
        tween(("gal-sel", id(self)), 260, step, ease=ease_out_quint)
        self.cmd(n)

    def paint(self):
        th = T()
        self.delete("all")
        self._imgs = []
        self.configure(bg=th[self.role])
        f = tkfont.nametofont("TkDefaultFont")
        for i, name in enumerate(THEME_ORDER):
            t2 = THEMES[name]
            x0 = (i % self.COLS) * (self.CW + self.GAP)
            y0 = (i // self.COLS) * (self.CH + self.GAP + self.LAB) - (2 if name == self.hot else 0)
            sel = self.sel[name]
            aa_round_rect(self, x0, y0, x0 + self.CW, y0 + self.CH, R(12), t2["bg"], line=mix(t2["border"], th["accent"], sel), lw=2 if sel > .5 else 1)
            aa_round_rect(self, x0 + 8, y0 + 8, x0 + 30, y0 + self.CH - 8, R(6), t2["panel"])
            for k, (col, w) in enumerate(((t2["kw"], 40), (t2["fn"], 56), (t2["st"], 34), (t2["cm"], 48))):
                aa_round_rect(self, x0 + 40, y0 + 12 + k * 14, x0 + 40 + w, y0 + 19 + k * 14, 3, col)
            aa_circle(self, x0 + self.CW - 16, y0 + 15, 5, t2["accent"])
            self.create_text(x0 + 2, y0 + self.CH + 10, text=name, anchor="w", fill=mix(th["muted"], th["fg"], max(sel, .6 if name == self.hot else 0)), font=f)

    retheme = paint


class Swatches(tk.Canvas):
    """Row of colour dots: the accent-colour picker ('A' = the theme's own colour)."""

    def __init__(self, master, value, command, theme_name, role="pop"):
        self.names = ["auto"] + list(ACCENTS)
        super().__init__(master, width=len(self.names) * 36 + 4, height=36, highlightthickness=0, bd=0, cursor="hand2")
        self.cmd, self.role, self.theme_name = command, role, theme_name
        self.sel = {n: 1.0 if n == value else 0.0 for n in self.names}
        self.hov = {n: 0.0 for n in self.names}
        self.bind("<Motion>", self._move)
        self.bind("<Leave>", lambda e: self._hover(None))
        self.bind("<ButtonRelease-1>", self._click)
        self.paint()

    def _at(self, x):
        i = int((x - 2) // 36)
        return self.names[i] if 0 <= i < len(self.names) else None

    def _hover(self, name):
        for n in self.names:
            want = 1.0 if n == name else 0.0
            if abs(self.hov[n] - want) > .01:
                a = self.hov[n]
                tween(("sw-h", id(self), n), 140, lambda p, n=n, a=a, want=want: (self.hov.__setitem__(n, a + (want - a) * p), self.paint()))

    def _move(self, e):
        self._hover(self._at(e.x))

    def _click(self, e):
        n = self._at(e.x)
        if n is None:
            return
        start = dict(self.sel)

        def step(p):
            for k in self.names:
                self.sel[k] = start[k] + ((1.0 if k == n else 0.0) - start[k]) * p
            self.paint()
        tween(("sw-sel", id(self)), 260, step, ease=ease_out_quint)
        self.cmd(n)

    def paint(self):
        th = T()
        self.delete("all")
        self._imgs = []
        self.configure(bg=th[self.role])
        for i, n in enumerate(self.names):
            cx, cy = 20 + i * 36, 18
            col = ACCENTS[n] if n in ACCENTS else THEMES.get(self.theme_name, THEMES["Legend Dark"])["accent"]
            r = 10 + 1.5 * self.hov[n]
            if self.sel[n] > .01:
                aa_circle(self, cx, cy, 15, th[self.role], line=mix(th[self.role], th["fg"], self.sel[n]), lw=2)
            aa_circle(self, cx, cy, r, col)
            if n == "auto":
                self.create_text(cx, cy, text="A", fill="#14110a" if not is_dark(col) else "#ffffff", font=(tkfont.nametofont("TkDefaultFont").cget("family"), 9, "bold"))

    retheme = paint


class ShapePicker(tk.Canvas):
    """Little buttons that show each corner style: sharp / soft / round / squircle / pill."""
    OPTS = (("sharp", "Sharp", 2), ("soft", "Soft", 9), ("round", "Round", 15), ("squircle", "Squircle", 14), ("pill", "Pill", 40))

    def __init__(self, master, value, command, role="pop"):
        super().__init__(master, width=5 * 88 + 4, height=44, highlightthickness=0, bd=0, cursor="hand2")
        self.cmd, self.role = command, role
        self.sel = {k: 1.0 if k == value else 0.0 for k, _, _ in self.OPTS}
        self.bind("<ButtonRelease-1>", self._click)
        self.paint()

    def _click(self, e):
        i = int((e.x - 2) // 88)
        if not 0 <= i < len(self.OPTS):
            return
        n = self.OPTS[i][0]
        start = dict(self.sel)

        def step(p):
            for k in self.sel:
                self.sel[k] = start[k] + ((1.0 if k == n else 0.0) - start[k]) * p
            self.paint()
        tween(("shape-sel", id(self)), 240, step, ease=ease_out_quint)
        self.cmd(n)

    def paint(self):
        th = T()
        self.delete("all")
        self._imgs = []
        self.configure(bg=th[self.role])
        f = tkfont.nametofont("TkDefaultFont")
        for i, (k, label, r) in enumerate(self.OPTS):
            x0 = 2 + i * 88
            sel = self.sel[k]
            aa_round_rect(self, x0, 2, x0 + 82, 42, r, mix(th["panel2"], th["accent"], .22 * sel), line=mix(th["border"], th["accent"], sel),
                          n=SHAPES[k][1])
            self.create_text(x0 + 41, 22, text=visual(tr(label)), fill=mix(th["muted"], th["fg"], sel), font=f)

    retheme = paint


class SettingsWindow:
    PAGES = ("General", "Appearance", "Editor", "Python", "C/C++", "AI", "Advanced")
    SUB = {"General": "Language, start-up and saving.", "Appearance": "Colours, shapes, glass and motion.", "Editor": "How the code editor behaves.",
           "Python": "The interpreter and how programs are run.", "C/C++": "Compilers and build flags.",
           "AI": "The assistant works out of the box: no account, no key, no cost. Everything here is optional.",
           "Advanced": "Performance, safety and diagnostics."}

    def __init__(self, app, page="General"):
        self.app = app
        th = T()
        self.top = tk.Toplevel(app.root)
        self.top.title("Settings — " + APP)
        self.top.transient(app.root)
        self.top.minsize(780, 540)
        self.top.configure(bg=th["pop"])
        app.root.update_idletasks()
        W, H = 920, 660
        x = app.root.winfo_rootx() + max(0, (app.root.winfo_width() - W) // 2)
        y = app.root.winfo_rooty() + max(0, (app.root.winfo_height() - H) // 3)
        self.top.geometry("%dx%d+%d+%d" % (W, H, x, y))
        self.top.protocol("WM_DELETE_WINDOW", self.close)
        self.top.bind("<Escape>", lambda e: self.close())
        self.page = page if page in self.PAGES else "General"
        self._save_job = None
        self._pulling = False
        self._pull_cancel = None
        self._pull_model = recommended_local_model()
        self._closed = False
        self._pq = queue.Queue()
        self.build()
        app.root.after(150, self._pump)

    # ---- scaffolding -----------------------------------------------------------
    def close(self):
        self._closed = True
        if self._pull_cancel:
            self._pull_cancel.set()
        self._flush()
        try:
            self.top.destroy()
        except tk.TclError:
            pass
        self.app.settings_win = None

    def _flush(self):
        if self._save_job:
            try:
                self.top.after_cancel(self._save_job)
            except Exception:
                pass
            self._save_job = None
        save_config(self.app.cfg)

    def changed(self, key, value, apply=None):
        self.app.cfg[key] = value
        if self._save_job:
            self.top.after_cancel(self._save_job)
        self._save_job = self.top.after(500, self._flush)
        if apply:
            apply()

    def _rebuild_open(self):
        if not self._closed:
            try:
                self.build()
            except tk.TclError:
                pass

    def show_page(self, page):
        self.page = page if page in self.PAGES else "General"
        self.build()

    def build(self):
        th, app = T(), self.app
        for c in self.top.winfo_children():
            c.destroy()
        self.top.configure(bg=th["pop"])
        nav = tk.Frame(self.top, width=200, bg=th["panel"])
        nav.pack(side="left", fill="y")
        nav.pack_propagate(False)
        TLabel(nav, text="Settings", bg=th["panel"], fg=th["fg"], font=(app.ui_font.cget("family"), fs(14), "bold"), anchor="w", padx=20, pady=18).pack(fill="x")
        for name in self.PAGES:
            on = name == self.page
            row = tk.Frame(nav, bg=mix(th["panel"], th["accent"], .16) if on else th["panel"], cursor="hand2")
            row.pack(fill="x", padx=10, pady=1)
            tk.Frame(row, width=3, bg=th["accent"] if on else row.cget("bg")).pack(side="left", fill="y")
            lab = TLabel(row, text=name, bg=row.cget("bg"), fg=th["fg"] if on else th["muted"], font=app.ui_bold if on else app.ui_font,
                           anchor="w", padx=14, pady=9, cursor="hand2")
            lab.pack(side="left", fill="x", expand=True)
            for wd in (row, lab):
                wd.bind("<Button-1>", lambda e, n=name: self.show_page(n))
        foot = tk.Frame(nav, bg=th["panel"])
        foot.pack(side="bottom", fill="x", padx=14, pady=14)
        Btn(foot, "Reset settings", self.reset, kind="outline", role="panel", height=30, padx=12).pack(anchor="w")
        TLabel(foot, text="Changes are saved automatically.", bg=th["panel"], fg=th["dim"], font=app.ui_font, anchor="w", justify="left", wraplength=165).pack(anchor="w", pady=(10, 0))
        right = tk.Frame(self.top, bg=th["pop"])
        right.pack(side="left", fill="both", expand=True)
        TLabel(right, text=self.page, bg=th["pop"], fg=th["fg"], font=(app.ui_font.cget("family"), fs(18), "bold"), anchor="w").pack(fill="x", padx=30, pady=(22, 0))
        TLabel(right, text=self.SUB[self.page], bg=th["pop"], fg=th["muted"], font=app.ui_font, anchor="w", wraplength=560, justify="left").pack(fill="x", padx=30, pady=(2, 8))
        sf = ScrollFrame(right, th["pop"])
        sf.pack(fill="both", expand=True, pady=(0, 10))
        self.body = sf.inner
        getattr(self, "page_" + {"C/C++": "cpp"}.get(self.page, self.page.lower()))()

    def reset(self):
        if not messagebox.askyesno(APP, "Reset all settings to their defaults?\n(Your files, folders and recent lists are kept.)", parent=self.top):
            return
        keep = {"files", "active", "recent_files", "recent_folders", "folder", "geometry"}
        for k, v in DEFAULTS.items():
            if k not in keep:
                self.app.cfg[k] = json.loads(json.dumps(v))
        self._flush()
        self.app.set_theme(self.app.cfg["theme"])
        self.app.set_font(family="", size=int(self.app.cfg["font_size"]))
        self.app.apply_editor_settings()
        self.build()
        self.app.toast("Settings reset", "info")

    # ---- row builders -------------------------------------------------------------
    def _row(self, label, hint=None):
        th, app = T(), self.app
        r = tk.Frame(self.body, bg=th["pop"])
        r.pack(fill="x", padx=30, pady=9)
        r.grid_columnconfigure(0, minsize=250)
        r.grid_columnconfigure(1, weight=1)
        left = tk.Frame(r, bg=th["pop"])
        left.grid(row=0, column=0, sticky="nw")
        TLabel(left, text=label, bg=th["pop"], fg=th["fg"], font=app.ui_font, anchor="w", justify="left", wraplength=230).pack(anchor="w")
        if hint:
            TLabel(left, text=hint, bg=th["pop"], fg=th["dim"], font=app.ui_font, anchor="w", justify="left", wraplength=230).pack(anchor="w", pady=(2, 0))
        right = tk.Frame(r, bg=th["pop"])
        right.grid(row=0, column=1, sticky="w")
        return right

    def section(self, text):
        th, app = T(), self.app
        f = tk.Frame(self.body, bg=th["pop"])
        f.pack(fill="x", padx=30, pady=(20, 2))
        TLabel(f, text=text, bg=th["pop"], fg=th["accent"], font=app.ui_bold, anchor="w").pack(side="left")
        tk.Frame(f, height=1, bg=th["border"]).pack(side="left", fill="x", expand=True, padx=(12, 0), pady=(2, 0))

    def switch(self, label, key, hint=None, apply=None, default=False):
        sw = Switch(self._row(label, hint), self.app.cfg.get(key, default), lambda v: self.changed(key, v, apply), role="pop")
        sw.pack(anchor="w")

    def select(self, label, key, options, hint=None, apply=None, width=24, cast=None):
        """options: list of display strings, or list of (display, value) pairs."""
        pairs = [(o, o) if not isinstance(o, tuple) else o for o in options]
        cur = self.app.cfg.get(key)
        shown = next((d for d, v in pairs if v == cur or str(v) == str(cur)), pairs[0][0])
        by = dict(pairs)
        sel = Select(self._row(label, hint), self.app, [d for d, v in pairs], shown,
                     lambda d: self.changed(key, by[d], apply), width=width, role="panel2")
        sel.pack(anchor="w")
        return sel

    def entry(self, label, key, hint=None, width=40, show=None, browse=False, apply=None, default=""):
        th, app = T(), self.app
        r = self._row(label, hint)
        var = tk.StringVar(value=str(app.cfg.get(key, default) or ""))
        e = tk.Entry(r, textvariable=var, width=width, font=app.ui_font, show=show or "")
        style_entry(e)
        e.pack(side="left", ipady=5)
        var.trace_add("write", lambda *a: self.changed(key, var.get().strip() if key != "cxxflags" and key != "cflags" else var.get(), apply))
        if browse:
            Btn(r, "Browse…", lambda: var.set(filedialog.askopenfilename(parent=self.top) or var.get()), kind="outline", role="pop", height=30, padx=12).pack(side="left", padx=8)
        return var

    def note(self, text, color="muted"):
        th, app = T(), self.app
        lab = TLabel(self.body, text=text, bg=th["pop"], fg=th[color], font=app.ui_font, anchor="w", justify="left", wraplength=600)
        lab.pack(fill="x", padx=30, pady=(4, 4))
        return lab

    # ---- pages --------------------------------------------------------------------------
    def _look(self):
        """Apply an appearance change now, then recolour this window once the cross-fade has finished."""
        self.app.restyle()
        self.app.root.after(420, self._rebuild_open)

    def _lang_changed(self):
        self.app.toast(tr("Restart to apply the language"), "info", 9000, action=(tr("Restart"), self.app.restart))

    def page_general(self):
        app = self.app
        self.section("Language")
        self.select("Interface language", "ui_lang", [("English", "en"), ("العربية", "ar")], "The interface changes after a restart.", width=18, apply=self._lang_changed)
        self.section("Start")
        self.switch("Remember my work when I close", "hot_exit", "Open tabs, unsaved text, cursor positions and the chat come back next time, without asking to save.", default=True)
        self.switch("Start in full screen", "fullscreen_start")
        self.select("New files are", "new_lang", [("Python", "python"), ("C++", "cpp"), ("C", "c")], width=14)
        self.select("When Legend starts", "startup", [("Reopen my last files", "restore"), ("Show the Home page", "welcome"), ("Start with a new file", "new")], width=26)
        self.entry("Your name", "user_name", "Used in the welcome message and by the assistant.", width=24)
        self.switch("Short welcome message", "greeting", "One quiet line when the app opens. Never blocks or slows the start.", default=True)
        self.switch("Automatic updates", "auto_update", "Downloads new versions quietly; they apply the next time you open the app.", default=True)
        self.section("Saving")
        self.switch("Autosave", "autosave", "Saves files that already have a name.")
        self.select("Autosave every", "autosave_secs", [("15 seconds", 15), ("30 seconds", 30), ("1 minute", 60), ("2 minutes", 120)], width=14)
        self.switch("Confirm before closing", "confirm_exit", "Always ask before Legend Code quits. (Unsaved changes are always asked about.)")
        self.section("Windows")
        r = self._row("Desktop icon", "Adds a Legend Code shortcut that shows the logo (Windows shows Python's icon for .pyw files).")
        Btn(r, "Create shortcut", lambda: app.create_shortcut(), icon="open", kind="outline", role="pop", height=32, padx=14).pack(anchor="w")

    def page_appearance(self):
        app = self.app
        self.section("Look")
        th = T()
        box = tk.Frame(self.body, bg=th["pop"])
        box.pack(fill="x", padx=30, pady=(9, 4))
        TLabel(box, text="Theme", bg=th["pop"], fg=th["fg"], font=app.ui_font, anchor="w").pack(anchor="w")
        TLabel(box, text="%d themes. Colours cross-fade smoothly." % len(THEME_ORDER), bg=th["pop"], fg=th["dim"], font=app.ui_font, anchor="w").pack(anchor="w", pady=(2, 8))
        ThemeGallery(box, app.cfg.get("theme"), lambda v: self.changed("theme", v, self._look)).pack(fill="x")
        r = self._row("Accent colour", "Colour of highlights, buttons and selections.")
        Swatches(r, app.cfg.get("accent", "auto"), lambda v: self.changed("accent", v, self._look), app.cfg.get("theme")).pack(anchor="w")

        def pick():
            from tkinter import colorchooser
            cur = app.cfg.get("accent", "auto")
            col = colorchooser.askcolor(color=ACCENTS.get(cur, cur if str(cur).startswith("#") else T()["accent"]),
                                        title=tr("Custom colour"), parent=self.win if hasattr(self, "win") else app.root)
            if col and col[1]:
                self.changed("accent", col[1].upper(), self._look)
        Btn(r, "Custom colour…", pick, kind="outline", role="pop", height=30, padx=12).pack(anchor="w", pady=(8, 0))
        self.switch("Colourful interface", "colorful", "Gives each part its own colour: sidebar icons, menus and the home cards.", apply=self._look)
        r = self._row("Shapes", "The corner style of buttons, cards and menus.")
        ShapePicker(r, app.cfg.get("shape", "soft"), lambda v: self.changed("shape", v, self._look)).pack(anchor="w")
        self.section("Glass")
        self.switch("Glass style", "glass", "Lighter, cooler surfaces with soft glowing edges, plus a see-through window.", apply=self._look)
        self.select("Window transparency", "opacity", [("None (100%)", 100), ("Slight (95%)", 95), ("Medium (90%)", 90), ("Strong (85%)", 85), ("Very strong (80%)", 80)],
                    "Used together with Glass style.", apply=lambda: app.root.attributes("-alpha", app.window_alpha()), width=20)
        self.section("Layout")
        self.switch("Show the activity bar", "show_activity", "The icon column on the far left.", apply=app.apply_chrome, default=True)
        self.switch("Show the status bar", "show_status", apply=app.apply_chrome, default=True)
        r = self._row("Full screen", "Press F11 any time (Esc leaves it).")
        Btn(r, "Toggle full screen", app.toggle_fullscreen, kind="outline", role="pop", height=32, padx=14).pack(anchor="w")
        self.section("Motion")
        self.switch("Smooth animations", "animations", "Gentle fades, glides and springs.", default=True)
        self.switch("Smooth scrolling", "smooth_scroll", "Eased mouse-wheel scrolling.", default=True)
        self.select("Scroll speed", "scroll_lines", [("Slow (2 lines)", 2), ("Normal (3 lines)", 3), ("Fast (5 lines)", 5), ("Very fast (8 lines)", 8)], width=20)
        self.select("Animation style", "anim_level", [("Expressive (strongest)", "expressive"), ("Smooth (richer)", "smooth"), ("Subtle (shorter)", "subtle")], width=22)
        self.section("Editor text")
        self.select("Editor font", "font_family", [("Auto", "")] + [(f, f) for f in app.mono_choices],
                    "Monospaced fonts found on this PC.", apply=lambda: app.set_font(family=app.cfg["font_family"]))
        self.select("Font size", "font_size", [str(n) for n in range(10, 25)], width=8, cast=int,
                    apply=lambda: app.set_font(size=int(app.cfg["font_size"])))

    def page_advanced(self):
        app = self.app
        self.section("Performance")
        self.switch("Lite mode", "lite", "Turns off animations and glass: the lightest and fastest feel.", apply=self._look)
        self.section("Safety")
        r = self._row("Unsaved work", "If Legend ever closes unexpectedly, your unsaved text is kept safely.")
        Btn(r, "Recover unsaved work", app.recover_unsaved, kind="outline", role="pop", height=32, padx=14).pack(anchor="w")
        r = self._row("Panels", "Brings the side panels back to their normal size.")
        Btn(r, "Reset layout", app.reset_layout, kind="outline", role="pop", height=32, padx=14).pack(anchor="w")
        r = self._row("Crash log", "Where errors are written (send it if something breaks).")
        Btn(r, "Open crash log", app.open_crash_log, kind="outline", role="pop", height=32, padx=14).pack(anchor="w")
        self.section("Information")
        ms = getattr(app, "_startup_ms", None)
        self.note("Started in %s" % ("%.0f ms" % ms if ms else "…") + ("  (safe mode)" if app.safe else ""))
        self.note("Version %s  ·  %s" % (VERSION, SCRIPT_PATH))

    def page_editor(self):
        app = self.app
        ap = app.apply_editor_settings
        self.section("Typing")
        self.select("Tab size", "tab_size", [("2 spaces", 2), ("4 spaces", 4), ("8 spaces", 8)], width=12, apply=ap)
        self.switch("Autocomplete", "autocomplete", "Suggest variables, functions and keywords as you type (Ctrl+Space any time).", default=True)
        self.switch("Auto-close brackets and quotes", "auto_pair", "Typing ( [ { or a quote adds the closing one.", default=True)
        self.select("Cursor", "cursor_style", [("Line", "line"), ("Thick line", "thick"), ("Block", "block")], width=14, apply=ap)
        self.switch("Blinking cursor", "cursor_blink", apply=ap, default=True)
        self.select("Line spacing", "line_spacing", [("Tight", 0), ("Normal", 1), ("Relaxed", 3), ("Airy", 5)], width=14, apply=ap)
        self.section("Saving files")
        self.switch("Remove trailing spaces when saving", "trim_ws")
        self.switch("End files with a new line", "final_newline")
        self.section("Display")
        self.switch("Word wrap", "word_wrap", apply=ap)
        self.switch("Line numbers", "line_numbers", apply=ap, default=True)
        self.switch("Highlight current line", "highlight_line", apply=ap, default=True)
        self.switch("Bracket matching", "bracket_match", "Highlights the partner of the bracket next to the cursor.", apply=ap, default=True)

    def page_python(self):
        app = self.app
        self.section("Interpreter")
        self.entry("Python executable", "python", "Leave empty to auto-detect.", browse=True, apply=lambda: self._refresh_detect())
        self.det = self.note("")
        self._refresh_detect()
        self.section("Running")
        self.entry("Program arguments", "run_args", "Passed to your program (same box as the Run sidebar).", width=40)
        self.switch("Save the file before running", "autosave_on_run", default=True)
        self.switch("Clear the terminal on each run", "clear_on_run", default=True)

    def page_cpp(self):
        self.section("Compiler")
        self.entry("C++ compiler (g++)", "cxx", "Leave empty to auto-detect (also finds MinGW on Windows).", browse=True, apply=lambda: self._refresh_detect())
        self.det = self.note("")
        self._refresh_detect()
        self.section("Flags")
        self.entry("C++ flags", "cxxflags", "Example: -std=c++17 -O2 -Wall", width=40)
        self.entry("C flags", "cflags", "Example: -std=c17 -O2 -Wall", width=40)
        self.switch("Unbuffered output", "unbuffered", "Makes prompts appear immediately in the terminal.", default=True)

    def _refresh_detect(self):
        try:
            cfg = self.app.cfg
            self.det.configure(text="Detected   Python: %s\n                  C++: %s\n                  C: %s" % (
                find_python(cfg), find_cxx(cfg) or "NOT FOUND", find_cc(cfg) or "NOT FOUND"))
        except Exception:
            pass

    def page_ai(self):
        th, app = T(), self.app
        cfg, ai = app.cfg, app.ai

        def refresh_ai():
            app.ai_panel.refresh_ready()
            app._slow_tick_once()
            try:
                self.using.configure(text="Using right now:  " + ai.describe())
            except tk.TclError:
                pass
        self.section("Provider")
        self.select("AI provider", "ai_provider", [("Auto (recommended)", "auto"), ("Free online - no account", "free"),
                                                   ("Local model - Ollama", "ollama"), ("Claude - needs an API key", "anthropic")],
                    "Auto uses a local model when one is running, otherwise the free online model.", apply=refresh_ai, width=28)
        self.using = self.note("Using right now:  " + ai.describe(), "accent")
        self.select("Reply language", "ai_reply", [("Arabic", "Arabic"), ("English", "English"), ("Same as my question", "Same as me")], width=22)
        self.row_test = self._row("Check that it works")
        Btn(self.row_test, "Test the assistant", self.test_ai, kind="primary", role="pop", height=32, padx=16).pack(side="left")
        self.test_res = TLabel(self.row_test, text="", bg=th["pop"], fg=th["muted"], font=app.ui_font, anchor="w", justify="left", wraplength=360)
        self.test_res.pack(side="left", padx=12)

        self.section("Local AI - private, offline, free")
        self.note("Runs on your own PC with Ollama. Your code never leaves your computer, and there are no limits.")
        r = self._row("Ollama status")
        self.local_l = TLabel(r, text="Checking…", bg=th["pop"], fg=th["muted"], font=app.ui_font, anchor="w", justify="left", wraplength=360)
        self.local_l.pack(side="left")
        r2 = self._row("Set up")
        Btn(r2, "1. Get Ollama", lambda: webbrowser.open("https://ollama.com/download"), kind="outline", role="pop", height=30, padx=12).pack(side="left")
        rec = recommended_local_model()
        self.pull_b = Btn(r2, "2. Download %s" % rec, lambda: self.start_pull(rec), kind="primary", role="pop", height=30, padx=12)
        self.pull_b.pack(side="left", padx=8)
        Btn(r2, "Check again", self.refresh_local, kind="ghost", role="pop", height=30, padx=10).pack(side="left")
        self.note("Recommended for this PC (%.0f GB RAM): %s" % (total_ram_gb(), rec))
        r3 = self._row("Download progress")
        self.bar = ttk.Progressbar(r3, orient="horizontal", length=300, mode="determinate", style="Legend.Horizontal.TProgressbar", maximum=100)
        self.bar.pack(side="left")
        self.pull_l = TLabel(r3, text="", bg=th["pop"], fg=th["muted"], font=app.ui_font, padx=10)
        self.pull_l.pack(side="left")
        self.entry("Ollama address", "ollama_url", width=34, apply=lambda: (ai.refresh_probe(force=True), self.refresh_local()))
        self.entry("Ollama model", "ollama_model", "Use the name from 'ollama list'.", width=34)
        try:
            app.style.configure("Legend.Horizontal.TProgressbar", troughcolor=th["panel2"], background=th["accent"], bordercolor=th["panel2"],
                                lightcolor=th["accent"], darkcolor=th["accent"], thickness=8)
        except tk.TclError:
            pass

        self.section("Free online model")
        self.note("Used when no local model is running. Your questions and code are sent to this free service. It can be slow or "
                  "busy at times; the address can be changed here if the service moves.")
        self.entry("Service address", "free_url", "Empty = built-in default.", width=44)
        self.entry("Model name", "free_model", "Empty = built-in default.", width=24)

        self.section("Claude (optional)")
        self.note("Only if you already have an Anthropic API key. Not needed for the assistant to work.")
        self.entry("API key", "ai_key", "Stored as plain text in ~/.legend_ide.json", width=44, show="•", apply=refresh_ai)
        self.entry("Claude model", "ai_model", width=28)
        self.refresh_local()

    # ---- AI page actions -------------------------------------------------------------------
    def _pump(self):
        """Main-thread poll for results coming from worker threads (local check, model download)."""
        if self._closed:
            return
        try:
            while True:
                item = self._pq.get_nowait()
                kind = item[0]
                if kind == "local":
                    self._show_local(item[1])
                elif kind == "progress":
                    if item[1] is not None:
                        self.bar.configure(value=item[1])
                    self.pull_l.configure(text=item[2])
                elif kind == "done":
                    self._pulling = False
                    self.bar.configure(value=100)
                    self.pull_l.configure(text="Ready ✔")
                    self.pull_b.set_text("2. Download %s" % self._pull_model)
                    self.changed("ollama_model", item[1])
                    self.app.ai.refresh_probe(force=True)
                    self.app.toast("Local AI model is ready - the assistant will use it automatically", "success", 4500)
                    self.refresh_local()
                elif kind == "error":
                    self._pulling = False
                    self.pull_l.configure(text=item[1])
                    self.pull_b.set_text("2. Download %s" % self._pull_model)
        except queue.Empty:
            pass
        except tk.TclError:
            pass                       # the page was rebuilt; widgets of the old page are gone
        self.app.root.after(150, self._pump)

    def refresh_local(self):
        url = self.app.cfg.get("ollama_url", "http://localhost:11434")
        try:
            self.local_l.configure(text="Checking…")
        except tk.TclError:
            pass
        q = self._pq
        threading.Thread(target=lambda: q.put(("local", ollama_models(url, 1.5))), daemon=True).start()

    def _show_local(self, models):
        th = T()
        if models is None:
            self.local_l.configure(text="Not running. Install Ollama (free), start it, then press 'Check again'.", fg=th["muted"])
        elif not models:
            self.local_l.configure(text="Running ✔  but no model yet - press 'Download' below.", fg=th["yellow"])
        else:
            self.local_l.configure(text="Running ✔  Models: " + ", ".join(models[:4]) + ("…" if len(models) > 4 else ""), fg=th["green"])

    def start_pull(self, model):
        if self._pulling:
            if self._pull_cancel:
                self._pull_cancel.set()
            return
        url = self.app.cfg.get("ollama_url", "http://localhost:11434")
        self._pulling = True
        self._pull_model = model
        self._pull_cancel = cancel = threading.Event()
        self.pull_b.set_text("Cancel download")
        self.pull_l.configure(text="Starting…")
        q = self._pq

        def work():
            try:
                if ollama_models(url, 1.5) is None:
                    q.put(("error", "Ollama isn't running. Install it from ollama.com, start it, then try again."))
                    return
                last = [None]

                def cb(status, done, total):
                    if total:
                        q.put(("progress", done * 100.0 / total, "%s  %.1f / %.1f GB" % (status[:24], done / 2 ** 30, total / 2 ** 30)))
                    elif status != last[0]:
                        last[0] = status
                        q.put(("progress", None, status[:50]))
                ok = ollama_pull(url, model, cb, cancel)
                q.put(("done", model) if ok else ("error", "Download cancelled."))
            except Exception as e:
                q.put(("error", "Download failed: %s" % e))
        threading.Thread(target=work, daemon=True).start()

    def test_ai(self):
        q = queue.Queue()
        cancel = threading.Event()
        buf = []
        self.test_res.configure(text="Testing…", fg=T()["muted"])
        self.app.ai.refresh_probe(force=True)
        self.app.ai.start("Reply with the single word OK.", [{"role": "user", "content": "ping"}], q, 0, cancel, 32)
        self._poll_test(q, buf, cancel, time.time())

    def _poll_test(self, q, buf, cancel, t0):
        th = T()
        if self._closed:
            cancel.set()
            return
        try:
            while True:
                rid, kind, data = q.get_nowait()
                if kind == "delta":
                    buf.append(data)
                elif kind == "done":
                    self.test_res.configure(text="✔ Works  (%s) - it answered: %s" % (self.app.ai.describe(), "".join(buf).strip()[:40] or "(empty)"), fg=th["green"])
                    return
                elif kind == "error":
                    self.test_res.configure(text="✖ " + data, fg=th["red"])
                    return
        except queue.Empty:
            pass
        except tk.TclError:
            return
        if time.time() - t0 > 60:
            cancel.set()
            self.test_res.configure(text="✖ Timed out.", fg=th["red"])
            return
        self.app.root.after(120, self._poll_test, q, buf, cancel, t0)


# ----------------------------------------------------------------------------
def main():
    safe = boot_begin()
    wd = start_watchdog(12)
    try:
        App(safe=safe, watchdog=wd).run()
    except Exception:
        msg = traceback.format_exc()
        try:
            with open(CRASH_LOG, "a", encoding="utf-8") as f:
                f.write("\n--- %s ---\n%s" % (time.ctime(), msg))
        except Exception:
            pass
        try:
            messagebox.showerror(APP, "Legend Code crashed:\n\n" + msg[-1500:])
        except Exception:
            print(msg, file=sys.stderr)


if __name__ == "__main__":
    main()
